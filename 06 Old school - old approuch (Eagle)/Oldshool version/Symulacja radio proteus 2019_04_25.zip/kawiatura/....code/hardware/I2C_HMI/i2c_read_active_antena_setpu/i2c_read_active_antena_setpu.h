#ifndef __i2c_read_active_antena_setup__
   #define __i2c_read_active_antena_setup__
   
   int8 get_active_antena_power_setup(void);

#endif
