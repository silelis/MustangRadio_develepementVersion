#include <main_slave_uart.h>

void main()
{

   while(TRUE)
   {
   if (input(pin_b0))
   {
   
   fprintf(PORT1,"START V1.3...");
   delay_ms(5000);
   
   
   }

      //TODO: User Code
   }

}
