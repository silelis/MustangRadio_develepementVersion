proteus_8.0_emulation_hex\PIC16F84A\UV_project.hex is for SIMULATION purpous only.
You can use it in final hardware only by Your own risk. All known bugs was fixed in final firmware version attached to source code.

Known bug (only in proteus_8.0_emulation_hex\PIC16F84A\UV_project.hex):
- time counted by emulator is not equal to real time.