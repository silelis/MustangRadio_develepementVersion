//#include <main.h>

#include <18F4520.h>
//#device ADC=10
//CONST=ROM
#device PASS_STRINGS=IN_RAM



#fuses HS,NOWDT, NOPROTECT//, NOLVP, BROWNOUT
//#fuses nomclr
//#FUSES WDT 
  // setup_wdt(WDT_2304MS);
  // restart_wdt();
   //setup_wdt(WDT_OFF);

#use delay (crystal=20MHz, clock=20MHz,fast_start)


//#use rs232(baud=57600,parity=N, xmit=PIN_C6,rcv=PIN_C7, bits=8, stream=Hrdw)

#use rs232(UART1, baud=9600,parity=N, bits=8, stream=Hrdw, ERRORS)//, DISABLE_INTS)

#use rs232(baud=38400,parity=N,xmit=PIN_b7,rcv=PIN_b6,bits=8,stream=Dbg)
   
   
#include </MCU_include/core/UART_Engine/UART_Engine.c>
#include </MCU_include/hardware/OVC3860/OVC3860.c>
// to do UART_engine



#int_rda
void serial_isr()
{
   uart_read_slave_data();   
}


#ZERO_RAM
void main()
{
   delay_ms(500);
    
  //fprintf(Dbg,"UART_dbg_TEST \r\n");
  output_high(pin_B5);
  uart_ClearRxParameter();
   
   
   enable_interrupts(int_rda);
   enable_interrupts(global);   
   
   fprintf(Dbg,"UART_dbg_TEST \r\n"); 
   


   //char buffer1[10]={"a"};
   
   //unsigned int16 wynik = parse_received_dataForInt16(buffer1, 10);

   //fprintf(Dbg,"atoI wynik %lu \r\n", wynik); 
   
   delay_ms(2000);

   OVC_powerUP(PIN_D1);

//   unsigned int16 *poiner;
//   poiner =&UART_kbhit_timeout;

   //unsigned int8 *UART_kbhit_timeout_pointer;
   //UART_kbhit_timeout_pointer = & UART_kbhit_timeout;
   
   //int16 vol_val;
   while(TRUE)
   {
   
   //fprintf(Hrdw,"UART HDR_TEST \r\n");
   //fprintf(Dbg,"UART DBG _TEST \r\n");
   //delay_ms(100);
   if (UART_data_received_STATEMENT==TRUE)
   {
   
   //uart_isTransmision_timeout(UART_kbhit_timeout_pointer);
   
   uart_isTransmision_timeout(& UART_kbhit_timeout);
   
   
   
   
   //disable_interrupts(global);
   //int8 answer = OVC_ParseReceivedData();
   
   
   
  int8 answer =parse_received_data(UART_SlaveBuffer, received_data_counter, OVC_parse_data);
   
   //fprintf(Dbg,"ZNALAZ�EM I KONCZE %u\r\n\r\n", answer);  
   
   
   switch(answer){
   
      case   InPairingState:    //State Indication
         fprintf(Dbg,"InPairingStat");
         break;
      case   ExitPairingState:    //State Indication
         fprintf(Dbg,"ExitPairingState");
         break;
      case   Connected:           //State Indication
         fprintf(Dbg,"Connected");
         break;
      case   Disconnected:        //State Indication
         fprintf(Dbg,"Disconnected");
         break;
      case   PhoneHandUp:         //State Indication
         fprintf(Dbg,"PhoneHandUp");
         break;
      case   HFP_ResponseValue:         //AT command response
         fprintf(Dbg,"HFP_ResponseValue");
         break;
      case   A2DP_ResponseValue:        //AT command response
         fprintf(Dbg,"A2DP_ResponseValue");
         break;
      case   AVRCP_ResponseValue:       //AT command response
         fprintf(Dbg,"AVRCP_ResponseValue");
         break;
      case   AudioVolume:               //AT command response
         //vol_val = OVC_ParseReceivedData4Int16();
         
         fprintf(Dbg,"AudioVolum");
         //fprintf(Dbg,":  %Ld", vol_val);
         //OVC_SendATCommand_simple(OVC3860_AV_SOURCE_CONNECT);
         break;
      case   AudioSampleRating:    //State Indication
         fprintf(Dbg,"AudioSampleRating");
         break;
         
         
         
         
///*      
//      case   AudioSampleRating48000:    //State Indication
//         fprintf(Dbg,"AudioSampleRating");
//         break;         
         
//     case   AudioSampleRating44100:    //State Indication
//               fprintf(Dbg,"AudioSampleRating44100");
//         break;
//     case  AudioSampleRating32000:   //State Indication
//               fprintf(Dbg,"AudioSampleRating32000");
//         break;
//      case  AudioSampleRating16000:    //State Indication
//               fprintf(Dbg,"AudioSampleRating16000");
//         break;
//*/
 

    
     
     case   AudioConfigError:          //State Indication
         fprintf(Dbg,"AudioConfigError");
         break;
      case   AudioCodecIsClosed:        //State Indication
         fprintf(Dbg,"AudioCodecIsClosed");
         break;
      case   AudioCodecIsInPhoneCallMode:    //State Indication
         fprintf(Dbg,"AudioCodecIsInPhoneCallMode");
         break;
      case   MusicPause:                //State Indication
         fprintf(Dbg,"MusicPause");
         break;
      case   MusicResume:               //State Indication
         fprintf(Dbg,"MusicResume");
         break;
      case   BackwardSsong:             //State Indication
         fprintf(Dbg,"BackwardSsong");
         break;
      case   ForwardSong:               //State Indication
         fprintf(Dbg,"ForwardSong");
         break;
      case   SPP_Opened:                //State Indication
         fprintf(Dbg,"SPP_Opened");
         break;
      case   SPP_Closed:                //State Indication
         fprintf(Dbg,"SPP_Closed");
         break;
      case   CommandIisError:           //State Indication
         fprintf(Dbg,"CommandIisError");
         break;
      case   NoEeprom:                  //State Indication
         fprintf(Dbg,"NoEeprom");
         break;
      case   ErrorEpromParameter:       //State Indication
         fprintf(Dbg,"ErrorEpromParamete");
         break;
      case   OK_response:               //AT command response
         fprintf(Dbg,"OK_response");
         break;
      case   AudioPausedStop_response:  //AT command response
         fprintf(Dbg,"AudioPausedStop_response");
         break;
      case   AudioPlay_response:        //AT command response
         fprintf(Dbg,"AudioPlay_response");
         break;
      case   EOT:                   //end of table - warto�c steruj�ca oznaczaj�ca koniec tabeli parsowani
         //fprintf(Dbg,"EOT");
         fprintf(Dbg,"EOT");// OVC command unknown\r\n");
         uart_ClearRxParameter();
         break;
      //default:
      //   fprintf(Dbg,"OVC command unknown");
   

   
   }
   //uart_debug_display_data(UART_SlaveBuffer, received_data_counter, display_char); 
   
   uart_ClearRxParameter();


   }
   }
}
