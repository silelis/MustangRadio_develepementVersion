#ifndef ACTIVE_ANTENA


//#define ACTIVE_ANTENA PIN_C5   
   
void        AAntenna_ON                      (void);
void        AAntenna_OFF                     (void);
#endif
