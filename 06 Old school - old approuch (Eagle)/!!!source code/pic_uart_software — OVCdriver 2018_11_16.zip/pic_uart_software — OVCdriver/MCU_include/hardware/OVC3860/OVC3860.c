#ifndef _OVC3860_
   
   #include </OVC3860.h>
   #include </MCU_include/core/UART_engine/UART_Engine.c>
   #include </MCU_include/core/silelis_parser/silelis_parser.c>
   #include <string.h>
   
   enum OVC_STATE_INDICATIONS
       {
         InPairingState=1,    //State Indication
         ExitPairingState,    //State Indication
         Connected,           //State Indication
         Disconnected,        //State Indication
         PhoneHandUp,         //State Indication
         HFP_ResponseValue,         //AT command response
         A2DP_ResponseValue,        //AT command response
         AVRCP_ResponseValue,       //AT command response
         AudioVolume,               //AT command response
         AudioSampleRating,         //State Indication
         //AudioSampleRating48000,    //State Indication
         //AudioSampleRating44100,    //State Indication
         //AudioSampleRating32000,    //State Indication
         //AudioSampleRating16000,    //State Indication
         AudioConfigError,          //State Indication
         AudioCodecIsClosed,        //State Indication
         AudioCodecIsInPhoneCallMode,    //State Indication
         MusicPause,                //State Indication
         MusicResume,               //State Indication
         BackwardSsong,             //State Indication
         ForwardSong,               //State Indication
         SPP_Opened,                //State Indication
         SPP_Closed,                //State Indication
         CommandIisError,           //State Indication
         NoEeprom,                  //State Indication
         ErrorEpromParameter,       //State Indication
         OK_response,               //AT command response
         AudioPausedStop_response,  //AT command response
         AudioPlay_response,        //AT command response
         EOT=0x00                   //end of table - warto�c steruj�ca oznaczaj�ca koniec tabeli parsowania
         
       };


   /////*              ----------------  OVC PARSING TABLE ----------------              */////
   rom char OVC_parse_data[]={
      /*
      
         AA1 = 44800
         AA2 = 44100
         AA4 = 32000
         AA8 = 16000
         AE = config error
         AF = codec closed
         AS = phone call
        
         IC Call-setup status is outgoing
         
         IG ongoing call indication
         IP5 Outgoing call number length indication,IPXX The next or previous PB number length indication, IP<lehgth>: Length of Phone Number
         IR12345 Outgoing call number indication (IP, IR indications only supported by HFP1.5 version.)
         IS
         
         MC Outgoing call number indication (audio transfered from handset(phone?) to module)
         MD The voice is on phone indication ((audio transfered to handset(phone?) from module)
         MGX The HSHF applications state is X indication, 1 � "Ready", 2 � "Connecting", 3 � "Connected", 4 �"outgoing call", 5 �"incoming call",6 � "ongoing call"
         MGXY X and Y are auto answer and auto connect after power on configuration, X:1 � "support auto answer", 0 � "not support auto answer", Y:1 � "support auto connect after power on", 0 � "no
         MFXY Power ON Init Complete Report AutoAnswer and PowerOn Auto Connection Configuration
         PE The voice dial start indication
         PF The voice dial is not supported indication
         PA0 The phone does not support the phone book feature
         PA1 The phone supports the phone book feature
         PBYY The next or previous PB number, PB<phonebook>: One Phonebook Indication
         PC End of Phonebook/Call History
         MN<phone number>, One Phonebook Indication
      */
      
            //Warto�� enum                            D�ugo�� odpowiedzi                  Odpowiedz z OVC - wszystkie obs�ugiwane przez m�j kod zrodlowy mo�liwo�ci
            //ParsingDataArray_EnumCommandPosition    ParsingDataArray_ParsingWordLen     
            //next_Command_addres                     next_Command_len_address            next_Response_BeginAddres
            InPairingState,                           2,                                  'I','I',       //II HSHF enters pairing state, discoverable for 2 minutes
            ExitPairingState,                         3,                                  'I','J','2',   //IJ2 HSHF exits pairing mode and enters listening
            Connected,                                2,                                  'I','V',       // IV HSHF State Is Connected indication
            Disconnected,                             2,                                  'I','A',       //IA HSHF State Is Listening
            PhoneHandUp,                              2,                                  'I','F',       //IF Call-setup status is idle/hang-up indication
            HFP_ResponseValue,                        2,                                  'M','G',
            A2DP_ResponseValue,                       2,                                  'M','U',
            AVRCP_ResponseValue,                      2,                                  'M','L',
            AudioVolume,                              3,                                  'V','O','L',
            AudioSampleRating,                        2,                                  'A','A', 
            //AudioSampleRating48000,                 3,                                  'A','A','1', 
            //AudioSampleRating44100,                 3,                                  'A','A','2',
            //AudioSampleRating32000,                 3,                                  'A','A','4', 
            //AudioSampleRating16000,                 3,                                  'A','A','8',
            AudioConfigError,                         2,                                  'A','E',
            AudioCodecIsClosed,                       2,                                  'A','F', 
            AudioCodecIsInPhoneCallMode,              2,                                  'A','S',
            MusicPause,                               2,                                  'M','P',
            MusicResume,                              2,                                  'M','R', 
            BackwardSsong,                            2,                                  'M','S', 
            ForwardSong,                              2,                                  'M','X', 
            SPP_Opened,                               2,                                  'S','C', 
            SPP_Closed,                               2,                                  'S','D',
            CommandIisError,                          3,                                  'E','R','R',
            NoEeprom,                                 4,                                  'N','O','E','P',
            ErrorEpromParameter,                      4,                                  'E','P','E','R',
            OK_response,                              2,                                  'O','K',
            AudioPausedStop_response,                 2,                                  'M','A',          //MB pause/ stop
            AudioPlay_response,                       2,                                  'M','B',          //MA playing
            EOT//,                                    0,                                  0            //end of table,
                     
      };  
   /////*              ----------------  OVC PARSING TABLE ----------------              */////
   
   void OVC_SendATCommand_simple(char *command)
   {
   //    !!!            UWAGA    UWAGA    UWAGA          !!!
   //
   //    ten spos�b przekazywania string�w wymaga zadeklarowania na samym poczatku:
   //
   //    #device PASS_STRINGS=IN_RAM
   //
   //    !!!            UWAGA    UWAGA    UWAGA          !!!
   
      //UART_ClearMasterBuffer();           //mo�e nie by� potrzebne
      //UART_ClearSlaveBuffers();        //mo�e nie by� potrzebne
      memcpy(UART_MasterBuffer,"AT#", 3);
      memcpy(UART_MasterBuffer+3,command, 2);
      memcpy(UART_MasterBuffer+5,"\r\n", 2);

      for (int i =0; i<7;i++)
      {
         //fprintf(Dbg ,"%c", UART_MasterBuffer[i]);
         fprintf(Hrdw,"%c", UART_MasterBuffer[i]);         
      }  
      
/*   void OVC_SendATCommand_extand(char *command, unsigned int8 command_len)
   {
   //    !!!            UWAGA    UWAGA    UWAGA          !!!
   //
   //    ten spos�b przekazywania string�w wymaga zadeklarowania na samym poczatku:
   //
   //    #device PASS_STRINGS=IN_RAM
   //
   //    !!!            UWAGA    UWAGA    UWAGA          !!!
   
      //UART_ClearMasterBuffer();           //mo�e nie by� potrzebne
      //UART_ClearSlaveBuffers();        //mo�e nie by� potrzebne
      memcpy(UART_MasterBuffer,"AT#", 3);
      memcpy(UART_MasterBuffer+3,command, command_len);
      memcpy(UART_MasterBuffer+3+command_len,"\r\n", command_len);

      for (int i =0; i<5+command_len;i++)
      {
         //fprintf(Dbg ,"%c", UART_MasterBuffer[i]);
         fprintf(Hrdw,"%c", UART_MasterBuffer[i]);         
      } */       
      
      
      
      
   }
   
   void OVC_powerUP(int16 pin)
   {
      output_bit(pin,1);

   
   }
      
      
   void OVC_powerDOWN(int16 pin)
   {
            output_bit(pin,0);
   }
   
#endif
