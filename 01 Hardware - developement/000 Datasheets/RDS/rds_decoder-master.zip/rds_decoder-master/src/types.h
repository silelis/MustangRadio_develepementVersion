#ifndef __TYPES_H__
#define __TYPES_H__

typedef unsigned char uchar;
typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;


#endif
