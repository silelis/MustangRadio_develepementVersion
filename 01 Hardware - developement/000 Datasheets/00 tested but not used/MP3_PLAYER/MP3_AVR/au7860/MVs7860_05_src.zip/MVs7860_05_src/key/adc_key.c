#include "syscfg.h"


#ifdef FUNC_ADC_KEY_EN

#define 	ADC_KEY_SCAN_TIME			20
#define 	ADC_KEY_JITTER_TIME			30
#define 	ADC_KEY_CP_TIME				1000
#define 	ADC_KEY_CPH_TIME				200		//450	


#define		ADC_KEY_COUNT				10

#define		ADC_KEY_COUNT				10 			//key count per adc channel
#define		ADC_KEY_FULL_VAL			4096		//


typedef enum _ADC_KEY_STATE
{
	ADC_KEY_STATE_IDLE,
	ADC_KEY_STATE_JITTER,
	ADC_KEY_STATE_PRESS_DOWN,
	ADC_KEY_STATE_CP

} ADC_KEY_STATE;

TIMER			AdcKeyWaitTimer;
TIMER			AdcKeyScanTimer;
ADC_KEY_STATE	AdcKeyState;
static BYTE		ModeSwitchKeyStatus = 0 ;

//static BYTE		FMSearchChannelKeyStatus = 0 ;
#if 0
static CODE BYTE AdcKeyEvent[][4] = 
{
						//һ���ʱ����		//һֱ����	//�ͷ�
//	SP					CPS					CPH				CPR
	{MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_NONE, 	MSG_NONE			},	//SW3
	{MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_NONE, 	MSG_NONE			},	//SW4
	{MSG_PRE, 			MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_FF_FB_END		},	//SW5
	{MSG_NEXT, 			MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_FF_FB_END		},	//SW6	
	{MSG_PLAY_PAUSE, 	MSG_STOP, 			MSG_NONE, 		MSG_NONE			},	//SW7

	{MSG_STOP, 			MSG_FOLDER_EN, 		MSG_NONE, 		MSG_NONE			},	//SW8
	{MSG_EQ_SW, 		MSG_PARTITION_SW, 	MSG_NONE, 		MSG_NONE			},	//SW9
	{MSG_REPEAT, 		MSG_REPEAT_AB, 		MSG_NONE, 		MSG_NONE			},	//SW10
	{MSG_MUTE, 			MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW11
	{MSG_MODE_SW, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW12
	
	{MSG_NEXT_FOLDER, 	1, 			2, 		3			},	//SW13
	{MSG_PRE_FOLDER, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW14
	{MSG_REC_MODE,		MSG_SPI_REC_MODE,	MSG_NONE, 		MSG_NONE			},	//SW15
	{MSG_REC_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW16
	{MSG_REC_DELETE, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW17
	
	{MSG_BROWSE_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW16
	{MSG_RTC_SW, 	    MSG_RTC_SET, 		MSG_NONE, 		MSG_NONE			},	//SW17    RTC module
	{MSG_RTC_DOWN, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW18
	{MSG_RTC_UP, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE			},	//SW19
	{MSG_ALARM_MODE,	MSG_ALARM_SET, 		MSG_NONE, 		MSG_NONE			},	//SW20

};	
#endif
//#ifdef ORT

//����3�볤��,��5��
static CODE BYTE AdcKeyEvent[][5] = 
{
						//һ���ʱ����		//һֱ����	//�ͷ�
//	SP					CPS					CPH				CPR
	{MSG_PRE, 		MSG_VOL_SUB, 		MSG_VOL_SUB_CP, 		MSG_NO_SHOW_VOLUME		, 	MSG_NONE	},	//SW3
	{MSG_PLAY_PAUSE, 	MSG_STOP, 			MSG_NONE, 		MSG_NONE		, 	MSG_MODE_SW			},	//SW4
	{MSG_NEXT, 		MSG_VOL_ADD, 		MSG_VOL_ADD_CP, 		MSG_NO_SHOW_VOLUME		, 	MSG_NONE		},	//SW4 + 1
	{MSG_NEXT, 		MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_NONE		, 	MSG_NONE		},	//SW4 + 1
	{MSG_NEXT, 			MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_FF_FB_END	, 	MSG_NONE		},	//SW6	
	{MSG_PLAY_PAUSE, 	MSG_STOP, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW7

	{MSG_STOP, 			MSG_FOLDER_EN, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW8
	{MSG_REC_DELETE, 		MSG_PARTITION_SW, 	MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW9
	{MSG_REPEAT, 		MSG_REPEAT_AB, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW10
	{MSG_MUTE, 			MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW11
	{MSG_MODE_SW, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW12
	
	{MSG_NEXT_FOLDER, 	1, 			2, 		3	, 	MSG_NONE			},	//SW13
	{MSG_PRE_FOLDER, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW14
	{MSG_REC_MODE,		MSG_SPI_REC_MODE,	MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW15
	{MSG_REC_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW16
	{MSG_REC_DELETE, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW17
	
	{MSG_BROWSE_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW16
	{MSG_RTC_SW, 	    MSG_RTC_SET, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW17    RTC module
	{MSG_RTC_DOWN, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW18
	{MSG_RTC_UP, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW19
	{MSG_ALARM_MODE,	MSG_ALARM_SET, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW20
	{MSG_BATTERY_CTL,	MSG_BATTERY_CTL, 		MSG_BATTERY_CTL, 		MSG_BATTERY_CTL	, 	MSG_BATTERY_CTL			},	//index 21 ����������

};
#if 0
static CODE BYTE AdcKeyEvent[][5] = 
{
						//һ���ʱ����		//һֱ����	//�ͷ�
//	SP					CPS					CPH				CPR
	{MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_NONE, 	MSG_NONE		, 	MSG_NONE	},	//SW3
	{MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_NONE, 	MSG_NONE		, 	MSG_POWER		},	//SW4
	{MSG_PRE, 			MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_FF_FB_END	, 	MSG_NONE		},	//SW5
	{MSG_NEXT, 			MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_FF_FB_END	, 	MSG_NONE		},	//SW6	
	{MSG_PLAY_PAUSE, 	MSG_STOP, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW7

	{MSG_STOP, 			MSG_FOLDER_EN, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW8
	{MSG_EQ_SW, 		MSG_PARTITION_SW, 	MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW9
	{MSG_REPEAT, 		MSG_REPEAT_AB, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW10
	{MSG_MUTE, 			MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW11
	{MSG_MODE_SW, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW12
	
	{MSG_NEXT_FOLDER, 	1, 			2, 		3	, 	MSG_NONE			},	//SW13
	{MSG_PRE_FOLDER, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW14
	{MSG_REC_MODE,		MSG_SPI_REC_MODE,	MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW15
	{MSG_REC_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW16
	{MSG_REC_DELETE, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW17
	
	{MSG_BROWSE_START, 	MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW16
	{MSG_RTC_SW, 	    MSG_RTC_SET, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW17    RTC module
	{MSG_RTC_DOWN, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW18
	{MSG_RTC_UP, 		MSG_NONE, 			MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW19
	{MSG_ALARM_MODE,	MSG_ALARM_SET, 		MSG_NONE, 		MSG_NONE	, 	MSG_NONE			},	//SW20

}
#endif
// Key process, image key value to key event.
static BYTE AdcChannelKeyGet(BYTE Channel)							
{
	WORD	Val;
	BYTE	KeyIndex;
	
	Val = AdcReadOneChannel(Channel, ADC_VREF_AVDD33);
	if(Val >= (ADC_KEY_FULL_VAL - (ADC_KEY_FULL_VAL/ADC_KEY_COUNT)/2))
	{
	 	return -1;	//no pressed key.
	}
	KeyIndex = (Val + (ADC_KEY_FULL_VAL/ADC_KEY_COUNT)/2)*ADC_KEY_COUNT/ADC_KEY_FULL_VAL;

	return KeyIndex;
}


static BYTE GetAdcKeyIndex()
{

#ifdef ORT
	BYTE KeyIndex = AdcChannelKeyGet(ADC_CHANNEL_E4);
#else
	BYTE KeyIndex = AdcChannelKeyGet(ADC_CHANNEL_E2);
	if(KeyIndex == -1)
	{
		KeyIndex = AdcChannelKeyGet(ADC_CHANNEL_E3);
		if(KeyIndex != -1)
		{
			KeyIndex += ADC_KEY_COUNT ;
		}
	}
#endif

	
	return KeyIndex;
}


// Initialize hardware key scan (GPIO) operation.
VOID AdcKeyScanInit()
{
	AdcKeyState = ADC_KEY_STATE_IDLE;
	TimeOutSet(&AdcKeyScanTimer, 0);

	
#ifdef ORT	
	SET_E4_ADC_IN();

	
#else
	SET_E2_ADC_IN();
	SET_E3_ADC_IN();
#endif
}


// Key process, image key value to key event.
BYTE AdcKeyEventGet()							
{
	static 	BYTE 	PreKeyIndex = -1;
	BYTE			KeyIndex;
//	BYTE		event = MSG_NONE;
	static	BYTE	CPHCnt = 0 ;
//	DBG(("AdcKeyEventGet*******\n"));
	if(!IsTimeOut(&AdcKeyScanTimer))
	{
		return MSG_NONE;
	}
	TimeOutSet(&AdcKeyScanTimer, ADC_KEY_SCAN_TIME);	

	KeyIndex = GetAdcKeyIndex();

	
	
	switch(AdcKeyState)
	{
		case ADC_KEY_STATE_IDLE:
			
			CPHCnt = 0 ;
			if(KeyIndex == -1)
			{
				return MSG_NONE;
			}
			ModeSwitchKeyStatus = 0 ;
			PreKeyIndex = KeyIndex;				
			TimeOutSet(&AdcKeyWaitTimer, ADC_KEY_JITTER_TIME);
			
			//DBG(("GOTO JITTER!\n"));
			AdcKeyState = ADC_KEY_STATE_JITTER;
				
		case ADC_KEY_STATE_JITTER:			
			CPHCnt = 0 ;
			if(PreKeyIndex != KeyIndex)
			{				
				AdcKeyState = ADC_KEY_STATE_IDLE;				
			}
			else if(IsTimeOut(&AdcKeyWaitTimer))
			{				
 				TimeOutSet(&AdcKeyWaitTimer, ADC_KEY_CP_TIME);
				AdcKeyState = ADC_KEY_STATE_PRESS_DOWN;				
			}
			break;

		case ADC_KEY_STATE_PRESS_DOWN:
			CPHCnt = 0 ;
			if(PreKeyIndex != KeyIndex)
			{
				//return key sp value
				//DBG(("ADC KEY SP%bu\n",PreKeyIndex));
				AdcKeyState = ADC_KEY_STATE_IDLE;
				return AdcKeyEvent[PreKeyIndex][0];
			}
			else if(IsTimeOut(&AdcKeyWaitTimer))
			{				
				TimeOutSet(&AdcKeyWaitTimer, ADC_KEY_CPH_TIME);
				AdcKeyState = ADC_KEY_STATE_CP;
				return AdcKeyEvent[PreKeyIndex][1];
			}
			break;

		case ADC_KEY_STATE_CP:
			if(PreKeyIndex != KeyIndex)
			{
				//return key cp value
				//DBG(("ADC KEY CPR!\n"));
				CPHCnt = 0 ;
				AdcKeyState = ADC_KEY_STATE_IDLE;
				return AdcKeyEvent[PreKeyIndex][3];
			}
			else if(IsTimeOut(&AdcKeyWaitTimer))
			{
				//return key cph value
				//DBG(("ADC KEY CPH!\n"));
				CPHCnt++ ;
				if(  1 == KeyIndex   )
				{
					if( ( 4 <= CPHCnt ) && (0 == ModeSwitchKeyStatus  ) )
					{
						ModeSwitchKeyStatus = 1 ;		//�ñ��ȷ��ģʽ�л��¼���Ϣֻ��һ��
						//DBG(("tttttttttttttttttttttttttttttttttttttttttttttttt *********************\n"));
						TimeOutSet(&AdcKeyWaitTimer, ADC_KEY_CPH_TIME);
						return AdcKeyEvent[PreKeyIndex][4];	
					}
				}
				else
				{
					TimeOutSet(&AdcKeyWaitTimer, ADC_KEY_CPH_TIME);
					return AdcKeyEvent[PreKeyIndex][2];
				}
			
			}
			break;

		default:
			AdcKeyState = ADC_KEY_STATE_IDLE;
			break;
	}
	return MSG_NONE;

}
#else
	#warning	"MV: ADC KEY NOT ENABLE!"
#endif
