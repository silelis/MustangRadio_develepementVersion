#include "syscfg.h"
#include "spi_flash.h"


#ifdef FUNC_SPI_FLASH_EN

	
static BOOL SpiFlashLinkFlag = FALSE;


// SPI flash (serial flash) command set, the name is compatiable with four kinds of serial flash . 
//like GD,MX,WINBOND,SST etc. Different instruction maybe work in different frequence, so please check it before use it.

#define		FLASH_BP			0x02	//To program one data byte
#define		FLASH_READ			0x03	//Read
#define		FLASH_RDID			0x9F	//Read-ID
#define		FLASH_WREN			0x06	//Write-Enable
#define		FLASH_WRDI			0x04	//Write-Disable
#define		FLASH_RDSR			0x05	//Read status register
#define		FLASH_WRSR			0x01	//Write status register
#define		FLASH_SE			0x20	//Erase sector of memory array
#define		FLASH_CE			0xC7	//Chip-Erase erase full Memory Array 
#define		FLASH_BE			0xD8	//Block-Erase Memory Array. for sst use this instrction can erase 64Kbyte block

//These instructions just sst have.
#define		FLASH_AAI			0xAD	//Auto Address increment programming
#define		FLASH_EWSR			0x50	//Enable writer state register


// SPI flash CS pin operation.
#define		SpiFlashCsAssert()		ClrGpioRegBit(SPI_FLASH_CS_PORT_OUT, SPI_FLASH_CS_BIT)
#define		SpiFlashCsDeassert()	SetGpioRegBit(SPI_FLASH_CS_PORT_OUT, SPI_FLASH_CS_BIT)

// SST Status Register bit.
#define	SPITESTADDR	0x0123
#define	BPL		0x80
#define	BP3		0x20
#define	BP2		0x10
#define	BP1		0x08
#define	BP0		0x04


//Read serial flash Manufacturer's ID and deviceID.
VOID SpiFlashIdRd()
{
	BYTE Mid;		//Manufacturer's ID
	WORD Did;		//Device ID

	SpiFlashCsAssert();		
	SpiSendByte(FLASH_RDID);		
	Mid = SpiRecvByte();	
	BYTE0(Did) = SpiRecvByte();   //just need the manfacture's ID
	BYTE1(Did) = SpiRecvByte();
	SpiFlashCsDeassert();
	if((Mid == 0x00) || (Mid == 0xFF))
	{
		SpiFlashLinkFlag = FALSE;
	}
	else
	{
		SpiFlashLinkFlag = TRUE;
	}
	DBG(("FlashID:0x%-.2BX\n", Mid));
}


//Inital SPI device structure.
VOID SpiFlashInit()
{
	SpiFlashCsDeassert();
	SetGpioRegBit(SPI_FLASH_CS_PORT_OE, SPI_FLASH_CS_BIT);
	SET_B4B5B6_SPI_BUS();
	SpiOpen(0, 1);	
	
	SpiFlashIdRd();
}


//Write Status Register.	  
//Bit7--6--5---4---3---2---1---0 
//BPL AAI BP3 BP2 BP1 BP0 WEL BUSY
VOID SpiFlashWriteStatus(BYTE Status)
{
	SpiFlashCsAssert();	
	SpiSendByte(FLASH_EWSR);
	SpiFlashCsDeassert();

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_WRSR);
	SpiSendByte(Status);
	SpiFlashCsDeassert();
}


//Read data to memory from spi flash.
VOID SpiFlashRead(DWORD StartAddr, BYTE* Buffer, WORD Len)
{
	SpiFlashCsAssert();	
	SpiSendByte(FLASH_READ);
	SpiSendByte(BYTE1(StartAddr));	
	SpiSendByte(BYTE2(StartAddr));	
	SpiSendByte(BYTE3(StartAddr));

	while(Len--)
	{
		*(Buffer++) = SpiRecvByte();
	}
	SpiFlashCsDeassert();
}


//Write data to spi flash from memory.
BOOL SpiFlashWrite(DWORD StartAddr, BYTE* Buffer, WORD Len)
{
	//ע�⣺
	//������ֻ������SST����AAI��ʽ��SPI FLASHоƬ��
	//���ʹ���������̵�SPI FLASHоƬ����ͻ�Ҫ��д��������

	//Write enable
	SpiFlashCsAssert();	
	SpiSendByte(FLASH_WREN);
	SpiFlashCsDeassert();

	SpiFlashCsAssert();	
	SpiSendByte(0xAD);
	SpiSendByte(BYTE1(StartAddr));	
	SpiSendByte(BYTE2(StartAddr));	
	SpiSendByte(BYTE3(StartAddr));
	if(Len)
	{
		SpiSendByte(*(Buffer++));
		Len--;
	}	
	if(Len)
	{
		SpiSendByte(*(Buffer++));
		Len--;
	}	
	
	SpiFlashCsDeassert();

	while(Len--)
	{
		SpiFlashCsAssert();	
		SpiSendByte(0xAD);
		SpiSendByte(*(Buffer++));		
		if(Len)
		{
			SpiSendByte(*(Buffer++));	
			Len--; 	
		}
		SpiFlashCsDeassert();	
	}

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_WRDI);	
	SpiFlashCsDeassert();

	return TRUE;
}


//Erase sector, sector size is 4KB. 
BOOL SpiFlashStartSectorErase()
{
//	DBG(("sector erase...\n"));

	SpiFlashWriteStatus(~(BPL | BP3 | BP2 | BP1 | BP0));

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_WREN);
	SpiFlashCsDeassert();

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_CE);
	SpiFlashCsDeassert();
	
//	while(SpiFlashIsBusy());

	return TRUE;
}


//Erase chip.
BOOL SpiFlashStartChipErase()
{
//	DBG(("chip erase...\n"));

	SpiFlashWriteStatus(~(BPL | BP3 | BP2 | BP1 | BP0));

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_WREN);
	SpiFlashCsDeassert();

	SpiFlashCsAssert();	
	SpiSendByte(FLASH_CE);
	SpiFlashCsDeassert();
	
//	while(SpiFlashIsBusy());

	return TRUE;
}


//Get busy status.
BOOL SpiFlashIsBusy()
{
	SpiFlashCsAssert();
	SpiSendByte(FLASH_RDSR);
	if((SpiRecvByte() & 0x01) == 0x00)
	{
		SpiFlashCsDeassert();
		return FALSE;
	}	
	SpiFlashCsDeassert();
	return TRUE;
}


//Get link status.
BOOL SpiFlashIsLink()
{
	return SpiFlashLinkFlag;
}


#endif