#ifndef _USB_IPOD_CTRL_H_
#define _USB_IPOD_CTRL_H_


//initial usb ipod device. 
BOOL UsbIpodCtrlInit();

//end usb ipod device.
VOID UsbIpodCtrlEnd();

//usb ipod device state control.
VOID UsbIpodStateCtrl();

#endif
