#ifndef _PARTITION_H_
#define _PARTITION_H_


BOOL PartitionLoad();

#endif
