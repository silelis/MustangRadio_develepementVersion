#ifndef _CARD_H_
#define _CARD_H_


typedef struct _CARD_INFO
{  
	BYTE	MID;			// Manufacturer ID
	BYTE	OID[2];			// OEM/Application ID
	BYTE	PNM[5];			// Product name
	BYTE	PRV;			// Product revision
	BYTE	PSN[4];			// Product serial number
	WORD	Rsv : 4;		// reserved
	WORD	MDT : 12;		// Manufacturing date
	BYTE	CRC : 7;		// CRC7 checksum
	BYTE	NoUse : 1;		// not used, always 1

} CARD_INFO;


extern CARD_INFO	gLibCardInfo;


// SD mode initialize card.
VOID CardOpen();

// Polling card insert and pull out.
BOOL CardInit();							

// Read card stor block
BOOL ReadCardStorBlock(DWORD block, WORD buffer, BYTE size);

// Write card stor block.
BOOL WriteCardStorBlock(DWORD block, WORD buffer, BYTE size);

// Card detect, to check card whether insert or pull out.
BOOL CardDetect();

//��ȡ����BLOCK����
DWORD CardGetBlockNum();

#endif
