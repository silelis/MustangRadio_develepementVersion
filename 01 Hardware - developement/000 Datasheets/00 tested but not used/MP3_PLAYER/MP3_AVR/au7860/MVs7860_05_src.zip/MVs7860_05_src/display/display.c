#include "syscfg.h"


//AU7860  Display Port Define as below:
//Pin	1	2	3	4	5	6	7	8	9	 10	  11   12	13   14		 	BLINK_CLN
//	    A	B	C	D	E	F	G	H  	I	 COM5 COM4 COM3 COM2 COM1		H-COM1    
//IO:	B0	B1	B2	B3	B4	B5	B6	B7	D2	 D3	  D4   D5	D6	 D7			B7

#define LCD_COM_NUM			5
#define LCDMASKSEG			0x00FF//0x02FF//5*9
#define LCDMASKCOM			0x7C00

#ifdef FUNC_DISP_EN

BYTE LCDbuf[LCD_COM_NUM];
//WORD LCDbuf[LCD_COM_NUM];


VOID DispInit()
{
	DBG(("->DispInit\n"));
	memset(LCDbuf, 0, sizeof(LCDbuf));	//�������㣬
	LcdInit(LCDMASKSEG, LCDMASKCOM, LCD_BIAS_3, VLCD_3V3);
	// COM3,LCD CH7����˸,��˸���0.5��(1����˸һ��).
	LcdBlinkCtrl(5, 7, 3);
	StrDisp("LOAD");
	LcdSetData((BYTE *)LCDbuf);				// �ϵ�����ʾ"LOAD"
}


VOID Display()
{


}

#endif
