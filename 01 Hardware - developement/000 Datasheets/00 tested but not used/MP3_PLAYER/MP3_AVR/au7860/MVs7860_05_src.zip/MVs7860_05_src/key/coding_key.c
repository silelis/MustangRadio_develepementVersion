#include "syscfg.h"


#ifdef FUNC_CODING_KEY_EN


//clockwise rotation
//    ----|		   |--------|		 |-------------------
//A       |        |        |        |
//        |--------|        |--------|

//     -------|        |--------|		 |---------------
//B           |        |        |		 |
//            |--------|        |--------|


//counterclockwise rotation
//    --------|		   |--------|		 |---------------
//A           |		   |        |		 |
//            |--------|        |--------|

//     ---|        |--------|		 |-------------------
//B       |        |        |		 |
//        |--------|        |--------|


static BYTE		ClockWiseCnt;
static BYTE		CounterClockWiseCnt;


// Initialize coding key scan (GPIO) operation.
// Config interrupt at negative edge of signal-A 
VOID CodingKeyScanInit()
{
	//enable pull up resister.
	ClrGpioRegBit(GPIO_C_PU, CODING_KEY_A_BIT);		//interrupt at negative edge of signal-A
	ClrGpioRegBit(GPIO_C_PD, CODING_KEY_A_BIT);		//interrupt at negative edge of signal-A
	ClrGpioRegBit(GPIO_C_OE, CODING_KEY_A_BIT);		//interrupt at negative edge of signal-A

	ClrGpioRegBit(CODING_KEY_B_PORT_PU, CODING_KEY_B_BIT);		//interrupt at negative edge of signal-A
	ClrGpioRegBit(CODING_KEY_B_PORT_PD, CODING_KEY_B_BIT);		//interrupt at negative edge of signal-A
	ClrGpioRegBit(CODING_KEY_B_PORT_OE, CODING_KEY_B_BIT);		//interrupt at negative edge of signal-A

	//interrupt at negative edge of signal-A
	ClrGpioRegBit(GPIO_C_PTRIG, CODING_KEY_A_BIT);		//interrupt at negative edge of signal-A
	SetGpioRegBit(GPIO_C_INTE, CODING_KEY_A_BIT);		//enable signal-A interrup
	SetGpioReg(GPIO_C_CTRL, 0x01);	//enable interrupt

	ClockWiseCnt = 0;
	CounterClockWiseCnt = 0;
}


// Key process, image key value to key event.
BYTE CodingKeyEventGet() 
{
 	BYTE event = MSG_NONE;

	if(ClockWiseCnt)
	{
		DBG(("MSG_VOL_ADD\n"));
		event = MSG_VOL_ADD;
	}
	else if(CounterClockWiseCnt)
	{
		DBG(("MSG_VOL_SUB\n"));
		event = MSG_VOL_SUB;
	}
	ClockWiseCnt = 0;
	CounterClockWiseCnt = 0;
	return event; 
}


// Coding key signal-A interrupt.
VOID CodingKeyInterrupt()					
{	
	if((baGPIOCtrl[GPIO_C_IN] & CODING_KEY_A_BIT)
		||(ClockWiseCnt != 0)
		||(CounterClockWiseCnt != 0))
	{
		return;
	}

	if(baGPIOCtrl[CODING_KEY_B_PORT_IN] & CODING_KEY_B_BIT)	
	{ 
		//clockwise rotation
		ClockWiseCnt++;
	}
	else	
	{
		//counterclockwise rotation
		CounterClockWiseCnt++;
	}
}

#endif



