#ifndef _TYPE_H_
#define _TYPE_H_


#define FALSE				0
#define TRUE				1

#define	XDATA				xdata
#define	DATA				data
#define	CODE				code


#define BYTE0(val)			(((BYTE*)(&val))[0])
#define BYTE1(val)			(((BYTE*)(&val))[1])
#define BYTE2(val)			(((BYTE*)(&val))[2])
#define BYTE3(val)			(((BYTE*)(&val))[3])

#define WORD0(val)			(((WORD*)(&val))[0])
#define WORD1(val)			(((WORD*)(&val))[1])



typedef void				VOID;
typedef char				BOOL;

typedef unsigned char		BYTE;
typedef signed char 		SBYTE;

typedef unsigned short		WORD;
typedef signed int			SWORD;

typedef unsigned long		DWORD;
typedef signed long			SDWORD;


#define XBYTE 				((BYTE volatile XDATA*) 0)
#define CBYTE 				((BYTE volatile CODE*) 0)


#endif

