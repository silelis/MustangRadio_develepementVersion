#ifndef _CARD_READER_CTRL_H_
#define _CARD_READER_CTRL_H_

//mass-storage device initial
VOID DeviceStorCtrlInit();

//mass-storage device initial
VOID DeviceStorCtrlEnd();

//mass-storage device process
VOID DeviceStorStateCtrl();

#endif
