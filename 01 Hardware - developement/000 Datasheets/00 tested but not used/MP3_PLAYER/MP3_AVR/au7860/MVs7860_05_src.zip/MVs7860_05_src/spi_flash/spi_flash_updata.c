#include "syscfg.h"
#include "spi_flash.h"
#include "file.h"

//Download MVF to SPI flash

#ifdef	FUNC_SPI_UPDATE_EN

BOOL gIsMVFFileFind;
FILE gUpdataFile;

VOID DownloadMVFToFsh()
{
	WORD	Len;
	DWORD	WriteAddr = 0;

	DBG(("DownloadMVFToFsh()\n"));
			
	DBG(("erase start...\n"));
	SpiFlashStartChipErase();
	while(SpiFlashIsBusy())
	{
		FeedWatchDog();
	}
	DBG(("erase end!\n"));

	while(!FileEOF(&gUpdataFile))
	{
		FeedWatchDog();
		
		if((Len = FileRead(&gUpdataFile, DIR_BUFFER, 512*3)) == 0)
		{
			DBG(("DownloadMVFToFsh,ReadFile Failed!\n"));
			return;
		}
			
		SpiFlashWrite(WriteAddr, (BYTE XDATA*)DIR_BUFFER, Len);
		WriteAddr += Len;
		DBG(("%ld%%\n", (WriteAddr*100UL)/gUpdataFile.Size));
	}
	DBG(("updata complete!\n"));
}

#endif
