#include "syscfg.h"
#include "sysctrl.h"
#include "ipod_usb.h"
#include "ipod_auth.h"
#include "audio_stream.h"
#include "usb_ipod_browser.h"
#include "usb_ipod_cmd.h"

#ifdef FUNC_USB_IPOD_EN

extern BYTE IpodRespBuf[];


//lingo 0x00
BYTE CODE EnterRemoteUIMode[] 				= {0x00, 0x05};		//deprecated ����warning�����Խ���
BYTE CODE ExitExtendedInterfaceMode[] 		= {0x00, 0x06};
BYTE CODE SetUIMode[] 						= {0x00, 0x37, 0x01};
BYTE	  SetEventNotification[] 			= {0x00, 0x49, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
BYTE CODE GetSupportedEventNotification[] 	= {0x00, 0x4F};

//lingo 0x02
BYTE CODE ContextButtonStatus_Stop[] 		= {0x02, 0x00, 0x80};
BYTE CODE ContextButtonStatus_PlayPause[] 	= {0x02, 0x00, 0x01};
BYTE CODE ContextButtonStatus_Pause[] 		= {0x02, 0x00, 0x00, 0x02};
BYTE CODE ContextButtonStatus_NextTrack[]	= {0x02, 0x00, 0x08};
BYTE CODE ContextButtonStatus_PreTrack[]	= {0x02, 0x00, 0x10};
BYTE CODE ContextButtonStatus_StartFF[]		= {0x02, 0x00, 0x00, 0x00, 0x10};
BYTE CODE ContextButtonStatus_StartFB[]		= {0x02, 0x00, 0x00, 0x00, 0x20};
BYTE CODE ContextButtonStatus_AllUp[]		= {0x02, 0x00, 0x00, 0x00, 0x00, 0x00};
BYTE CODE ContextButtonStatus_PlayResume[]	= {0x02, 0x00, 0x00, 0x01};

//lingo 0x03
BYTE CODE SetRemoteEventNotification[] 		= {0x03, 0x08, 0x00, 0x00, 0x81, 0x8A};
BYTE 	  GetTrackTitle[] 					= {0x03, 0x12, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};	
BYTE 	  GetTrackArtist[] 					= {0x03, 0x12, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};	
BYTE 	  GetTrackAlbum[] 					= {0x03, 0x12, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};	

//BYTE CODE SetPlayStatus_Stopped[] 			= {0x03, 0x0E, 0x03, 0x00};	
//BYTE CODE SetPlayStatus_Playing[] 			= {0x03, 0x0E, 0x03, 0x01};	
//BYTE CODE SetPlayStatus_Paused[] 			= {0x03, 0x0E, 0x03, 0x02};	
//BYTE CODE SetPlayStatus_FF[] 				= {0x03, 0x0E, 0x03, 0x03};	
//BYTE CODE SetPlayStatus_FB[] 				= {0x03, 0x0E, 0x03, 0x04};	
//BYTE CODE SetPlayStatus_EndFF_FB[] 			= {0x03, 0x0E, 0x03, 0x05};	

//lingo 0x04
BYTE CODE GetAudiobookSpeed[] 				= {0x04, 0x09};
BYTE	  ResetDBSelection[] 				= {0x04, 0x16};
BYTE	  SelectDBRecord[] 					= {0x04, 0x17, 0x05, 0x00, 0x00, 0x00, 0x00};
BYTE	  GetNumberCategorizedDBRecords[]	= {0x04, 0x18, 0x05};
BYTE	  RetrieveCategorizedDBRecords[]	= {0x04, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01};

BYTE CODE GetPlayStatus[] 					= {0x04, 0x1C};
BYTE CODE GetCurrentPlayingTrackIndex[] 	= {0x04, 0x1E};

BYTE	  GetIndexedPlayingTrackTitle[] 	= {0x04, 0x20, 0x00, 0x00, 0x00, 0x00};
BYTE	  GetIndexedPlayingTrackArtistName[]= {0x04, 0x22, 0x00, 0x00, 0x00, 0x00};
BYTE	  GetIndexedPlayingTrackAlbumName[] = {0x04, 0x24, 0x00, 0x00, 0x00, 0x00};

BYTE CODE SetPlayStatusChangeNotification[] = {0x04, 0x26, 0x00, 0x00, 0x08, 0x01};
//BYTE CODE PlayCurrentSelection[] 			= {0x04, 0x28, 0x00, 0x00, 0x00, 0x00};		//deprecated

BYTE CODE PlayCtrl_PlayPause[]				= {0x04, 0x29, 0x01};
BYTE CODE PlayCtrl_Stop[]					= {0x04, 0x29, 0x02};
//BYTE CODE PlayCtrl_NextTrack[]			= {0x04, 0x29, 0x03};	//deprecated
//BYTE CODE PlayCtrl_PrevTrack[]			= {0x04, 0x29, 0x04};	//deprecated
BYTE CODE PlayCtrl_StartFF[]				= {0x04, 0x29, 0x05};
BYTE CODE PlayCtrl_StartRew[]				= {0x04, 0x29, 0x06};
BYTE CODE PlayCtrl_EndFF_Rew[]				= {0x04, 0x29, 0x07};
BYTE CODE PlayCtrl_Next[]					= {0x04, 0x29, 0x08};
BYTE CODE PlayCtrl_Prev[]					= {0x04, 0x29, 0x09};
BYTE CODE PlayCtrl_Play[]					= {0x04, 0x29, 0x0A};
BYTE CODE PlayCtrl_Pause[]					= {0x04, 0x29, 0x0B};
BYTE CODE PlayCtrl_NextChapter[]			= {0x04, 0x29, 0x0C};
BYTE CODE PlayCtrl_PreChapter[]				= {0x04, 0x29, 0x0D};

BYTE CODE GetShuffle[] 						= {0x04, 0x2C};
BYTE	  SetShuffle[] 						= {0x04, 0x2E, 0x01, 0x00};
BYTE CODE GetRepeat[] 						= {0x04, 0x2F};
BYTE	  SetRepeat[] 						= {0x04, 0x31, 0x00};
	
BYTE CODE GetNumPlayingTracks[] 			= {0x04, 0x35};
BYTE      SetCurrentPlayingTracks[] 		= {0x04, 0x37, 0x00, 0x00, 0x00, 0x00};

BYTE CODE GetColorDisplayImageLimits[] 		= {0x04, 0x39};
BYTE CODE ResetDBSelectionHierarchy[] 		= {0x04, 0x3B, 0x01};
								

//lingo 0x0A
BYTE CODE RetAccSampleRateCaps[] 			= {0x0A, 0x03, 0x00, 0x00, 0x7D, 0x00, 0x00, 0x00, 0xAC, 0x44, 0x00, 0x00, 0xBB, 0x80};


BOOL IpodIsExtendedUIMode;					//��ǰ�Ƿ���Extendedģʽ��־
WORD IpodTotalDBTrackNum;					//DataBase Engine�е�����Ŀ��
WORD IpodTotalTrackNum;						//PlayBack Engine�е�����Ŀ��
WORD IpodCurrentTrackIndex;					//��ǰ���ڲ��ŵ���Ŀ��������



//////////////////////Image��ʾ///////////////////////////////////////////////////////////////////////////

//��IPOD�豸����ʾһ��ͼƬ
VOID IpodSetImage()
{
	//һ�����ص�ռ�����ֽڣ�IPOD_RGB�꽫RGB��ɫ�����ϲ���һ��WORD������ֵ
	#define IPOD_RGB(red, green, blue)	(((red & 0x1F) << 3) | ((green & 0x1C) << 11) | ((green & 0x03) << 1)| ((blue & 0x1F) << 8))
	#define IPOD_IMAGE_WIDTH	130
	#define IPOD_IMAGE_HEIGHT	60
	BYTE ImageBuf[IPOD_IMAGE_WIDTH*2+4];
	BYTE i;
	BYTE j;
	BYTE CODE SetDisplayImageFormat[] = 
	{
		0x04, 
		0x32, 
		0x00, 
		0x00, 
		0x02,				//RGB 565 color, little-endian, 16bpp 
		0x00, 
		IPOD_IMAGE_WIDTH,	//ͼƬ����Ϊ128�� 
		0x00, 
		IPOD_IMAGE_HEIGHT,	//ͼƬ�߶�Ϊ80�� 
		0x00, 
		0x00, 
		(IPOD_IMAGE_WIDTH*2) >> 8,	 
		(IPOD_IMAGE_WIDTH*2) & 0xFF
	};

	IPOD_SendCmdAndWaitResp(GetColorDisplayImageLimits, sizeof(GetColorDisplayImageLimits), 500);

	//��һ�����ݰ�ֻ����ͼ�θ�ʽ
	IPOD_SendCmdAndWaitAck(SetDisplayImageFormat, sizeof(SetDisplayImageFormat), 500);
	
	//ÿ��ѭ������һ�е�ͼ�����ݣ�ÿ����ռ�������ֽ�	
	for(i = 1; i <= IPOD_IMAGE_HEIGHT; i++)
	{
		ImageBuf[0] = 0x04;
		ImageBuf[1] = 0x32;
		ImageBuf[2] = 0x00;
		ImageBuf[3] = i;		

		//ͨ�������г�һ����ɫ����ĺ�����ͼ��
		for(j = 0; j < IPOD_IMAGE_WIDTH; j++)
		{	
			*((WORD*)(&ImageBuf[2*j + 4])) = IPOD_RGB(i/2, i/4, i/8);
		}
 
		IPOD_SendCmdAndWaitAck(ImageBuf, IPOD_IMAGE_WIDTH*2 + 4, 500);
	}
}


////IPOD������TITLE��ARTIST��ALBUM����Ϣ��UTF8����ģ�������û�а���UTF8����������������DEBUGʱʹ�á�
//VOID DispUnicodeString(BYTE* Str1, BYTE* Str2)
//{
//	DBG(("%s: (%s)", Str1, Str2));
////	while((Str2[0] != 0x00) || (Str2[1] != 0x00))
////	{
////		DBG(("%-.2BX %-.2BX ", Str2[0], Str2[1]));
////		Str2 += 2;
////	}
//	DBG(("\n"));
//}


//////////////////////��ȡ������Ϣ///////////////////////////////////////////////////////////////////////////
//�������IPOD��ȡTITLE��ARTIST��ALBUM
BOOL IpodGetSongTitle(WORD TrackIndex, BYTE* Buf, BYTE MaxLen)
{
	memset(Buf, 0x00, MaxLen);

	//TITLE
	GetTrackTitle[5] = BYTE0(TrackIndex);
	GetTrackTitle[6] = BYTE1(TrackIndex);
	if(IPOD_SendCmdAndWaitResp(GetTrackTitle, sizeof(GetTrackTitle), 500))
	{
	 	//���յ�TITLE
		if(IpodRespBuf[0] > 3)
		{
			IpodRespBuf[0] -= 3;
			memcpy(Buf, &IpodRespBuf[4], (IpodRespBuf[0] > MaxLen) ? MaxLen : IpodRespBuf[0]);
			return TRUE;
		}
	}
	return FALSE;
}


//�������IPOD��ȡARTIST
BOOL IpodGetSongArtist(WORD TrackIndex, BYTE* Buf, BYTE MaxLen)
{
	memset(Buf, 0x00, MaxLen);

	//TITLE
	GetTrackArtist[5] = BYTE0(TrackIndex);
	GetTrackArtist[6] = BYTE1(TrackIndex);
	if(IPOD_SendCmdAndWaitResp(GetTrackArtist, sizeof(GetTrackArtist), 500))
	{
	 	//���յ�TITLE
		if(IpodRespBuf[0] > 3)
		{
			IpodRespBuf[0] -= 3;
			memcpy(Buf, &IpodRespBuf[4], (IpodRespBuf[0] > MaxLen) ? MaxLen : IpodRespBuf[0]);
			return TRUE;
		}
	}
	return FALSE;
}


//�������IPOD��ȡALBUM
BOOL IpodGetSongAlbum(WORD TrackIndex, BYTE* Buf, BYTE MaxLen)
{
	memset(Buf, 0x00, MaxLen);

	//TITLE
	GetTrackAlbum[5] = BYTE0(TrackIndex);
	GetTrackAlbum[6] = BYTE1(TrackIndex);
	if(IPOD_SendCmdAndWaitResp(GetTrackAlbum, sizeof(GetTrackAlbum), 500))
	{
	 	//���յ�TITLE
		if(IpodRespBuf[0] > 3)
		{
			IpodRespBuf[0] -= 3;
			memcpy(Buf, &IpodRespBuf[4], (IpodRespBuf[0] > MaxLen) ? MaxLen : IpodRespBuf[0]);
			return TRUE;
		}
	}
	return FALSE;
}


//////////////////////DataBase Engine��������///////////////////////////////////////////////////////////////////////////
//��λ���ݿ�
VOID IpodResetDBSelection()
{
	IPOD_SendCmdAndWaitAck(ResetDBSelection, sizeof(ResetDBSelection), 500);
}


//ѡ��ĳ����¼
VOID IpodSelectDBRecord(BYTE DataBaseType, WORD RecordIndex)
{
	SelectDBRecord[2] = DataBaseType;
	if(RecordIndex == -1)
	{
		SelectDBRecord[3] = 0xFF;
		SelectDBRecord[4] = 0xFF;
	}
	else
	{
		SelectDBRecord[3] = 0x00;
		SelectDBRecord[4] = 0x00;
	}
	SelectDBRecord[5] = BYTE0(RecordIndex);
	SelectDBRecord[6] = BYTE1(RecordIndex);

	IPOD_SendCmdAndWaitAck(SelectDBRecord, sizeof(SelectDBRecord), 500);
}

//��ȡĳ������ļ�¼��Ŀ
WORD IpodGetDBRecordsNum(BYTE DataBaseType)
{
	GetNumberCategorizedDBRecords[2] = DataBaseType;
	if(IPOD_SendCmdAndWaitResp(GetNumberCategorizedDBRecords, sizeof(GetNumberCategorizedDBRecords), 500))
	{
		return (IpodRespBuf[5]*256 + IpodRespBuf[6]);		
	}
	return 0;
}


//��ȡһ����¼��ALBUM��ARTIST��SONG�ȶ�ͳһʹ���������
//StartIndex��0��ʼ
//RecordBuf[]����������IPOD_MAX_TAG_LEN+2�ֽ�
BOOL IpodGetDBRecord(BYTE DataBaseType, WORD StartIndex, BYTE* RecordBuf, BYTE MaxBufLen)
{
	memset(RecordBuf, 0x00, MaxBufLen);
	RetrieveCategorizedDBRecords[2] = DataBaseType;
	RetrieveCategorizedDBRecords[5] = BYTE0(StartIndex);
	RetrieveCategorizedDBRecords[6] = BYTE1(StartIndex);
	if(IPOD_SendCmdAndWaitResp(RetrieveCategorizedDBRecords, sizeof(RetrieveCategorizedDBRecords), 500))
	{
		if(IpodRespBuf[0] > 6)
		{
			IpodRespBuf[0] -= 6;
			memcpy(RecordBuf, &IpodRespBuf[7], (IpodRespBuf[0] > MaxBufLen) ? MaxBufLen : IpodRespBuf[0]);
			DBG(("%s\n", RecordBuf));
		}
		//DispUnicodeString("Record", RecordBuf);	
		return TRUE;
	}
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

VOID IpodWaitButtonTime()
{
	TIMER Timer;

	TimeOutSet(&Timer, 30);

	while(!IsTimeOut(&Timer))
	{
		AudioStreamProcess();
	}
}


////////////////////////Notification////////////////////////////////////////////////////////////////////////

VOID IpodSetEventNotification()
{
	//����GetSupportedEventNotification����󣬽��ϵ�IPOD����iPodAck bad parameterӦ��
	//���µ�IPOD����RetSupportedEventNotificationӦ�𣬵����е�IPOD���ӳ�2��Ż᷵��
	if(IPOD_SendCmdAndWaitResp(GetSupportedEventNotification, sizeof(GetSupportedEventNotification), 3000))
	{
		SetEventNotification[8] = IpodRespBuf[9] & 0x02;	//�Ƿ�֧��Database Changed
	}
	else
	{
		SetEventNotification[8] = 0x00;		//���ϵ�IPOD���ص���iPodAck
	}
	SetEventNotification[9] = 0x04;		
	IPOD_SendCmdAndWaitAck(SetEventNotification, sizeof(SetEventNotification), 500);
}


VOID IpodSetRemoteNotification()
{
	IPOD_SendCmdAndWaitAck(SetRemoteEventNotification, sizeof(SetRemoteEventNotification), 500);
}


VOID IpodSetPlayStatusNotification()
{
	IPOD_SendCmdAndWaitAck(SetPlayStatusChangeNotification, sizeof(SetPlayStatusChangeNotification), 500);
}


////////////////////////Repeat and Shuffle////////////////////////////////////////////////////////////////////////
//0: shuffle off, 1: shuffle tracks, 2: shuffle albums
BYTE IpodGetShuffle()
{
	if(IPOD_SendCmdAndWaitResp(GetShuffle, sizeof(GetShuffle), 500))
	{
		return IpodRespBuf[3];
	}
	return 0;	  
}


//0: shuffle off, 1: shuffle tracks, 2: shuffle albums
VOID IpodSetShuffle(BYTE Shuffle)
{
	SetShuffle[2] = Shuffle;
	IPOD_SendCmdAndWaitAck(SetShuffle, sizeof(SetShuffle), 500);
}


//0: repeat off, 1: repeat one, 2: repeat all
BYTE IpodGetRepeat()
{
	if(IPOD_SendCmdAndWaitResp(GetRepeat, sizeof(GetRepeat), 500))
	{
		return IpodRespBuf[3];
	}
	return 0;	  
}


//0: repeat off, 1: repeat one, 2: repeat all
VOID IpodSetRepeat(BYTE Repeat)
{
	SetRepeat[2] = Repeat;
	IPOD_SendCmdAndWaitAck(SetRepeat, sizeof(SetRepeat), 500);
}


////////////////////////Play Control////////////////////////////////////////////////////////////////////////

//��ȡplayback engine������Ŀ��
WORD IpodGetNumPlayingTracks()
{
	if(IPOD_SendCmdAndWaitResp(GetNumPlayingTracks, sizeof(GetNumPlayingTracks), 1000))
	{
		return (IpodRespBuf[5]*256 + IpodRespBuf[6]);
	}
	return 0;	  
}


//��ȡplayback engine�е�ǰ���ڲ��ŵ���ĿIndex
WORD IpodGetCurPlayingTrackIndex()
{
	if(IPOD_SendCmdAndWaitResp(GetCurrentPlayingTrackIndex, sizeof(GetCurrentPlayingTrackIndex), 1000))
	{
		if((IpodRespBuf[5] == 0xFF) && (IpodRespBuf[6] == 0xFF))
		{
			return 0;
		}
		else
		{
			return (IpodRespBuf[5]*256 + IpodRespBuf[6]);
		}
	}
	return 0;	//no track is playing or paused	  
}


//��ȡ��ǰ����״̬
BYTE IpodGetPlayStatus(WORD* CurPlayTime)
{
	DWORD Position;

	if(IPOD_SendCmdAndWaitResp(GetPlayStatus, sizeof(GetPlayStatus), 3000))
	{
		BYTE0(Position) = IpodRespBuf[7];
		BYTE1(Position) = IpodRespBuf[8];
		BYTE2(Position) = IpodRespBuf[9];
		BYTE3(Position) = IpodRespBuf[10];
		*CurPlayTime = Position/1000;
		return IpodRespBuf[11];
	}
	return IPOD_STATUS_STOPPED;	  
}


//��ͣ
VOID IpodPlayCtrl_Paused()
{
	if(IpodIsExtendedUIMode)
	{ 
		IPOD_SendCmdAndWaitAck(PlayCtrl_Pause, sizeof(PlayCtrl_Pause), 500);
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_Pause, sizeof(ContextButtonStatus_Pause)); 
		IpodWaitButtonTime();
		IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 	
	}	
}


//��ֹͣ״̬�ָ�����
VOID IpodPlayCtrl_Play()
{
	if(IpodIsExtendedUIMode)
	{  
		IpodCurrentTrackIndex = 0;
		IpodResetDBSelection();	
		IpodTotalDBTrackNum = IpodGetDBRecordsNum(IPOD_DB_SONG);
		if(IpodTotalDBTrackNum > 0)
		{
			IpodSelectDBRecord(IPOD_DB_SONG, IpodCurrentTrackIndex);				
			IpodTotalTrackNum = IpodGetNumPlayingTracks();
		}
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_PlayResume, sizeof(ContextButtonStatus_PlayResume)); 
		IpodWaitButtonTime();
		IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
	} 
}

 
//play/pause 
VOID IpodPlayCtrl_PlayPauseToggle()
{
	if(IpodIsExtendedUIMode)
	{
		IPOD_SendCmdAndWaitAck(PlayCtrl_PlayPause, sizeof(PlayCtrl_PlayPause), 500);	  
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_PlayPause, sizeof(ContextButtonStatus_PlayPause)); 
		IpodWaitButtonTime();	
		IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
	} 
}

//stop
VOID IpodPlayCtrl_Stop()
{
	if(IpodIsExtendedUIMode)
	{  
		IPOD_SendCmdAndWaitAck(PlayCtrl_Stop, sizeof(PlayCtrl_Stop), 500);
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_Stop, sizeof(ContextButtonStatus_Stop)); 
		IpodWaitButtonTime();
		IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
	} 
}


//��ʼ���
VOID IpodPlayCtrl_StartFF()
{	
	if(IpodIsExtendedUIMode)
	{
		IPOD_SendCmdAndWaitAck(PlayCtrl_StartFF, sizeof(PlayCtrl_StartFF), 500);	  
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_StartFF, sizeof(ContextButtonStatus_StartFF));
		IpodWaitButtonTime(); 
	} 
}


//��ʼ����
VOID IpodPlayCtrl_StartFB()
{
	if(IpodIsExtendedUIMode)
	{
		IPOD_SendCmdAndWaitAck(PlayCtrl_StartRew, sizeof(PlayCtrl_StartRew), 500);	  
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_StartFB, sizeof(ContextButtonStatus_StartFB)); 
		IpodWaitButtonTime();
	} 
}


//������������
VOID IpodPlayCtrl_EndFF_FB()
{
	if(IpodIsExtendedUIMode)
	{
		IPOD_SendCmdAndWaitAck(PlayCtrl_EndFF_Rew, sizeof(PlayCtrl_EndFF_Rew), 500);	  
	}
	else
	{
		IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
		IpodWaitButtonTime();
	} 
}


////�����ƶ���Ŀ
//VOID IpodStartPlayTrack(WORD TrackIndex)
//{
//	SetCurrentPlayingTracks[4] = BYTE0(TrackIndex);
//	SetCurrentPlayingTracks[5] = BYTE1(TrackIndex);
//	IPOD_SendCmd(SetCurrentPlayingTracks, sizeof(SetCurrentPlayingTracks)); 
//}


//��һ��
VOID IpodPlayCtrl_NextTrack()
{
	if(IpodIsExtendedUIMode)
	{
		if(IPOD_SendCmdAndWaitAck(PlayCtrl_Next, sizeof(PlayCtrl_Next), 2000) == 0x00)
		{
			return;
		}	  
	}

	IPOD_SendCmd(ContextButtonStatus_NextTrack, sizeof(ContextButtonStatus_NextTrack)); 
	IpodWaitButtonTime();
	IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
}


//��һ��
VOID IpodPlayCtrl_PreTrack()
{
	if(IpodIsExtendedUIMode)
	{
		DBG(("300\n"));
		if(IPOD_SendCmdAndWaitAck(PlayCtrl_Prev, sizeof(PlayCtrl_Prev), 2000) == 0x00)
		{
			DBG(("301\n"));
			return;
		}	  
	}

	DBG(("302\n"));
	IPOD_SendCmd(ContextButtonStatus_PreTrack, sizeof(ContextButtonStatus_PreTrack)); 
	IpodWaitButtonTime();
	IPOD_SendCmd(ContextButtonStatus_AllUp, sizeof(ContextButtonStatus_AllUp)); 
}


////////////////Extendedģʽ��Standardģʽ���л�/////////////////////////////////////////////////////////////////////////////////////////////
//����SIMPLE REMOTE MODE�����ԭ�����ڲ���״̬�����Żᱻ�Զ���ͣ
VOID IpodEnterRemoteUIMode()
{
	if(IPOD_SendCmdAndWaitAck(ExitExtendedInterfaceMode, sizeof(ExitExtendedInterfaceMode), 3000) != 0x00)
	{
		//������صĲ���OK����ô����0x06(command pending)�������Ҫ�ٵȴ�3000ms
		IPOD_WaitIpodAck(ExitExtendedInterfaceMode, 3000);
	}

	IpodIsExtendedUIMode = FALSE;
}


//����EXTENDED MODE�����ԭ�����ڲ���״̬�����Żᱻ�Զ���ͣ
VOID IpodEnterExtendedUIMode()
{
	//iTouch������ģʽ����Ҫ6�����Ҳŷ��ؽ��	
	if(IPOD_SendCmdAndWaitAck(SetUIMode, sizeof(SetUIMode), 10000) == 0x04)
	{
		//������صĽ����0x04(bad parameter)������Ҫʹ��EnterRemoteUIMode������ܽ���Extendedģʽ
		if(IPOD_SendCmdAndWaitAck(EnterRemoteUIMode, sizeof(EnterRemoteUIMode), 3000) != 0x00)
		{
			//������صĲ���OK����ô����0x06(command pending)�������Ҫ�ٵȴ�3000ms
			IPOD_WaitIpodAck(EnterRemoteUIMode, 3000);
		}
	}

	IpodIsExtendedUIMode = TRUE;
}


//////////////////SimpleRemoteģʽ�µĳ�����������//////////////////////////////////////////////////////////////////////////
VOID IpodSimpleRemoteButtonOp(BYTE Status)
{
	if(!IpodIsExtendedUIMode)
	{
		if(Status == 0x01)			//FF
		{
			IPOD_SendCmd(ContextButtonStatus_StartFF, sizeof(ContextButtonStatus_StartFF)); 
			IpodWaitButtonTime();
		}
		else if(Status == 0x02)		//FB
		{
			IPOD_SendCmd(ContextButtonStatus_StartFB, sizeof(ContextButtonStatus_StartFB)); 
			IpodWaitButtonTime();
		}
	}
}


//////////////////Digital Audio��غ���//////////////////////////////////////////////////////////////////////////
VOID IpodRetSampleRate()
{
	//����֧�ֵĲ�������Ϣ
	IPOD_SendResp(RetAccSampleRateCaps, sizeof(RetAccSampleRateCaps));
}

#endif