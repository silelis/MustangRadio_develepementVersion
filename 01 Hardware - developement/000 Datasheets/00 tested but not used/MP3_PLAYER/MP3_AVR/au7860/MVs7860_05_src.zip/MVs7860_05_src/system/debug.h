#ifndef _DEBUG_H_
#define _DEBUG_H_

#include <stdio.h>
#include "syscfg.h"


#if 1

#if (defined(FUNC_UARTDBG_EN) && (!defined(LIB_CREATE_EN)))
	#define	DBG(x)				
	#define	DBG1(x)				printf x
#else
	#define	DBG(x)
	#define	DBG1(x)				
#endif

#else

#if (defined(FUNC_UARTDBG_EN) && (!defined(LIB_CREATE_EN)))
	#define	DBG(x)				printf x
#else
	#define	DBG(x)
#endif

#endif


VOID InitUart();


#endif
