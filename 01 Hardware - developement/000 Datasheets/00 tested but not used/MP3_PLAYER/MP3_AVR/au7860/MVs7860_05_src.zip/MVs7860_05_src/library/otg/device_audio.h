#ifndef _DEVICE_AUDIO_H_
#define	_DEVICE_AUDIO_H_


//pc volume: 0 --- 999
#define AUDIO_MAX_VOLUME	999


//pc command
#define PC_CMD_NEXT			0x04
#define PC_CMD_PRE			0x08
#define PC_CMD_MUTE			0x10
#define PC_CMD_PLAY_PAUSE	0x40
#define PC_CMD_STOP			0x80


//usb audio device initial
VOID DeviceAudioInit();

//usb audio device process
VOID DeviceAudioRequestProcess();

//send command to pc
BOOL DeviceAudioSendPcCmd(BYTE PcCmd);

#endif
