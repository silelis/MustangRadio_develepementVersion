#ifndef _SPI_PLAY_H_
#define _SPI_PLAY_H_


#define SPIPLAY_STATE_IDLE		0
#define SPIPLAY_STATE_START		1
#define SPIPLAY_STATE_PLAY		2
#define SPIPLAY_STATE_PAUSE		3
#define SPIPLAY_STATE_MUTE		4
#define SPIPLAY_STATE_STOP		5

extern BYTE gSpiPlayState;

BOOL SPI_SongPlayStart();
BOOL SPI_PlayCtrl();

#endif