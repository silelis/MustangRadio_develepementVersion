#include "syscfg.h"
#include "sysctrl.h"
#include "timer.h"
#include "utility.h" 
#include "radio_ctrl.h"
#include "message.h"
#include "key.h"
#include "debug.h"
#include	"radioDisp.h"
#include "syscfg.h"
#include "24Cxx.h"
#include "gui.h"
//#include	"..\pace\paceLib\paceLib.h" //lxl comment 7-17

extern BYTE Status_DisVol ;

VOID LoadRadioInfo();
#define		FLAG_NUMB		((MAX_SAVE_CH*2+3+7)/8)


//RADIO_CTRL	gRadioCtrl;
extern BOOL	StopSDClkFlag;
#ifdef FUNC_RADIO_EN
#define u8 BYTE

#if 0
#define EEP_ADR_SYSTEMMODE		0
#define EEP_ADR_SAVE_CH_NUM 		(EEP_ADR_SYSTEMMODE + 1)
#define EEP_ADR_FREQ_MSB			(EEP_ADR_SAVE_CH_NUM +1)
#define EEP_ADR_FREQ_LSB			(EEP_ADR_FREQ_MSB + 1)
#define EEP_ADR_CUR_CHL_NO		(EEP_ADR_FREQ_LSB + 1)
#define EEP_ADR_FM1_MEM_STR		(EEP_ADR_CUR_CHL_NO + 1)
#endif
//---------------------------------------------------

static TIMER	StartSearchFMTimer;								//��ʼ����FMƵ��ʱ��
#define		OUTTIME_STARTSEARCHFM_TIMER			1000	//1000ms�ڰ������м������,��ʼ����


static BYTE FMSearchChlKeyStatus = 0 ;	//�����ж�˫�����ż����µ���̨����

RADIO_CTRL	gRadioCtrl;
Radio_NAME 	Radio_Name;

//------------------------------------------------------
static TIMER	SeekDelay;

void		RadioAutoSearchStart(void);
BYTE		RadioAutoSearch(void);

//void	RadioSeekStartSet(BYTE dir);
BYTE	RadioSeekChk(void);
u8		RadioChkChNum(u8 fg);
void	RadioFreqSet(void);

//-----------------------------------------------------

BYTE	radioSaveflag[FLAG_NUMB];

extern	void		paceAudioFastMuteOn(BYTE tm);
extern WORD	gIrNumber;


enum {
	RADIO_SAVE_CUR_FREQ=0,
	RADIO_SAVE_CH_SUM,	
	RADIO_SAVE_MEM_FREQ,	
};





//-----------------------------------------------------

//FM in �������ö�Ӧ�ķŴ���
BYTE CODE gFmInGain[VOLUME_MAX + 1] = 
{
	 63, 
	 62, 	59, 	57, 	55,		53,		51,		49,		47, 	
	 45, 	43, 	41, 	39,     37, 	35, 	33, 	31,
	 29,	27,		25,  	23, 	21, 	20, 	19,  	18,  
	 17,  	16,  	15,  	14, 	13,  	12,  	11,  	10
};

#if 0	//lxl to reduce target size 8-2
VOID	RadioSetVol(BYTE vl)
{

	InDacLineInGain(gFmInGain[vl]);
	InDacMuteDis();

}
#endif
VOID	RadioSetVolume(void)
{
	InDacLineInGain(gFmInGain[gSys.Volume]);
	InDacMuteDis();
}


/********************************************************

*********************************************************/
#if 1
CODE  const	 pDrv pRadioDrvTab[RADIO_MAX-1]={
	RDA5807P_ReadID,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0
};
#else
CODE  const	 pDrv pRadioDrvTab[RADIO_MAX-1]={
	RDA5807P_ReadID,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	(pDrv)0,
	QN8035_ReadID,
	(pDrv)0
};
#endif

Radio_NAME	RadioChkDrvID(void)
{
	BYTE	cnt=0;
	Radio_Name = RADIO_NONE;
	for (cnt=0; cnt<(RADIO_MAX-1); cnt++)
	{
		if (pRadioDrvTab[cnt])
		{
			 if ((*pRadioDrvTab[cnt])())
			 {
				Radio_Name = cnt+1;
				DBG(("Radio ID = %BU", Radio_Name));
				break;
			 }
		}
	}
	return	Radio_Name;
}



VOID RadioInit()
{
	BYTE	wk=0;
	//Radio_Name = RADIO_NONE;

	gRadioCtrl.Freq = FREQ_DEF;
	gRadioCtrl.CurCh = 0;
	gRadioCtrl.MaxCh = 0;

	for (wk=0; wk<8; wk++)
	{
		radioSaveflag[wk] = 0;
	}

#if 0
{
	//д������
	BYTE dataadd = 0 ;
	DBG(("\n\neep test 111111111111111111111111\n"));
	EEPROM_WriteByte( (BYTE)dataadd, (BYTE)0);
	DBG(("read data = %2BX \n\n" , EEPROM_ReadByte((BYTE)dataadd)));
	DBG(("read over---------------------- \n\n"));
//��������
	
}
#endif

	if(RadioChkDrvID())		//read FM module ID
	{

		//if (eepIsValid())
		if (1)	//lxl 7-24
		{
#if 0		
//			gRadioCtrl.MaxCh = eepRdByte(EEP_ADR_SAVE_CH_NUM);//lxl 7-24
			gRadioCtrl.MaxCh = EEPROM_ReadByte(EEP_ADR_SAVE_CH_NUM);
			if (gRadioCtrl.MaxCh > MAX_SAVE_CH)
			{
				DBG(("ERR:	 Radio  Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh));
				gRadioCtrl.MaxCh = 0;
				gRadioCtrl.Freq = FREQ_MIN;
				return ;
			}
			DBG(("\n Radio  Read Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh) );
			
			gRadioCtrl.Freq = EEPROM_ReadByte(EEP_ADR_FREQ_MSB);
			gRadioCtrl.Freq<<= 8;
			gRadioCtrl.Freq += EEPROM_ReadByte(EEP_ADR_FREQ_LSB);
			DBG((" Radio Get Cur FREQ = %d \n", (short)gRadioCtrl.Freq));
			if ((gRadioCtrl.Freq>FREQ_MAX) ||(gRadioCtrl.Freq<FREQ_MIN))
			{
				gRadioCtrl.Freq = FREQ_MIN;
			}
			else
			{
				gRadioCtrl.CurCh = EEPROM_ReadByte(EEP_ADR_CUR_CHL_NO);
			}
			//gRadioCtrl.Freq = FREQ_MIN;	//LXL FOR TEST 7-24
			//for (wk=0; wk<30; wk++)
			DBG((" berore for loop Radio  Read Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh) );
			for ( wk = 0 ;  wk <  gRadioCtrl.MaxCh ; wk++)
			//for ( wk=0; wk <  4; wk++)
			{
				DBG((" 33333333333333333333333 CH%d", (short)(wk)));
				gRadioCtrl.MemFreq[wk] = EEPROM_ReadByte(EEP_ADR_FM1_MEM_STR+(wk<<1));
				gRadioCtrl.MemFreq[wk] <<= 8;
				gRadioCtrl.MemFreq[wk] += EEPROM_ReadByte(EEP_ADR_FM1_MEM_STR+(wk<<1)+1);
				if ((gRadioCtrl.MemFreq[wk] >FREQ_MAX) ||(gRadioCtrl.MemFreq[wk] <FREQ_MIN))
				{
					//Ӧ��ȡ����Ƶ����Ϣ
					gRadioCtrl.MemFreq[wk]  = FREQ_MIN;
				}			
				DBG((" Radio  Freq Mem CH%d", (short)(wk)));
				DBG((" : FREQ = %d\n",gRadioCtrl.MemFreq[wk]));
			}
#endif			
		}
		else
		{
			RADIO_SET_FLAG(RADIO_SAVE_CH_SUM_FLAG_REL);
		}
	}
	else
	{
		return;
	}
	
}

VOID LoadRadioInfo()
{
	BYTE	wk=0;	
	
//			
			gRadioCtrl.MaxCh = EEPROM_ReadByte(EEP_ADR_SAVE_CH_NUM);
			if (gRadioCtrl.MaxCh > MAX_SAVE_CH)
			{
				DBG(("ERR:	 Radio  Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh));
				gRadioCtrl.MaxCh = 0;
				gRadioCtrl.Freq = FREQ_MIN;
				return ;
			}
			DBG(("\n Radio  Read Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh) );
			
			gRadioCtrl.Freq = EEPROM_ReadByte(EEP_ADR_FREQ_MSB);
			gRadioCtrl.Freq<<= 8;
			gRadioCtrl.Freq += EEPROM_ReadByte(EEP_ADR_FREQ_LSB);
			DBG((" Radio Get Cur FREQ = %d \n", (short)gRadioCtrl.Freq));
			if ((gRadioCtrl.Freq>FREQ_MAX) ||(gRadioCtrl.Freq<FREQ_MIN))
			{
				gRadioCtrl.Freq = FREQ_MIN;
			}
			else
			{
				gRadioCtrl.CurCh = EEPROM_ReadByte(EEP_ADR_CUR_CHL_NO);
			}
			//gRadioCtrl.Freq = FREQ_MIN;	//LXL FOR TEST 7-24
			//for (wk=0; wk<30; wk++)
			DBG((" berore for loop Radio  Read Freq Mem Max CH=%2Bu\n", (BYTE)gRadioCtrl.MaxCh) );
			for ( wk = 0 ;  wk <  gRadioCtrl.MaxCh ; wk++)
			//for ( wk=0; wk <  4; wk++)
			{
				DBG((" 33333333333333333333333 CH%d", (short)(wk)));
				gRadioCtrl.MemFreq[wk] = EEPROM_ReadByte(EEP_ADR_FM1_MEM_STR+(wk<<1));
				gRadioCtrl.MemFreq[wk] <<= 8;
				gRadioCtrl.MemFreq[wk] += EEPROM_ReadByte(EEP_ADR_FM1_MEM_STR+(wk<<1)+1);
				if ((gRadioCtrl.MemFreq[wk] >FREQ_MAX) ||(gRadioCtrl.MemFreq[wk] <FREQ_MIN))
				{
					//Ӧ��ȡ����Ƶ����Ϣ
					gRadioCtrl.MemFreq[wk]  = FREQ_MIN;
				}			
				DBG((" Radio  Freq Mem CH%d", (short)(wk)));
				DBG((" : FREQ = %d\n",gRadioCtrl.MemFreq[wk]));
			}
	
}

VOID RadioCtrlInit()
{
	BYTE	wk=0;	
	//paceAudioFastMuteOn(200);	//lxl 7-24
	//radioDispSetSts(RADIO_DISP_STS_INIT);
	//gRadioCtrl.Freq = FREQ_DEF;		//test

	/*********����ϵͳģʽ*********/
	EEPROM_WriteByte( (BYTE)EEP_ADR_SYSTEMMODE, (BYTE)SYS_MODE_RADIO);


	LoadRadioInfo();
	
	WaitMs(1);

	RadioSetVolume();
	
	FmModeInit();

	//gRadioCtrl.Freq = 971;
	RadioFreqSet();
//	paceAudioFastMuteOn(200);

	//Ӧ�������Ļ
	ClearFreqWin();
	
	ShowWholeRadioFre(gRadioCtrl.Freq);
	gRadioCtrl.Stauts = RADIO_STS_INIT;
	
}


VOID RadioCtrlEnd()
{
	InDacMuteEn();
	WaitMs(10);
	RadioPowerDownEn();
	gRadioCtrl.Stauts = RADIO_STS_INIT;
	radioDispSetSts(RADIO_DISP_STS_EXIT);

	StopSDClkFlag =FALSE;
}


/*************************************************************


**************************************************************/
/********************************************************
Function:
Input:
Output:
Description:

********************************************************/
void		RadioAbort(void)
{
	FmModeInit();
	RadioFreqSet();
//	paceAudioFastMuteOn(200);

	
}




void	RadioFreqSet(void)
{
	RadioFreqSet_drv();
	RADIO_SET_FLAG(RADIO_SAVE_CUR_FREQ_H_FLAG_REL);
	RADIO_SET_FLAG(RADIO_SAVE_CUR_FREQ_L_FLAG_REL);

	//ShowRadioFre(gRadioCtrl.Freq);
	
#if 0	//lxl 7-24 
	DBG((" Radio Set Cur Freq Save Flag 0=%X\n", (short)(radioSaveflag[0])));
	DBG((" Radio Set Cur Freq Save Flag 1=%X\n", (short)(radioSaveflag[1])));
	DBG((" Radio Set Cur Freq Save Flag 2=%X\n", (short)(radioSaveflag[2])));
	DBG((" Radio Set Cur Freq Save Flag 3=%X\n", (short)(radioSaveflag[3])));
#endif	
}

#if 0  //lxl to reduce target size
void	RadioSetMemSaveFlag(BYTE mem)
{

	if (mem == 0)
		return;
	mem--;
	RADIO_SET_FLAG(RADIO_SAVE_MEM_FREQ_FLAG_REL+(mem<<1));
	RADIO_SET_FLAG(RADIO_SAVE_MEM_FREQ_FLAG_REL+(mem<<1)+1);	
	DBG((" Radio Set Mem Freq Save Flag!\n"));

}
#endif

//FM ���ܿ���
VOID RadioStateCtrl()
{
	MESSAGE event = MessageGet(MSG_FIFO_KEY);



	switch (gRadioCtrl.Stauts)
	{
		case	RADIO_STS_INIT:
			gRadioCtrl.Stauts = RADIO_STS_IDLE;
			FMSearchChlKeyStatus = 0;
			break;
		case	RADIO_STS_IDLE:
			 //lxl 7-24
			switch(event)
			{			
				//case IN_KEY_VOL_ADD: //lxl comment
				case MSG_VOL_ADD:			//������������,�̰���һ��,��һ��
				{
					if(gSys.Volume < VOLUME_MAX)
					{
						gSys.Volume++; 
						RadioSetVolume();
						//eepSaveVol();//??? lxl 
					}
					if (gSys.Volume == 1)
						InDacMuteDis();
#ifdef FUNC_BREAK_POINT_EN
					BP_SaveVolumeInfo();
#endif
					//EEPROM_WriteByte( (BYTE)(EEP_ADR_VOLUME), (BYTE)(gSys.Volume));
					
					ShowVolume( );
					Status_DisVol = 1 ;
					break;
				}
				case MSG_VOL_ADD_CP:			//������������,�̰���һ��,��һ��
				{
					if(gSys.Volume < VOLUME_MAX)
					{
						gSys.Volume++; 
						//if( VOLUME_MAX >= gSys.Volume )
						{
							RadioSetVolume();
						}
					}
					if (gSys.Volume == 0)
						InDacMuteDis();
#ifdef FUNC_BREAK_POINT_EN
					BP_SaveVolumeInfo();
#endif					
					//EEPROM_WriteByte( (BYTE)(EEP_ADR_VOLUME), (BYTE)(gSys.Volume));
					
					ShowVolumeCP( 1 );
					Status_DisVol = 1 ;
					break;
				}
				case MSG_VOL_SUB:
				{
					if(gSys.Volume > VOLUME_MIN)
					{
						gSys.Volume--;
						//if( VOLUME_MIN <= gSys.Volume   )
						{
							RadioSetVolume();
						}
						if(gSys.Volume == 0)
						{
							InDacMuteEn();
						}
						else
						{
							//paceAudioExitFuncMute();
						}
					}							
#ifdef FUNC_BREAK_POINT_EN
					BP_SaveVolumeInfo();
#endif					
					//EEPROM_WriteByte( (BYTE)(EEP_ADR_VOLUME), (BYTE)(gSys.Volume));
					ShowVolume( );
					Status_DisVol = 1 ;
					break;
				}
				case MSG_VOL_SUB_CP:
				{
					if(gSys.Volume > VOLUME_MIN)
					{
						gSys.Volume--;
						//if( VOLUME_MIN <= gSys.Volume   )
						{
							RadioSetVolume();
						}
						if(gSys.Volume == 0)
						{
							InDacMuteEn();
						}
						else
						{
							//paceAudioExitFuncMute();
						}
					}							
#ifdef FUNC_BREAK_POINT_EN
					BP_SaveVolumeInfo();
#endif
					//EEPROM_WriteByte( (BYTE)(EEP_ADR_VOLUME), (BYTE)(gSys.Volume));
					ShowVolumeCP( 0 );
					Status_DisVol = 1 ;
					break;
				}

			#if 0
				case IN_KEY_PLAY_SP:
				case IN_KEY_INTRO:
				//case IN_KEY_PLAYSCAN:
			#endif
				case MSG_PLAY_PAUSE:	//1����˫���м������,��ʼFM����
				//case MSG_STOP:
#ifndef FMSEARCH_DUAL_CLICK		
					//������̨
					DBG(("Start to search FM channels \n"));
					ClearFreqWin();
					RadioAutoSearchStart();
					break ;
					
#else
					//˫����̨
					if( 1 == FMSearchChlKeyStatus )
					{
						//�Ѿ������м��������
						if (!IsTimeOut(&StartSearchFMTimer))
						{
							//��˫������
							//��ʼ����FM
							DBG(("Start to search FM channels \n"));
							ClearFreqWin();
							RadioAutoSearchStart();
						}												
					}
					TimeOutSet(&StartSearchFMTimer, OUTTIME_STARTSEARCHFM_TIMER );
					FMSearchChlKeyStatus = 1 ;
					
					break;	
#endif					

#if 0
				case MSG_REC_DELETE:		//sw17	�Զ���̨
					#if 0	//lxl 7-19
					paceAudioExitFuncMute();
					paceAudioDispSetSts(AUDIO_DISP_STS_EXIT);
					#endif
					ClearFreqWin();
					RadioAutoSearchStart();
					break;
#endif
					
#if 0
				case IN_KEY_MUTE:		//mute enable
				//case	IN_KEY_PLAY_SP:
					paceAudioFncMute();
					break;
//#if defined(NEXT_PREV_SP_TUNE)

				case IN_KEY_PRE_SP:	//��һ̨
					gRadioCtrl.Freq-=1;
					if (gRadioCtrl.Freq < FREQ_MIN)
					{
						gRadioCtrl.Freq = FREQ_MAX;
					}
					RadioFreqSet();
					radioDispSetSts(RADIO_DISP_STS_FREQ);
					break;

				case IN_KEY_NEXT_SP:	//��һ̨
					gRadioCtrl.Freq+=1;
					if (gRadioCtrl.Freq > FREQ_MAX)
					{
						gRadioCtrl.Freq = FREQ_MIN;
					}
					RadioFreqSet();
					radioDispSetSts(RADIO_DISP_STS_FREQ);
					break;					

//#elif defined(NEXT_PREV_SP_CH)
#endif

				//case IN_KEY_PRE_SP:	//��һ̨
				case MSG_PRE:	//��һ̨	���ð���	
					//DBG((" ��һ̨ Cur CH=%d\n", (short)gRadioCtrl.CurCh));
					//DBG((" ��һ̨ Max CH=%d\n", (short)gRadioCtrl.MaxCh));
					//DBG(("curchl =%d freq = %d \n" , (short)gRadioCtrl.CurCh , gRadioCtrl.Freq));
					if (gRadioCtrl.MaxCh == 0)
					{
						DBG(("��һ̨ maxch == 0\n"));
						break;
					}
					if (gRadioCtrl.CurCh > 0)
						gRadioCtrl.CurCh--;
					else
						gRadioCtrl.CurCh=gRadioCtrl.MaxCh-1;
					if (gRadioCtrl.CurCh >= 0)
					{
						gRadioCtrl.Freq = gRadioCtrl.MemFreq[gRadioCtrl.CurCh];
						RadioFreqSet();
						radioDispSetSts(RADIO_DISP_STS_CH);
					}
					//ShowRadioFre(gRadioCtrl.Freq);
					ClearFreqWin();
					
					ShowWholeRadioFre(gRadioCtrl.Freq);
					
					EEPROM_WriteByte( (BYTE)(EEP_ADR_CUR_CHL_NO), (BYTE)(gRadioCtrl.CurCh));
					EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_MSB ), (BYTE)(gRadioCtrl.Freq>>8));
					EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_LSB ), (BYTE)(gRadioCtrl.Freq));
					DBG(("curchl =%d freq = %d \n" , (short)gRadioCtrl.CurCh , gRadioCtrl.Freq));
					break;

				//case IN_KEY_NEXT_SP:	//��һ̨
				case MSG_NEXT:
					if (gRadioCtrl.MaxCh == 0)
					{
						DBG(("��һ̨ maxch == 0\n"));
						break;
					}
					if (gRadioCtrl.CurCh < (gRadioCtrl.MaxCh-1))
						gRadioCtrl.CurCh++;
					else
						gRadioCtrl.CurCh=0;
					if (gRadioCtrl.CurCh >= 0)
					{
						gRadioCtrl.Freq = gRadioCtrl.MemFreq[gRadioCtrl.CurCh];
						RadioFreqSet();
						radioDispSetSts(RADIO_DISP_STS_CH);
					}
					//ShowRadioFre(gRadioCtrl.Freq);
					ClearFreqWin();
					ShowWholeRadioFre(gRadioCtrl.Freq);
					EEPROM_WriteByte( (BYTE)(EEP_ADR_CUR_CHL_NO), (BYTE)(gRadioCtrl.CurCh));
					EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_MSB ), (BYTE)(gRadioCtrl.Freq>>8));
					EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_LSB ), (BYTE)(gRadioCtrl.Freq));
					DBG(("curchl =%d freq = %d \n" , (short)gRadioCtrl.CurCh , gRadioCtrl.Freq));
					break;
				case MSG_NO_SHOW_VOLUME:
					//Ӧ�������Ļ
					ClearFreqWin();
					ShowWholeRadioFre(gRadioCtrl.Freq);
					break;
				case MSG_RETURN_VOLTAGE:
					//Ӧ�������Ļ
					ClearFreqWin();
					ShowWholeRadioFre(gRadioCtrl.Freq);
					break;
#if 0
//#endif

				case IN_KEY_PRE_CP:	
					RadioSeekStartSet(SEEKDN);
					DBG(("Radio : Seek Down Start!\n"));
					break;


				case IN_KEY_NEXT_CP:	
					RadioSeekStartSet(SEEKUP);
					DBG(("Radio : Seek Up Start!\n"));
					break;

				case IN_KEY_PICK_SONG:
					if((gIrNumber >= FREQ_MIN) && (gIrNumber <= FREQ_MAX))
					{
						gRadioCtrl.Freq = gIrNumber;						
						RadioFreqSet();	
						radioDispSetSts(RADIO_DISP_STS_FREQ);
					}
					else if((gIrNumber >= 1) && (gIrNumber <= gRadioCtrl.MaxCh))
						{
						gRadioCtrl.CurCh=gIrNumber;
						gRadioCtrl.Freq = gRadioCtrl.MemFreq[gRadioCtrl.CurCh-1];
						RadioFreqSet();
						radioDispSetSts(RADIO_DISP_STS_CH);
						}
					else
						radioDispSetSts(RADIO_DISP_STS_FREQ);
					
					gIrNumber = 0;					
					
					break;
			#endif
				default:
					break;
			}
	#endif	//lxl 7-24		
			if (RadioChkChNum(0))
				radioDispSetSts(RADIO_DISP_STS_CH);
			//radioExtPrc();
			break;
		case	RADIO_STS_SEEK:
			if (RadioSeekChk())
			{
				DBG(("Radio : Seek End!\n"));
				gRadioCtrl.Stauts = RADIO_STS_IDLE;
			}
			else
			{
				switch(event)
				{
					case MSG_PRE:	// lxl 7-24
				#if 0 //lxl 7-24
					case IN_KEY_NEXT_SP:
					case IN_KEY_PRE_SP:
					case IN_KEY_NEXT_CP:
					case IN_KEY_PRE_CP:
					case IN_KEY_PLAY_SP:	
						#endif
						RadioAbort();
						RadioFreqSet();
						RadioMuteDis();
						//paceAudioSwMuteOff();	//lxl 7-24
						gRadioCtrl.Stauts = RADIO_STS_IDLE;
						break;
					default:
						break;
				}
			}
			break;
		case	RADIO_STS_SEARCH:
			if (RadioAutoSearch())
			{
				DBG(("Radio : Search End!\n"));
				gRadioCtrl.Stauts = RADIO_STS_IDLE;
			}
			else
			{
				switch(event)
				{
					case MSG_PRE:	//lxl 7-24
					case MSG_NEXT:
					case MSG_PRE_POWER:
						#if 0
					case IN_KEY_NEXT_SP:
					case IN_KEY_PRE_SP:
					case IN_KEY_NEXT_CP:
					case IN_KEY_PRE_CP:
					case IN_KEY_PLAY_SP:	
					#endif		//lxl 7-24	
						RadioAbort();
						//////////////////////////////////////////////////
						if (gRadioCtrl.MaxCh> 0)
						{
							gRadioCtrl.Freq = gRadioCtrl.MemFreq[gRadioCtrl.CurCh++];
						}
						else
						{
							gRadioCtrl.Freq = 875;
						}
						//////////////////////////////////////////////////
						RadioFreqSet();
						RadioMuteDis();
						//paceAudioSwMuteOff();
						//paceAudioFastMuteOn(300);//lxl 7-24
						gRadioCtrl.Stauts = RADIO_STS_IDLE;
						ShowWholeRadioFre(gRadioCtrl.Freq);

						///////////////////////////////////////////////////
						RadioChkChNum(1);
						/////////////////////////////////////////////////////
						break;
					default:
						break;
				}
			}
			break;
			
		case	RADIO_STS_EXIT:
			break;
		default:
			break;
		}
#if 0	//lxl 7-24
	if (gRadioCtrl.Stauts != RADIO_STS_SEARCH)
		radioDispPrc();
#endif	
}




//===========================================================================

/********************************************************
Function:
Input:
Output:
Description:��õ�ǰƵ����Ϣ��radioƵ�����

********************************************************/
u8		RadioChkChNum(u8 fg)
{
	static	WORD ChFreq=0xffff;
	u8	rt = 0;

	if (gRadioCtrl.MaxCh == 0)
		return rt;

	if (fg || (ChFreq != gRadioCtrl.Freq))
	{
		ChFreq = gRadioCtrl.Freq;
		for (gRadioCtrl.CurCh=0; gRadioCtrl.CurCh<gRadioCtrl.MaxCh; gRadioCtrl.CurCh++)
		{
			if (ChFreq == gRadioCtrl.MemFreq[gRadioCtrl.CurCh])
			{
				break;
			}
		}
		if (gRadioCtrl.CurCh < gRadioCtrl.MaxCh)
		{
			//gRadioCtrl.CurCh++;		//lxl comment ??
			rt = gRadioCtrl.CurCh;
		}
		else
		{
			gRadioCtrl.CurCh = 0;
		}
		DBG((" RadioChkChNum Radio  Freq Cur CH=%d\n", (short)gRadioCtrl.CurCh));
		DBG((" RadioChkChNum Radio  Freq Max CH=%d\n", (short)gRadioCtrl.MaxCh));
	}
	return rt;

}



#if 0  //lxl to reduce target size
/*********************************************************************
Function:
Input:
Output:
Description:

***********************************************************************/
void	RadioSeekStartSet(BYTE dir)
{

	//paceAudioSwMuteOn();	//lxl 7-24
	RadioMuteEn();
	gRadioCtrl.SeekStarFreq = gRadioCtrl.Freq;
	gRadioCtrl.SeekDir = dir;
	if (gRadioCtrl.SeekDir == SEEKUP)
	{
		if (gRadioCtrl.Freq < FREQ_MAX)
			gRadioCtrl.Freq++;
		else
			gRadioCtrl.Freq = FREQ_MIN;
	}
	else
	{
		if (gRadioCtrl.Freq > FREQ_MIN)
			gRadioCtrl.Freq--;
		else
			gRadioCtrl.Freq = FREQ_MAX;
	}
	gRadioCtrl.Stauts = RADIO_STS_SEEK;
	RadioFreqSet_drv();
	RadioSeekStart();
	TimeOutSet(&SeekDelay, 10);

}
#endif	
/*********************************************************************
Function:
Input:
Output:
Description:

***********************************************************************/
BYTE	RadioSeekChk(void)
{
	BYTE	wk=0;
	BYTE	NeedExit=0;
	if (!IsTimeOut(&SeekDelay))	return 0;
		wk = RadioSeekResultGet();
	if (gRadioCtrl.SeekStarFreq == gRadioCtrl.Freq)
	{
		NeedExit = 1;
	}

	if ((wk!=0) || (NeedExit!=0))
	{
		FmModeInit();
		RadioFreqSet();
		RadioMuteDis();
		//paceAudioSwMuteOff();//lxl 7-24
		return 1;
	}

	if (gRadioCtrl.SeekDir == SEEKUP)
	{
		if (gRadioCtrl.Freq < FREQ_MAX)
			gRadioCtrl.Freq++;
		else
			gRadioCtrl.Freq = FREQ_MIN;
	}
	else
	{
		if (gRadioCtrl.Freq > FREQ_MIN)
			gRadioCtrl.Freq--;
		else
			gRadioCtrl.Freq = FREQ_MAX;
	}
	RadioSeekStart();
	TimeOutSet(&SeekDelay, 50);

	return 0;
}




/********************************************************
Function:
Input:
Output:
Description:

********************************************************/
void		RadioAutoSearchStart(void)
{
	gRadioCtrl.Stauts = RADIO_STS_SEARCH;
	gRadioCtrl.SeekSts = SEARCH_INIT;
}


/********************************************************
Function:
Input:
Output:
Description:

********************************************************/
BYTE		RadioAutoSearch(void)
{
	u8	wk=0;
	switch (gRadioCtrl.SeekSts)
	{
		case	SEARCH_INIT:
//			paceAudioSwMuteOn(); // 7-24
			//DBG(("SEARCH_INIT ----------------\n"));
			for (wk=0; wk<MAX_SAVE_CH; wk++)
			{
				gRadioCtrl.MemFreq[wk] = 875;
			}

			gRadioCtrl.Freq = 875;
			gRadioCtrl.MaxCh = 0;
			gRadioCtrl.CurCh = 0;
			RadioFreqSet_drv();
			//RadioMuteEn();		//lxl 7-29
			gRadioCtrl.SeekSts = SEARCH_START;
			TimeOutSet(&SeekDelay, 0);
			//Ӧ������
			ClearFreqWin();
			break;

		case	SEARCH_START:			
			if (!IsTimeOut(&SeekDelay))	break;
			//DBG(("SEARCH_START ----------------\n"));

			RadioSeekStart();
			//radioDispFreq();
			//��ʾ���������е�Ƶ��ͼ��,�ڷ�Ƶģʽ�£�ˢ����Ҫ�϶��ʱ��
			//���Խ���ʾ��ǰƵ����Ϣ���Ҳ���������Ƶ��������Ļ
			ShowRadioFre(gRadioCtrl.Freq);	
			//ShowPaceRadioFre(gRadioCtrl.Freq);
			gRadioCtrl.SeekSts = SEARCH_CHK;
			TimeOutSet(&SeekDelay, 50);
			break;
			
		case	SEARCH_CHK:		//����������
			if (!IsTimeOut(&SeekDelay))	break;
			gRadioCtrl.SeekSts = SEARCH_NEXT;
			//DBG(("SEARCH_CHK ----------------\n"));
			wk = RadioSeekResultGet();
			if (wk != 0)
			{
				//RadioMuteDis();
				if (gRadioCtrl.MaxCh < MAX_SAVE_CH)
				{
					//gRadioCtrl.MemFreq[gRadioCtrl.MaxCh++] = gRadioCtrl.Freq;
					gRadioCtrl.MemFreq[gRadioCtrl.MaxCh] = gRadioCtrl.Freq;

					//������������Ƶ���Ƶ����Ϣ
					EEPROM_WriteByte( (BYTE)(EEP_ADR_FM1_MEM_STR+(gRadioCtrl.MaxCh<<1)), (BYTE)(gRadioCtrl.Freq>>8));
					EEPROM_WriteByte( (BYTE)(EEP_ADR_FM1_MEM_STR+(gRadioCtrl.MaxCh<<1) + 1), (BYTE)(gRadioCtrl.Freq));
					//eepWrByte(EEP_ADR_FREQ, (BYTE)(gRadioCtrl.Freq>>8));
					//eepWrByte(EEP_ADR_FREQ+1, (BYTE)(gRadioCtrl.Freq));


					//������Ƶ����Ŀ,����м��˳�
					gRadioCtrl.MaxCh++;	//lxl
					EEPROM_WriteByte( (BYTE)(EEP_ADR_SAVE_CH_NUM) , (BYTE)gRadioCtrl.MaxCh );
								
					DBG((" Radio  Freq Save MAX_CH=%d\n", (short)gRadioCtrl.MaxCh));
					DBG((" Radio  Freq Save Freq=%d\n", (short)gRadioCtrl.Freq));
					//ShowRadioFre10Pixels(gRadioCtrl.Freq);
//					RadioSetMemSaveFlag(gRadioCtrl.MaxCh);//lxl comment
					//radioDispCh(gRadioCtrl.MaxCh);
					TimeOutSet(&SeekDelay, (1000) );	
					gRadioCtrl.SeekSts = SEARCH_DISP;
				}
			}
			
			break;

		case	SEARCH_DISP:
			if (!IsTimeOut(&SeekDelay))	break;
			gRadioCtrl.SeekSts = SEARCH_DISP_00;
			//DBG(("SEARCH_DISP ----------------\n"));
			break;

		case	SEARCH_DISP_00:
			if (!IsTimeOut(&SeekDelay))	break;
			//DBG(("SEARCH_DISP_00 ----------------\n"));
			gRadioCtrl.SeekSts = SEARCH_DISP_01;
			break;

		case	SEARCH_DISP_01:
			if (!IsTimeOut(&SeekDelay))	break;
			//DBG(("SEARCH_DISP_01 ----------------\n"));
			gRadioCtrl.SeekSts = SEARCH_NEXT;
			break;		
			
		case	SEARCH_NEXT:
			//DBG(("SEARCH_NEXT ----------------\n"));
			gRadioCtrl.Freq++;
			if (gRadioCtrl.Freq > 1080)
			{
				//gRadioCtrl.Freq = 875;
				gRadioCtrl.SeekSts = SEARCH_OK;
			}
			else
			{
				gRadioCtrl.SeekSts = SEARCH_START;
				//RadioFreqSet_drv();
				TimeOutSet(&SeekDelay, (10/CLK_DIV_RATE) );
			}
			break;
				
		case	SEARCH_OK:
			DBG(("SEARCH_OK ----------------\n"));
			RADIO_SET_FLAG(RADIO_SAVE_CH_SUM_FLAG_REL);
			FmModeInit();
			if (gRadioCtrl.MaxCh> 0)
			{
				gRadioCtrl.Freq = gRadioCtrl.MemFreq[gRadioCtrl.CurCh++];
			}
			else
			{
				gRadioCtrl.Freq = 875;
			}
			RadioFreqSet();
			RadioMuteDis();
			ShowWholeRadioFre(gRadioCtrl.Freq);
			//paceAudioSwMuteOff();
			//paceAudioFastMuteOn(300);	//lxl 7-24
			//��õ�ǰƵ����Ϣ��Ƶ�����
			RadioChkChNum(1);

			
			
			//���浱ǰƵ����Ϣ,�´�����FM�����Ƶ��
			EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_MSB ), (BYTE)(gRadioCtrl.Freq>>8));
			EEPROM_WriteByte( (BYTE)( EEP_ADR_FREQ_LSB ), (BYTE)(gRadioCtrl.Freq));
			//������Ƶ����Ŀ,����м��˳�
			EEPROM_WriteByte( (BYTE)(EEP_ADR_CUR_CHL_NO), (BYTE)(gRadioCtrl.CurCh));
			EEPROM_WriteByte( (BYTE)(EEP_ADR_SAVE_CH_NUM), (BYTE)(gRadioCtrl.MaxCh));
			
			if(gRadioCtrl.CurCh)
				radioDispSetSts(RADIO_DISP_STS_CH);
			else
				radioDispSetSts(RADIO_DISP_STS_FREQ);
			//radioDispFreq();
			return 1;
			//break;
			
		default:
			break;
	}
        return 0;
}


#if 0	//lxl to reduce target size 8-2
/********************************************************
Function:
Input:
Output:
Description:

********************************************************/
BYTE	RadioSavePrc(void)
{

	BYTE	byte_cnt=0;
	BYTE	bit_cnt=0;
	BYTE	wk=0;

	if (gRadioCtrl.Stauts != RADIO_STS_IDLE)
		return 1;
	
	for (byte_cnt=0; byte_cnt<FLAG_NUMB; byte_cnt++)
	{
		if (0 != radioSaveflag[byte_cnt])
			break;
	}
	if (byte_cnt >= FLAG_NUMB)
		return 1;

	for (bit_cnt=0; bit_cnt<8; bit_cnt++)
	{
		if ((1<<bit_cnt)&radioSaveflag[byte_cnt])
			break;
	}	
	wk = (byte_cnt<<3)+bit_cnt;
	if (RADIO_GET_FLAG(wk))
	{
		RADIO_CLR_FLAG(wk);
		#if 0	//lxl 7-24
		if (wk == RADIO_SAVE_CUR_FREQ_H_FLAG_REL)
		{
			//EEPROM_WriteByte(BYTE Addr, (BYTE)(gRadioCtrl.Freq>>8));
			eepWrByte(EEP_ADR_FREQ, (BYTE)(gRadioCtrl.Freq>>8));
			DBG((" Radio Save Cur FREQ H = %d\n",gRadioCtrl.Freq));
		}
		else if (wk == RADIO_SAVE_CUR_FREQ_L_FLAG_REL)
		{
			eepWrByte(EEP_ADR_FREQ+1, (BYTE)(gRadioCtrl.Freq));
			DBG((" Radio Save Cur FREQ L = %d\n",gRadioCtrl.Freq));
		}
		else if (wk == RADIO_SAVE_CH_SUM_FLAG_REL)
		{
			eepWrByte(EEP_ADR_SAVE_CH_NUM, gRadioCtrl.MaxCh);

			DBG((" Radio Save Mem Ch = %d\n",(WORD)gRadioCtrl.MaxCh));
		}
		else
		{
			if ((wk-RADIO_SAVE_MEM_FREQ_FLAG_REL) & 1)
			{
				eepWrByte(EEP_ADR_FM1_MEM_STR+(wk-RADIO_SAVE_MEM_FREQ_FLAG_REL), (BYTE)gRadioCtrl.MemFreq[(wk-RADIO_SAVE_MEM_FREQ_FLAG_REL)>>1]);
			}
			else
			{
				eepWrByte(EEP_ADR_FM1_MEM_STR+(wk-RADIO_SAVE_MEM_FREQ_FLAG_REL), (BYTE)(gRadioCtrl.MemFreq[(wk-RADIO_SAVE_MEM_FREQ_FLAG_REL)>>1]>>8));
			}
		}
		#endif
	}
	return 0;

}
#endif

void ShowSearchedRadioFre( WORD Freq )
{

	BYTE ChannelLoop = 0 ;

	for( ChannelLoop = 0 ; ChannelLoop < gRadioCtrl.MaxCh ; ChannelLoop++ )
	{
		if(gRadioCtrl.MemFreq[ChannelLoop] <= Freq )
		{
			ShowRadioFre10Pixels(gRadioCtrl.MemFreq[ChannelLoop]);	
		}
		else
		{
			break ;
		}
	}

	return ;
}

//#endif
