#ifndef _LRC_H_
#define _LRC_H_


#define MAX_LRCSECTLIST_CNT	12

// character code
#define CHAR_ANSI			0
#define CHAR_UNICODE_BE		0xEF	//FEFF �͵�ַ����(Big Endian)
#define CHAR_UNICODE		0xFE	//FFFE �ߵ�ַ����
#define CHAR_UTF8_BE		0xF8	//U+FEFF(Big Endian)
#define CHAR_UTF8			0x8F	//U+FFFE


typedef struct _LRC_TIME
{
	BYTE Min;
	BYTE Sec;
	BYTE Msec;
} LRC_TIME;

typedef enum _LABEL_TYPE
{
	LABEL_AR,
	LABEL_TI,
	LABEL_AL,
	LABEL_BY,
	LABEL_TIME_OFFSET, 
	LABEL_TIME,
	LABEL_LINE_END,
	LABEL_FILE_END,
	LABEL_UNKNOWN
} LABEL_TYPE;

typedef struct	_LRC_ROW
{					
	BYTE XDATA*		pLrcData;   	// the buffer-address which is use to store the lyric-data.
	BYTE			Len;			// the length										
} LRC_ROW;


typedef struct _ST_LRC_SECT{
	DWORD dwStartSect;
	BYTE  ucSectCnt;
} ST_LRC_SECT; 


typedef struct _ST_LRC_ROWLIST{
	WORD wDispTime;	// UNIT: 100ms.
	WORD wOffset;	// offset in lrc file.
	BYTE ucLen;	   	// the number of bytes of lyric.
} ST_LRC_ROWLIST;


typedef struct _ST_LRCINFO{
	WORD wFileSize;			// lrc�ļ���С,���֧��64KB.
	BYTE ucRowSum;			// ���������(���֧�ֵ�MAX_LRC_ROW_NUM).
	BYTE ucMaxRowNum;
	BYTE ucSectListLen;
	ST_LRC_SECT stSectList[MAX_LRCSECTLIST_CNT];
	BYTE ucPrevRowNum;
	BYTE ucLrcBuffSz;
} ST_LRCINFO;

typedef struct _ST_LRC_LFN{
	BYTE Length;
	BYTE Name[66];
} ST_LRC_LFN;

extern XDATA BYTE 		gucaLrcContent[];
extern ST_LRC_LFN		gstLrcLongFileName;
extern  BYTE bUnicode; 	// 0xFE = 0xFFFE UNIC 
					 	// 0xEF = 0xFEFF UNIC
					 	// 0xF8 = 0xEFBBBF	UTF-8 -->0xFEFF
					 	// 0x8F = 0xEFBFBE	UTF-8 -->0xFFFE

// Parse Lrc File.
//TRUE ->�ҵ�ƥ��ĸ���ļ��������ɹ�. 
//FALSE->û�ҵ�ƥ��ĸ���ļ����޷�����.			
BOOL ParseLrc(FOLDER* Folder, BYTE* FileName);
	
// Get lyric content(Fit to Time).	 		  
//PlayTime ->��ǰ����ʱ��
//NULL ->û�ҵ�ƥ��ĸ��. !NULL->�ҵ�ƥ��ĸ��.
LRC_ROW* GetLrcRow(WORD PlayTime);


#endif
