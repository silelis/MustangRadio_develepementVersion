#include "syscfg.h"

BOOL gDeviceError;

// Read data blocks from storage device, it is the interface 
// between file system and storage device.
// Example: You want to read 4 blocks from block 100 of device 1, 
// and data buffer start address is 0xC000, call this funciton as follow
// "ReadBlock(1, 100, (BYTE XDATA *)0xC000, 4);" After this funciton, 
// 4 blocks data have been loaded into the buffer, which start address is 0xC000.
BOOL ReadBlock(DWORD block, WORD buffer, BYTE size)
{			
	FeedWatchDog();

	gDeviceError = FALSE;

#ifdef FUNC_USB_EN
	if(gFsInfo.DevID == DEV_ID_USB)
	{													//read usb disk
		if(HostReadBlock(block, (BYTE XDATA*)buffer, size))
		{
			return TRUE;
		}
	}
#endif

#ifdef FUNC_CARD_EN
	if(gFsInfo.DevID == DEV_ID_SD)
	{													//read card 
		if(ReadCardStorBlock(block, buffer, size))
		{
			return TRUE;
		}
	}
#endif
	
	gDeviceError = TRUE;
	return FALSE;
}


BOOL WriteBlock(DWORD block, WORD buffer, BYTE size)
{			
	FeedWatchDog();

#ifdef FUNC_USB_EN
	if(gFsInfo.DevID == DEV_ID_USB)
	{													//read usb disk
		return HostWriteBlock(block, (BYTE XDATA*)buffer, size);
	}
#endif

#ifdef FUNC_CARD_EN
	if(gFsInfo.DevID == DEV_ID_SD)
	{													//read card 
		return WriteCardStorBlock(block, buffer, size);
	}
#endif
	
	return FALSE;
}


//¼�������д���¼�����ݣ���lib���е��ļ�ϵͳ�ص�
VOID RecordCallBack()
{
	extern VOID RecordSaveData();

#ifdef FUNC_RECORD_EN
	RecordSaveData();
#endif
}

