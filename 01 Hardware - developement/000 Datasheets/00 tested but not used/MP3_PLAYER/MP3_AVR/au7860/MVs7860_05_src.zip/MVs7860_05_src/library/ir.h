#ifndef _IR_H_
#define	_IR_H_

VOID IrInit();
BOOL IrIsKeyCome();
DWORD IrGetKeyCode();
BOOL IrIsContinuePrs();
VOID IrIgnoreLeadHeader(BOOL IsIgnore);


#endif
