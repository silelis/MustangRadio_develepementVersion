#include "syscfg.h"


#define EEPROM_WRITE_TIME	10		//10ms

#define	IIC_READ	0x01
#define	IIC_WRITE	0x00

		
//#define SetInputSCL()	ClrGpioRegBit(I2C_SCL_PORT_OE, I2C_SCL_BIT)
 #define SetOutputSCL()	SetGpioRegBit(I2C_SCL_PORT_OE, I2C_SCL_BIT); 
 #define SetSCL()		SetGpioRegBit(I2C_SCL_PORT_OUT, I2C_SCL_BIT); I2C_Delay()
 #define ClrSCL()		ClrGpioRegBit(I2C_SCL_PORT_OUT, I2C_SCL_BIT); I2C_Delay()
 //#define GetSCL()		(GetGpioReg(I2C_SCL_PORT_IN) & I2C_SCL_BIT)
 
 #define SetInputSDA()	ClrGpioRegBit(I2C_SDA_PORT_OE, I2C_SDA_BIT); 
 #define SetOutputSDA()	SetGpioRegBit(I2C_SDA_PORT_OE, I2C_SDA_BIT);
 #define SetSDA()		SetGpioRegBit(I2C_SDA_PORT_OUT, I2C_SDA_BIT); I2C_Delay()
 #define ClrSDA()		ClrGpioRegBit(I2C_SDA_PORT_OUT, I2C_SDA_BIT); I2C_Delay()
 #define GetSDA()		(GetGpioReg(I2C_SDA_PORT_IN) & I2C_SDA_BIT)

#define Set_CLK_PU()	ClrGpioRegBit(GPIO_E_PU, I2C_SCL_BIT),\
                        ClrGpioRegBit(GPIO_E_PD, I2C_SCL_BIT);

#define Set_SDA_PU()	ClrGpioRegBit(GPIO_E_PU, I2C_SDA_BIT),\
                        ClrGpioRegBit(GPIO_E_PD, I2C_SDA_BIT);\
				SetGpioRegBit(GPIO_E_DS, I2C_SDA_BIT);



VOID I2C_Delay()
{

//	return ;
	
	//BYTE i = 10;
	//while(i--);
}

VOID I2C_Init(VOID)
 {
 	//CLK , SDA���ʹ��










 	SetOutputSCL();
	SetOutputSDA();
 	//CLK,SDA�����Ϊ1
 	SetSDA();
	SetSCL();
 	//SDA PD = 0
 	//SDA PU = 0
 	Set_SDA_PU();
 	//SDA DS = 1
}
// send START signal. 
VOID I2C_Start()
{
	SetSDA();
	SetSCL();
	
	SetOutputSCL();
	SetOutputSDA();

	SetSDA();
	SetSCL();
	ClrSDA();
	ClrSCL();
}

// send STOP signal. 
VOID I2C_Stop()
{
//	DBG(("I2C_Stop()\n")); 
	SetOutputSCL();
	SetOutputSDA();
	
	ClrSDA(); 	
	SetSCL();
	SetSDA();

	SetInputSDA();
}

// send Acknowledgement(ACK or NACK) signal. 
VOID I2C_SendAck()
{
//	DBG(("I2C_SendAck()\n")); 	
	ClrSDA(); 
	SetSCL();
	ClrSCL();
}

// send Acknowledgement(ACK or NACK) signal. 
VOID I2C_SendNoAck()
{
	SetSDA(); 
	SetSCL();
	ClrSCL();
}

// Check Ackowledge signal(ACK/NACK). 
BOOL I2C_ChkAck()
{
	BOOL	Ack;

	ClrSCL();
	SetInputSDA();
	SetSCL();
	Ack = !GetSDA();
	ClrSCL();
	return Ack;
}

// Send one byte via I2C(check ACK). 
BOOL I2C_WriteByte(BYTE Dat)
{
	BYTE i = 8;

//	DBG(("I2C_WriteByte(%-.2BX)\n", Dat)); 
	SetOutputSDA();	 
	ClrSCL();
	while(i--)
	{
		if(Dat & 0x80)				//MSB output first
		{
		  	SetSDA(); 
		}
		else
		{
			ClrSDA(); 
		}
		Dat <<= 1;
		SetSCL();
		ClrSCL();
	}
	return I2C_ChkAck();
}

// Receive one byte via I2C. 
BYTE I2C_ReadByte()
{
	BYTE i = 8;
	BYTE Dat = 0;

	SetInputSDA();
	while(i--)
	{	
		Dat <<= 1;
		if(GetSDA())
		{
		  	Dat |= 0x01;
		}
		SetSCL();
		ClrSCL();	 
	}
	SetOutputSDA();
	return Dat;
}


BOOL I2C_WriteBytes(BYTE* Buf, BYTE Len)
{
	while(Len--)
	{
		if(!I2C_WriteByte(*(Buf++)))
		{
			DBG(("write data err\n"));
			return FALSE;
		}
	}

	return TRUE;
}

// Read data via I2C. 
BOOL I2C_ReadBytes(BYTE* Buf, BYTE Len)
{
	while(Len--)
	{
		*(Buf++) = I2C_ReadByte();
		if(Len == 0)
		{
			I2C_SendNoAck();
		}
		else
		{
			I2C_SendAck();
		}
	}

	return TRUE;
}


// send address via IIC.
BOOL I2C_SendAddr(BYTE icAddr, WORD wAddr, BYTE ucRW)
{	
	I2C_Start();
	if(!I2C_WriteByte(icAddr))
	{
		WaitMs(EEPROM_WRITE_TIME); // Wairt for Programming-time.
		I2C_Start();
		if(!I2C_WriteByte(icAddr))// | PageAddr))
		{
			I2C_Stop();
			return FALSE;
		}
	}
	
   	if(!I2C_WriteByte((BYTE)wAddr))
	{
	 	I2C_Stop();
		return FALSE;
	}
	
	if(ucRW == IIC_READ)
	{
		I2C_Start();
		if(!I2C_WriteByte(icAddr| IIC_READ))
		{
		 	I2C_Stop();
			return FALSE;
		}
	}
	
	return TRUE;
}


// Write data to eeprom from buffer
BOOL I2C_WriteNByte(BYTE devAddr,WORD Addr, BYTE* Buf, BYTE Len)
{
	BOOL	acktemp = FALSE;
		
	acktemp = I2C_SendAddr(devAddr, Addr, IIC_WRITE);
	acktemp &= I2C_WriteBytes(Buf, Len);
	I2C_Stop();

	return acktemp;
}


// Read data from eeprom.
BOOL I2C_ReadNByte(BYTE devAddr,WORD Addr, BYTE* Buf, BYTE Len)
{
	BOOL	acktemp = FALSE;

	acktemp = I2C_SendAddr(devAddr,Addr,IIC_READ);
	acktemp &= I2C_ReadBytes(Buf, Len);
	I2C_Stop();

	return acktemp;
}



