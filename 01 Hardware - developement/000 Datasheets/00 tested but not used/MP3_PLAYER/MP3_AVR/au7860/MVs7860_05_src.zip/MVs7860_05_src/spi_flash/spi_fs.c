#include "syscfg.h"
#include "spi_flash.h"


#ifdef FUNC_SPI_FS_EN


#define		SPI_DEV_CUSTOMER_ID		0x55AA01FE
#define		MVFAT_START_ADDR		32



//the SPI flash file system boot header. 
//a copy of this data structure must be stored at the 0x0000 address of the SPI flash.
typedef	struct _SPI_FS_HEAD
{
	DWORD	SpiDevCustomerId;
	DWORD	FlashSize;
	WORD	TotalFileNum;
	BYTE	Mp3FileSum;
	BYTE	TxtFileSum;
	BYTE	OthFileSum;
	BYTE    Reserved[19];

} SPI_FS_HEAD;


//the file entry structure in the SPI flash file system.
typedef struct _SPI_FILE_ENTRY
{
	DWORD	StartAdd;									//file entry addr
	DWORD	FileSize;									//file size in byte
	BYTE	FileName[8];

} SPI_FILE_ENTRY;


//the file type in SPI flash FS.
typedef enum _SPI_FILE_TYPE
{
	SPI_FILE_MP3 = 0,
	SPI_FILE_TXT,
	SPI_FILE_OTH

} SPI_FILE_TYPE;


static SPI_FS_HEAD SpiFsHeader;



// SPI flash file system initial.
BOOL SpiFsInit()
{
//	DBG(("SpiFlashFsInit\n"));
	SpiFlashRead(0, (BYTE*)&SpiFsHeader, sizeof(SPI_FS_HEAD));

//	DBG(("SpiDevCustomerId: 0x%-.8LX\n", SpiFsHeader.SpiDevCustomerId));
	DBG(("FileNum: %d (%d, %d, %d)\n", 
			(WORD)SpiFsHeader.TotalFileNum, 
			(WORD)SpiFsHeader.Mp3FileSum, 
			(WORD)SpiFsHeader.TxtFileSum, 
			(WORD)SpiFsHeader.OthFileSum));

	if(SpiFsHeader.SpiDevCustomerId != SPI_DEV_CUSTOMER_ID)
	{	
//		DBG(("invalid spi dev!\n"));
		return FALSE;
	}

//	DBG(("valid spi dev!\n"));
	gFsInfo.FolderSum = 1;
	gFsInfo.FileSum = SpiFsHeader.Mp3FileSum;

	return TRUE;
}


// Open the specified file in SPI flash file system.
BOOL SpiFsFileOpen(FILE* File, WORD FileNum, BYTE FileType)
{
	WORD TempFileNum;
	SPI_FILE_ENTRY	FileEntry;

	if(FileType == SPI_FILE_OTH)
	{
		if (FileNum > SpiFsHeader.OthFileSum)
		{
			return FALSE;
		}
		TempFileNum = FileNum;
		File->FileType = FILE_TYPE_UNKNOWN;
	}
	else if(FileType == SPI_FILE_MP3)
	{
		if(FileNum > SpiFsHeader.Mp3FileSum)
		{
			return FALSE;
		}
		TempFileNum = (FileNum + SpiFsHeader.OthFileSum);
		File->FileType = FILE_TYPE_MP3;
	}
	else if(FileType == SPI_FILE_TXT)
	{
		if(FileNum > SpiFsHeader.TxtFileSum)
		{
			return FALSE;
		}
		TempFileNum = (FileNum + SpiFsHeader.OthFileSum + SpiFsHeader.Mp3FileSum);
		File->FileType = FILE_TYPE_UNKNOWN;
	}
	else
	{
		return FALSE;
	}

	SpiFlashRead(MVFAT_START_ADDR + (TempFileNum - 1)*sizeof(SPI_FILE_ENTRY), (BYTE*)&FileEntry, sizeof(SPI_FILE_ENTRY)); 	//get file entry

	memset(&File->ShortName[0], '0', 4);
	memcpy(&File->ShortName[4], &FileEntry.FileName[0], 4);
	memcpy(&File->ShortName[8], &FileEntry.FileName[5], 3);
	
	File->FileNumInDisk = FileNum;
	File->FolderNum = 1;
	File->FileNumInFolder = FileNum;

	File->Size = FileEntry.FileSize;
	File->StartSec = FileEntry.StartAdd;	//�ļ���SPI FLASH�е���ʼ��ַ
	File->OpSec = File->StartSec;
	File->OpSecCnt = 0;
	File->SecNum = File->Size; 
	
	return TRUE;	
}


//Read File data from the specified file.	   
//File data buffer 16bit address 
//Read operation data length in bytes
WORD SpiFsFileRead(FILE* File, WORD Buffer, WORD Len)
{
	if(File->OpSecCnt + Len > File->SecNum)
	{
		Len = File->SecNum - File->OpSecCnt;
	}
		
	SpiFlashRead(File->OpSec, (BYTE XDATA*)Buffer, Len);
	File->OpSec += Len;
	File->OpSecCnt += Len;

	return Len;
}


//���ļ��У�ֻ����1���ļ���
BOOL SpiFsFolderOpen(FOLDER* Folder, WORD FolderNum)
{
	if(FolderNum != 1)
	{
		return FALSE;
	}

	Folder->FolderNum = 1;
	Folder->ValidFolderNum = 1;
	Folder->ShortName[0] = '\\';
	Folder->ShortName[1] = '\0';
	Folder->StartFileNum = 1;
	Folder->IncFileCnt = SpiFsHeader.Mp3FileSum;
	Folder->IncFolderCnt = 0;
	Folder->RecFileCnt = SpiFsHeader.Mp3FileSum;
	Folder->RecFolderCnt = 0;

	return TRUE;
}


// Seek file like the standard C library function, but the unit is sector..
BOOL SpiFsFileSeek(FILE* File, SDWORD Offset, BYTE Base)
{
	Offset *= SECTOR_SIZE;
	if(Base == SEEK_FILE_END)
	{
		Offset += File->SecNum;
	}
	else if(Base == SEEK_FILE_CUR)
	{
		Offset += File->OpSecCnt;	
	}
	
	if(Offset > File->SecNum)
	{
		Offset = File->SecNum;
		File->OpSec = File->StartSec + Offset;
		File->OpSecCnt = Offset;
		return FALSE;
	}

	File->OpSec = File->StartSec + Offset;
	File->OpSecCnt = Offset;

	return TRUE;
}

#endif

