#ifndef _IR_KEY_H_
#define _IR_KEY_H_


// IR decoder initilize.
VOID IrKeyScanInit();

// Check IR key value from IR controller.
BYTE IrKeyEventGet();

#endif 
