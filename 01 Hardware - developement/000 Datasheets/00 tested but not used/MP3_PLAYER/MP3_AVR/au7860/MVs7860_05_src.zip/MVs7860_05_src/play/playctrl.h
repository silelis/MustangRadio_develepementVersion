#ifndef _PLAYCTRL_H_
#define _PLAYCTRL_H_


// Define playing mode.
typedef enum _PLAY_MODE
{
	PLAY_MODE_REPEAT_ALL = 0,
	PLAY_MODE_RANDOM,
	PLAY_MODE_REPEAT_ONE,
	PLAY_MODE_INTRO,

	PLAY_MODE_SUM
	
} PLAY_MODE;


typedef enum _PLAY_DIRECT
{
	PLAY_DIRECT_NEXT,
	PLAY_DIRECT_PRE,
	PLAY_DIRECT_NEXT_10,
	PLAY_DIRECT_PRE_10
	
} PLAY_DIRECT;


// Define playing control state structure.
typedef enum _PLAY_STATE
{
	PLAY_STATE_IDLE = 0,
	PLAY_STATE_STOP,
	PLAY_STATE_PLAY,
	PLAY_STATE_PAUSE,
	PLAY_STATE_FF,
	PLAY_STATE_FB,
	PLAY_STATE_BROWSE,
	
} PLAY_STATE;


// Paly error type.
typedef enum _PLAY_ERROR
{
	PLAY_ERROR_NONE = 0,
	PLAY_ERROR_SONG_INIT,
	PLAY_ERROR_SONG_CMPT,
	PLAY_ERROR_PLAY_DO
	
} PLAY_ERROR;

// Define play control structure.
typedef struct _PLAY_CTRL
{
	PLAY_STATE		State;	
	BYTE			Event;

	BYTE			RepeatMode;
	BYTE			Eq;
	BYTE			Direction;

	BOOL			FolderEnable;	
	WORD			FolderNum;	
	FOLDER			Folder;

	WORD			FileNum; 
	FILE			File;
	
	BOOL 			LrcFlag;

} PLAY_CTRL;


extern PLAY_CTRL gPlayCtrl;


BOOL PlayCtrlInit();			
VOID PlayStateCtrl();									
BOOL PlayCtrlEnd();
BOOL SongPlayInit();
VOID StartSleepTimer( VOID );
// External interface for updating song data for playing.
// Note: in AP layer code (such as LED display program),
//	the function is invoked to keeping song playing continuously.
BOOL SongPlayDo();


#endif
