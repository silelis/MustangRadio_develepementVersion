#ifndef _ADC_KEY_H_
#define _ADC_KEY_H_


// Initialize adc key scan (GPIO) operation.
VOID AdcKeyScanInit();

// Key process, image key value to key event.
BYTE AdcKeyEventGet();

#endif 
