#ifndef _INT_H_
#define _INT_H_


// bit mask of INT_EN_ADR_REG, INT_MASK_ADR_REG, INT_FLAG_REG
// used by the functions:
#define			MASK_INT_TIME				(1 << 0)
#define			MASK_INT_GPIOC				(1 << 1)
#define			MASK_INT_FIFO				(1 << 2)
#define			MASK_INT_SDSPI				(1 << 3)
#define			MASK_INT_OTG_DMA			(1 << 4)
#define			MASK_INT_OTG_MC				(1 << 5)
#define			MASK_INT_RTC				(1 << 6)
#define			MASK_INT_FAST_UART			(1 << 7)


// Enable the corresponding extended interrupts' source.
VOID SetIntEnBit(BYTE bMask);

// Disable the corresponding extended interrupts' source.
VOID ClrIntEnBit(BYTE bMask);

// Get the value of interrupt enable register.
BYTE GetIntEn();

// Clear extended interrupts' flag bit.
// Note: call it after response the interrupt.
VOID ClrIntFlagBit(BYTE bMask);

// Get the triggered extended interrupts' flag.
BYTE GetIntFlag();				

// Mask extended interrupts' trigger, used to mask unexpectable interrupt signal.
VOID SetIntMask(BYTE bMask);

// Enable auto mask interrupt when access to the share buffer.
VOID EnBufAutoMaskInt();

// Set extended Timer's counter value.
// Note: This is a extended timer. It bases on 12MHz clock, counter unit is 83ns. The counter value is 0 ~ 0xFFFFFF.
//		 Need not update initial value in interrupt process.
VOID SetTimerCnt(DWORD dwVal);


#endif
