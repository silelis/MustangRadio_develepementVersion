#include "syscfg.h"


#ifdef FUNC_GPIO_KEY_EN

#define 	GPIO_KEY_SCAN_TIME			20
#define 	GPIO_KEY_JITTER_TIME			30
#define 	GPIO_KEY_CP_TIME				2000
#define 	GPIO_KEY_CPH_TIME				450


#define		GPIO_KEY_COUNT				10

#define		GPIO_KEY_COUNT				10 			//key count per GPIO channel
#define		GPIO_KEY_FULL_VAL			4096		//


typedef enum _GPIO_KEY_STATE
{
	GPIO_KEY_STATE_IDLE,
	GPIO_KEY_STATE_JITTER,
	GPIO_KEY_STATE_PRESS_DOWN,
	GPIO_KEY_STATE_CP

} GPIO_KEY_STATE;

TIMER			GPIOKeyWaitTimer;
TIMER			GPIOKeyScanTimer;
GPIO_KEY_STATE	GPIOKeyState;

//#ifdef ORT

//����3�볤��,��5��
static CODE BYTE GPIOKeyEvent[][4] = 
{
					//3���ʱ����	//һֱ����	//�ͷ�
//	SP					CPS					CPH				CPR
//	{MSG_LIGHT, 		MSG_POWER, 		MSG_NONE, 		MSG_NONE	},	//GPIO_C_2
	{MSG_LIGHT, 		MSG_POWER, 		MSG_NONE, 		MSG_NONE	},	//GPIO_C_2
};

#if 0
// Key process, image key value to key event.
static BYTE GPIOChannelKeyGet(BYTE Channel)							
{
	WORD	Val;
	BYTE	KeyIndex;

	Val = GPIOReadOneChannel(Channel, GPIO_VREF_AVDD33);

	if(Val >= (GPIO_KEY_FULL_VAL - (GPIO_KEY_FULL_VAL/GPIO_KEY_COUNT)/2))
	{
	 	return -1;	//no pressed key.
	}

	KeyIndex = (Val + (GPIO_KEY_FULL_VAL/GPIO_KEY_COUNT)/2)*GPIO_KEY_COUNT/GPIO_KEY_FULL_VAL;

	return KeyIndex;
}



static BYTE GetGPIOKeyIndex()
{

#ifdef ORT
//	BYTE KeyIndex = GPIOChannelKeyGet(GPIO_CHANNEL_E4);
	BYTE KeyIndex = POWERKEY_PORT_LED_CTRL_GET
#endif

//	if(KeyIndex != -1)
//	{
//		DBG(("KeyIndex: %d\n", (WORD)KeyIndex));
//	}
	if(-1 != KeyIndex)
	{
		DBG(("KEY INDEX = %d\n" , (short)KeyIndex));
	}
	return KeyIndex;
}
#endif

// Initialize hardware key scan (GPIO) operation.
VOID GPIOKeyScanInit()
{
	GPIOKeyState = GPIO_KEY_STATE_IDLE;
	TimeOutSet(&GPIOKeyScanTimer, 0);
	POWERKEY_PORT_LED_CTRL_IN_EN
//fdef ORT	
#if 0 //??????
	SET_GPIO_C1_INOUT();		
	SET_GPIO_C2_IN();
#endif
}


// Key process, image key value to key event.
BYTE GPIOKeyEventGet()							
{
	//static 	BYTE 	PreKeyIndex = -1;
//	BYTE			KeyIndex;
BYTE			KeyStatus;
//	BYTE		event = MSG_NONE;
	static	BYTE	CPHCnt = 0 ;
//	DBG(("GPIOKeyEventGet*******\n"));
	if(!IsTimeOut(&GPIOKeyScanTimer))
	{
		return MSG_NONE;
	}
	TimeOutSet(&GPIOKeyScanTimer, GPIO_KEY_SCAN_TIME);	

	//KeyIndex = GetGPIOKeyIndex();
	KeyStatus = POWERKEY_PORT_LED_CTRL_GET ;
	//DBG(("KEYSTATUS = %u!\n , (short)KeyStatus"));
	switch(GPIOKeyState)
	{
		case GPIO_KEY_STATE_IDLE:
			//CPHCnt = 0 ;
			if(KeyStatus != 0)
			{
				return MSG_NONE;
			}
			//PreKeyIndex = KeyIndex;
			TimeOutSet(&GPIOKeyWaitTimer, GPIO_KEY_JITTER_TIME);
			
			DBG(("GOTO JITTER!\n"));
			GPIOKeyState = GPIO_KEY_STATE_JITTER;
				
		case GPIO_KEY_STATE_JITTER:
			//CPHCnt = 0 ;
			if(KeyStatus != 0)
			{
				DBG(("GOTO IDLE Because jitter!\n"));
				GPIOKeyState = GPIO_KEY_STATE_IDLE;
			}
			else if(IsTimeOut(&GPIOKeyWaitTimer))
			{
				DBG(("GOTO PRESS_DOWN!\n"));
 				TimeOutSet(&GPIOKeyWaitTimer, GPIO_KEY_CP_TIME);
				GPIOKeyState = GPIO_KEY_STATE_PRESS_DOWN;
			}
			break;

		case GPIO_KEY_STATE_PRESS_DOWN:
			CPHCnt = 0 ;
			if(KeyStatus != 0)
			{
				//return key sp value
				DBG(("from pressdown to idle \n"));
				GPIOKeyState = GPIO_KEY_STATE_IDLE;
				return GPIOKeyEvent[0][0];
			}
			else if(IsTimeOut(&GPIOKeyWaitTimer))
			{
				//return key cp value
				DBG(("GPIO KEY CP!\n"));
				TimeOutSet(&GPIOKeyWaitTimer, GPIO_KEY_CPH_TIME);
				GPIOKeyState = GPIO_KEY_STATE_CP;
				return GPIOKeyEvent[0][1];
			}
			break;

		case GPIO_KEY_STATE_CP:
			
//////////////////////////////////
			if(KeyStatus != 0)
			{
				//return key cp value
				DBG(("from cp to idle!\n"));
				GPIOKeyState = GPIO_KEY_STATE_IDLE;
				return GPIOKeyEvent[0][3];		//��������
			}
			else if(IsTimeOut(&GPIOKeyWaitTimer))
			{
				//return key cph value
				DBG(("gpio in  KEY CPH!\n"));
				TimeOutSet(&GPIOKeyWaitTimer, GPIO_KEY_CPH_TIME);
				return GPIOKeyEvent[0][2];			//����1�����������
			}
			break;
/////////////////////////////////

		default:
			GPIOKeyState = GPIO_KEY_STATE_IDLE;
			break;
	}
	return MSG_NONE;

}
#else
	#warning	"MV: GPIO KEY NOT ENABLE!"
#endif

