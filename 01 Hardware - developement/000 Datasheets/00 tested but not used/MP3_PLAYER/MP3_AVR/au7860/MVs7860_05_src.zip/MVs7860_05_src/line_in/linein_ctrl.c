#include "syscfg.h"
#include "sysctrl.h"
#include "record_ctrl.h"
#include "device.h"


#ifdef FUNC_LINEIN_EN

//static BYTE LineInVolume = 4;
// Volume table in dB set.
BYTE CODE gLineInGain[VOLUME_MAX + 1] = 
{
	63,
	62,		58, 	54,		51,		48,		45,		42,		39,	
	37,		35,		33,		31,		29,		27,		25,		23,	
	21,		19,		17,		15,		14,		13,		12,		11,	
	10,		9,		8,		7,		6,		5,		4,		3
};


TIMER	LineInOpen;
static	BOOL LineInOpenFg;



extern VOID SysClkDivSet(BYTE ClkDivRate);
extern VOID SysClkDivClr();

#ifdef FUNC_RECORD_EN
static	BOOL LineInRecordFlag; 
extern FILE	RecordFile;
#endif

//set line-in volume.
VOID SetLineInVolume()
{
	InDacLineInGain(gLineInGain[gSys.Volume]);
	InDacMuteDis();
}


BOOL LineInCtrlInit()
{
	SetLineInVolume();
#ifdef FUNC_RECORD_EN
	LineInRecordFlag = FALSE;
#endif
	return TRUE;
}

#ifdef FUNC_RECORD_EN
BOOL LineInRecordInit()
{
	//¼��ǰ���豸��ʼ��

#ifdef FUNC_USB_EN
	//U�̵������Ӽ��
	if(IsUSBLink())
	{
		DBG(("IsUSBLink() OK!\n"));
		SysClkDivClr();
		if(HostStorInit())	
		{
			if(FSInit(DEV_ID_USB))
			{
				DBG(("FSInit() OK!\n"));
				return TRUE;
			}
		}
	}
#endif

#ifdef FUNC_CARD_EN
	//SD���������Ӽ��
	if(IsCardLink())
	{
		DBG(("IsCardLink() OK!\n"));
		SysClkDivClr();
		if(CardInit())	
		{
			if(FSInit(DEV_ID_SD))
			{
				DBG(("FSInit() OK!\n"));
				return TRUE;
			}
		}
	}
#endif
	
	DBG(("no device!\n"));
	return FALSE;
}
#endif


VOID LineInStateCtrl()
{
	MESSAGE event = MessageGet(MSG_FIFO_KEY);

	switch(event)
	{
		case MSG_VOL_ADD:	
			if(gSys.Volume < VOLUME_MAX)
			{
				gSys.Volume++; 
				SetLineInVolume();
			}
			break;
			
		case MSG_VOL_SUB:	
			if(gSys.Volume > VOLUME_MIN)
			{
				gSys.Volume--;
				SetLineInVolume();
			}	
			break;
			
		case MSG_MUTE:		//mute enable
			if(gSys.MuteFg)
			{
				gSys.MuteFg = FALSE;
				DBG(("mute disable\n"));
				SetLineInVolume();
			}
			else
			{
				gSys.MuteFg = TRUE;
				DBG(("mute enable\n"));
				InDacMuteEn();
			}
			break;

#ifdef FUNC_RECORD_EN
		case MSG_REC_START:	
			DBG(("record start...\n"));
			if(!LineInRecordInit())
			{
				break;
			}

			if(!RecordCtrlInit())
			{
				DBG(("RecordCtrlInit() error!\n"));
			}

			if(!RecordGenNewFile())
			{
				DBG(("RecordStart() error!\n"));
			}

			//MIC
			//MicEnable(MIC_GAIN_32DB); 
			WaitMs(200);
			RecordStart(&RecordFile, REC_SOURCE_DAC, REC_GAIN_0DB, REC_FMT_32KHZ_1CH);

			LineInRecordFlag = TRUE;
			break;

		case MSG_STOP:	
			DBG(("record stop...\n"));
			RecordEnd();
			//MicDisable();	//�ر�MIC
			LineInRecordFlag = FALSE;
			SysClkDivSet(CLK_DIV_RATE);
			break;
#endif

		default:
			break;
	}

#ifdef FUNC_RECORD_EN
	if(LineInRecordFlag)
	{
#ifdef FUNC_USB_EN
		if((gFsInfo.DevID == DEV_ID_USB) && (!IsUSBLink()))			//usb removed
		{
			LineInRecordFlag = FALSE;
		}
#endif

#ifdef FUNC_CARD_EN
		if((gFsInfo.DevID == DEV_ID_SD) && (!IsCardLink()))			//SD removed
		{
			LineInRecordFlag = FALSE;
		}
#endif

		if(!LineInRecordFlag)
		{
			DBG(("record stop...\n"));
			RecordEnd();
			MicDisable();	//�ر�MIC
			SysClkDivSet(CLK_DIV_RATE);
		}

	 	RecordTask();
	}
#endif
}

#endif
