#ifndef _USB_AUDIO_CTRL_H_
#define _USB_AUDIO_CTRL_H_

//initial usb audio device. 
BOOL DeviceAudioCtrlInit();

//end usb audio device.
VOID DeviceAudioCtrlEnd();

//usb audio device state control.
VOID DeviceAudioStateCtrl();

#endif
