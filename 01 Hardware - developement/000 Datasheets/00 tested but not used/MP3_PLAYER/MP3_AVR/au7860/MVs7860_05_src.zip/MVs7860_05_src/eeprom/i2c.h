#ifndef _I2C_H_
#define _I2C_H_

VOID I2C_Init();
VOID I2C_Start();
VOID I2C_Stop();
VOID I2C_SendAck();
VOID I2C_SendNoAck();
BOOL I2C_ChkAck();
BYTE I2C_ReadByte();
BOOL I2C_ReadBytes(BYTE* Buf, BYTE Len);
BOOL I2C_WriteByte(BYTE Dat);
BOOL I2C_WriteBytes(BYTE* Buf, BYTE Len);
BOOL I2C_WriteNByte(BYTE devAddr,WORD Addr, BYTE* Buf, BYTE Len);
BOOL I2C_ReadNByte(BYTE devAddr,WORD Addr, BYTE* Buf, BYTE Len);

#endif