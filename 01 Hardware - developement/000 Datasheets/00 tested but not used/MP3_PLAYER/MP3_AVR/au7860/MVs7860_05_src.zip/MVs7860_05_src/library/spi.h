#ifndef _SPI_H_
#define	_SPI_H_


//open spi bus.
//MISO: GPIO_B[4], MOSI: GPIO_B[6], CLK: GPIO_B[5], 
VOID SpiOpen(BYTE Mode, BYTE ClkDivExp);

//close spi bus.
VOID SpiClose();

// SPI module send byte.
VOID SpiSendByte(BYTE Val);

// SPI module receive byte
BYTE SpiRecvByte();

// SPI module send bytes.
VOID SpiSendBytes(BYTE* Buf, WORD Len);	

// SPI module receive bytes
VOID SpiRecvBytes(BYTE* Buf, WORD Len);

#endif

