#ifndef _BREAKPOINT_H_
#define _BREAKPOINT_H_


#define BP_SIGNATURE	0x5A

#if 0
typedef struct	_BP_INFO
{
	BYTE	Signature;			// Only when this field is equal to BP_SIGNATURE, this structure is valid.

	//USB
//	WORD	USB_Signature;		// usb signature, generated from usb id.
	WORD	USB_CurFolderNum; 	// Current folder number.							
	WORD	USB_CurFileNum; 	// Current file number.
	DWORD	USB_CurPlayTime; 	// Current paly time.
	WORD	USB_FolderSum; 		// folder sum.							
	WORD	USB_FileSum; 		// file sum in u-disk.
	BYTE	USB_FileName[8];	// file name

	//SD
//	WORD	SD_Signature;		// sd-card signature, generated from CID.
	WORD	SD_CurFolderNum; 	// Current folder number.							
	WORD	SD_CurFileNum; 		// Current file number.
	DWORD	SD_CurPlayTime; 	// Current paly time.
	WORD	SD_FolderSum; 		// folder sum.							
	WORD	SD_FileSum; 		// file sum in sd-card.
	BYTE	SD_FileName[8];		// file name

	//FM
	WORD	FM_CurFreq; 

	BYTE	SystemMode;			// system function mode.

	BYTE	Volume;				// Volume:0--25
	BYTE	Eq;					// EQ
	BYTE	RepeatMode;			// Play mode
			  					
} BP_INFO;
#endif
typedef struct	_BP_INFO
{
	BYTE	Signature;			// Only when this field is equal to BP_SIGNATURE, this structure is valid.
	BYTE	SystemMode;			// system function mode.
	
	//USB
//	WORD	USB_Signature;		// usb signature, generated from usb id.
	WORD	USB_FolderSum; 		// folder sum.		
	WORD	USB_FileSum; 		// file sum in u-disk.
	
	WORD	USB_CurFolderNum; 	// Current folder number.							
	WORD	USB_CurFileNum; 	// Current file number.
	DWORD	USB_CurPlayTime; 	// Current paly time.
						
	
	//BYTE	USB_FileName[8];	// file name

	//SD
//	WORD	SD_Signature;		// sd-card signature, generated from CID.
	WORD	SD_FolderSum; 		// folder sum.							
	WORD	SD_FileSum; 		// file sum in sd-card.
	WORD	SD_CurFolderNum; 	// Current folder number.							
	WORD	SD_CurFileNum; 		// Current file number.
	DWORD	SD_CurPlayTime; 	// Current paly time.

	
	//BYTE	SD_FileName[8];		// file name

	BYTE	Volume;				// Volume:0--25
	BYTE	Eq;					// EQ
	BYTE	RepeatMode;			// Play mode
	
	//FM
	//WORD	FM_CurFreq; 

	

	
			  					
} BP_INFO;


extern BP_INFO		gBreakPointInfo;



VOID BP_LoadInfo();

// Save break point information to EEPROM
VOID BP_SaveInfo();	

//���沥���ļ�����Ϣ������Ŀ¼��ţ��ļ����
void BP_SaveFileNO();
//�����ļ�Ŀ¼��Ϣ
VOID BP_SaveFolderInfo();
//���浱ǰ����ʱ���
DWORD BP_SaveCurPlayTime();
//����������Ϣ
VOID BP_SaveVolumeInfo();
//���2402C���ݣ�ģ���������Ӻ��һ���������
void BP_SaveNULLBK();

WORD BP_GetCurFolderNum();

WORD BP_GetCurFileNum();

DWORD BP_GetCurPlayTime();

WORD BP_GetFolderSum();

WORD BP_GetFileSum();

//BYTE* BP_GetFileName();

BYTE BP_GetSystemMode();

//WORD BP_GetDevSignature();
void BP_SaveSystemMode();

#endif
