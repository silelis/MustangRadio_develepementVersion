#ifndef _ADC_H_
#define	_ADC_H_

// ADC reference votage selection
// used by funciton: AdcReadOneChannel()
#define		ADC_VREF_BG24			0
#define		ADC_VREF_AVDD33			1

// ADC channel selection
// used by funciton: AdcReadOneChannel()
#define		ADC_CHANNEL_AUDIO_L		1
#define		ADC_CHANNEL_AUDIO_R		2
#define		ADC_CHANNEL_A0			7
#define		ADC_CHANNEL_A1			8
#define		ADC_CHANNEL_A2			9
#define		ADC_CHANNEL_D1			10
#define		ADC_CHANNEL_E0			11
#define		ADC_CHANNEL_E1			12
#define		ADC_CHANNEL_E2			13
#define		ADC_CHANNEL_E3			14
#define		ADC_CHANNEL_E4			15

//E4 A0ͬʱ��ADC�ɼ��Ļ�,֮��Ҫ��һ����ʱ lxl 7-30

// read value from one channel.
WORD AdcReadOneChannel(BYTE Channel, BYTE Vref);

//return votage at LDO_5VIN pin, unit is mV.
//   3.40V--4.60V.
WORD GetVinVoltage();

#endif
