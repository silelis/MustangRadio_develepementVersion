#ifndef _DEVICE_HCD_H_
#define	_DEVICE_HCD_H_

// Max packet size. Fixed, user should not modify.
#define	DEVICE_FS_CONTROL_MPS		64		
#define	DEVICE_FS_BULK_IN_MPS		64		
#define	DEVICE_FS_BULK_OUT_MPS		64		

//#define	DEVICE_FS_ISO_IN_MPS		192		
#define	DEVICE_FS_ISO_OUT_MPS		192		


// Endpoint number. Fixed, user should not modify.
#define	DEVICE_CONTROL_EP			0x00
#define	DEVICE_BULK_IN_EP			0x81
#define	DEVICE_BULK_OUT_EP			0x02

#define	DEVICE_ISO_IN_EP			0x82
#define	DEVICE_ISO_OUT_EP			0x02


// Bus event define
#define	USB_VBUS_ERROR				(1 << 7)
#define	USB_SESSION_REQ				(1 << 6)
#define	USB_DISCONNECT				(1 << 5)
#define	USB_CONNECT					(1 << 4)
#define	USB_SOF						(1 << 3)
#define	USB_RESET					(1 << 2)
#define	USB_RESUME					(1 << 1)
#define	USB_SUSPEND					(1 << 0)


//���ϵͳ�Ƿ�������һ��USB����
BOOL UsbDeviceIsLink();

// Device initial
VOID UsbDeviceInit();

// Device software disconnect.
VOID UsbDeviceDisConnect();

// Send stall
VOID UsbDeviceSendStall(BYTE EndpointNum);

// Set receive endpoint to ISO mode.
VOID UsbDeviceSetRcvISO();

// Reset endpoint
VOID UsbDeviceResetEndpoint(BYTE EndpointNum); 

// Set device address
VOID UsbDeviceSetAddress(BYTE Address);	 

// Get bus event
BYTE UsbDeviceGetBusEvent();

// Send data to control endpoint
VOID UsbDeviceControlSend(BYTE* Addr, BYTE Len);

// Receive data from control endpoint
BYTE UsbDeviceControlRcv(BYTE* Buf, BYTE MaxLen);

// Receive setup packet from control endpoint
BYTE UsbDeviceSetupRcv(BYTE* Buf, BYTE MaxLen);	

// Send data to bulk in endpoint
VOID UsbDeviceBulkSend(BYTE* Addr, WORD Len);

// Receive data from bulk out endpoint
WORD UsbDeviceBulkRcv(BYTE* Buf, WORD Len);	 


#endif