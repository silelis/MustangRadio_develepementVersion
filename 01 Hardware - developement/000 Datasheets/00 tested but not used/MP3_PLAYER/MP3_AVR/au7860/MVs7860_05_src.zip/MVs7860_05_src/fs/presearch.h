#ifndef _PRESEARCH_H_
#define _PRESEARCH_H_



BOOL FSInit(BYTE DeviceID);

#endif
