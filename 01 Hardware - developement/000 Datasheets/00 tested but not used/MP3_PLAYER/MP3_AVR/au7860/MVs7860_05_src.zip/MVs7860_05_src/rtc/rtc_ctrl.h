#ifndef _RTC_CTRL_H_
#define _RTC_CTRL_H_

// Rtc initial.
VOID RtcCtrlInit();

// Rtc mode state control.
VOID RtcStateCtrl();


#endif
