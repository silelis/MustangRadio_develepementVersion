#ifndef _CLK_H_
#define _CLK_H_


// bit mask of sperate module, used by ModuleClkEn and ModuleClkDis functions.
#define		MASK_RECODER_CLOCK				(1 << 0)
#define		MASK_RFR_CLOCK					(1 << 1)
#define		MASK_RTC_CLOCK					(1 << 2)
#define		MASK_LCD_CLOCK					(1 << 3)
#define		MASK_SDSPI_CLOCK				(1 << 4)
#define		MASK_UART_CLOCK					(1 << 5)
#define		MASK_USB_CLOCK					(1 << 6)
#define		MASK_IR_CLOCK					(1 << 7)

#define		MASK_ADC_CLOCK					(1 << 8)
#define		MASK_MP3_CLOCK					(1 << 9)
#define		MASK_VMEM_CLOCK					(1 << 10)
#define		MASK_PWM_CLOCK					(1 << 11)
#define		MASK_I2C_CLOCK					(1 << 12)
#define		MASK_DAC_CLOCK					(7 << 13)

#define		MASK_ALL_CLOCK					0xFFFF


// Module clock enable.
VOID ModuleClkEn(WORD module);

// Module clock disable.
VOID ModuleClkDis(WORD module);	

// Set Clock divid rate��1��128.
VOID SetClkDivRate(BYTE rate); 

// Get system clock divide rate.
BYTE GetClkDivRate();

#endif
