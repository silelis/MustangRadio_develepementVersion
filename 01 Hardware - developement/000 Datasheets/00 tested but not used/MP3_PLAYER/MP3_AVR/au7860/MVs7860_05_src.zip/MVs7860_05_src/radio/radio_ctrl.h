#ifndef _RADIOCTRL_H_
#define _RADIOCTRL_H_


//------------------------------
#define		FREQ_MIN	875u
//#define		FREQ_MIN	971u
//#define		FREQ_MIN	1043u
#define		FREQ_MAX	1080u

#define		FREQ_DEF	875u

#define		MAX_SAVE_CH	50

//------------------------------
//#define		NEXT_PREV_SP_TUNE
#define		NEXT_PREV_SP_CH

// RADIO control structure.
typedef struct _RADIO_CTRL
{
	BYTE				Stauts;
	BYTE				SeekDir;
	WORD				SeekStarFreq;
	WORD				Freq;
	WORD				MemFreq[MAX_SAVE_CH];
	BYTE				CurCh;
	BYTE				MaxCh;
	BYTE				SeekSts;
} RADIO_CTRL;

enum {
	RADIO_STS_INIT=0,
	RADIO_STS_IDLE,
	RADIO_STS_SEEK,
	RADIO_STS_SEARCH,
	RADIO_STS_EXIT
};


enum
{
	SEARCH_INIT=0,
	SEARCH_START,
	SEARCH_CHK,	
	SEARCH_NEXT,
	SEARCH_DISP,
	SEARCH_DISP_00,
	SEARCH_DISP_01,
	SEARCH_DISP_02,
	SEARCH_DISP_03,
	SEARCH_OK
};


enum
{
	SEEKUP=0,
	SEEKDN,
};
//------------------------------

typedef enum _Radio_NAME
{
	RADIO_NONE=0,	
	RADIO_RDA5807P,	
	RADIO_SILI4702,	
	RADIO_CS2010,	
	RADIO_CL6017X,	
	RADIO_KT0830E,	
	RADIO_AR1000F,	
	RADIO_BK1080,	
	RADIO_QN8035,
	RADIO_RDA5807H,
	
	RADIO_MAX
} Radio_NAME;

//---------------------------------------
typedef		BOOL (*pDrv)(void);


enum
{
	RADIO_SAVE_CH_SUM_FLAG_REL=0,	
	RADIO_SAVE_CUR_FREQ_H_FLAG_REL,
	RADIO_SAVE_CUR_FREQ_L_FLAG_REL,
	RADIO_SAVE_MEM_FREQ_FLAG_REL
};

extern BYTE	radioSaveflag[(MAX_SAVE_CH*2+3+7)/8];

#define		RADIO_SET_FLAG(rel)	(radioSaveflag[(rel)/8]|=(1<<((rel)%8)))
#define		RADIO_CLR_FLAG(rel)	(radioSaveflag[(rel)/8]&=(~(1<<((rel)%8))))
#define		RADIO_GET_FLAG(rel)	(radioSaveflag[(rel)/8]&(1<<((rel)%8)))

//----------------------------------------

typedef enum _RADIO_SEEk_RESULT
{
	RADIO_SEEK_NONE = 0,
	RADIO_SEEK_FALSE,
	RADIO_SEEK_STC,
	RADIO_SEEK_VALIDSTATION,
	RADIO_SEEK_BANDLIMIT

}RADIO_SEEk_RESULT;




#if 0


#if defined(_FM_RDA5807P)
#include ".\RDA5807P\RDA5807P.h"
#warning	"-----------FM: Define RDA5807P!"
#define		FmRdID()				RDA5807P_ReadID()
#define		FmModeInit()			RDA5807P_Init()
#define		RadioMuteEn()			RDA5807P_Mute(TRUE)
#define		RadioMuteDis()			RDA5807P_Mute(FALSE)
#define		RadioPowerDownEn()		RDA5807P_PowerDownEn()
#define		RadioPowerDownDis()		RDA5807P_PowerDownDis()
#define		RadioFreqSet_drv()			RDA5807P_FreqSet(0)
#define		RadioSeekStart()		RDA5807P_FreqSet(1)
#define		RadioSeekResultGet()	RDA5807P_SeekResultGet()
//#define		RadioLinkOk()			((Radio_Name != RADIO_NONE) ? TRUE : FALSE)

#elif defined(_FM_QN8035)
#include ".\QN8035\QN8035.h"
#warning	"-----------FM: Define QN8035!"

#define		FmRdID()				QN8035_ReadID()
#define		FmModeInit()			QN8035_Init()
#define		RadioMuteEn()			QN8035_Mute(TRUE)
#define		RadioMuteDis()			QN8035_Mute(FALSE)
#define		RadioPowerDownEn()		QN8035_PowerDownEnable()
#define		RadioPowerDownDis()	
#define		RadioFreqSet_drv()			QN8035_FreqSet(gRadioCtrl.Freq)
#define		RadioSeekStart()			QN8035_SeekStart(gRadioCtrl.Freq)
#define		RadioSeekResultGet()	QN8035_SeekResultGet()

#endif


#else
#include ".\RDA5807P\RDA5807.h"
//#include ".\QN8035\QN8035.h"


#define		FmModeInit()			{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_Init(); break;\
											default: break;\										
										}\
									}


#define		RadioMuteEn()			{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_Mute(TRUE); break;\
											default: break;\										
										}\
									}
#define		RadioMuteDis()			{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_Mute(FALSE); break;\
											default: break;\										
										}\
									}

#define		RadioPowerDownEn()		{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_PowerDownEn(); break;\
											default: break;\										
										}\
									}


#define		RadioPowerDownDis()		{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_PowerDownDis(); break;\
											default: break;\										
										}\
									}

#define		RadioFreqSet_drv()			{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_FreqSet(gRadioCtrl.Freq); break;\
											default: break;\										
										}\
									}

#define		RadioSeekStart()		{\
										switch (Radio_Name)\
										{\
											case	RADIO_RDA5807P: RDA5807P_FreqSet(gRadioCtrl.Freq); break;\
											default: break;\										
										}\
									}
#if 0	//lxl 7-24
#define		RadioSeekResultGet()	((Radio_Name==RADIO_RDA5807P)?RDA5807P_SeekResultGet():\
									 ((Radio_Name==RADIO_QN8035)?QN8035_SeekResultGet():0))	
#else
#define		RadioSeekResultGet()	RDA5807P_SeekResultGet();
#endif


#endif


#define 	MACRADIO_XTAL_12M			0		//1: 12M   0:32.768K





extern Radio_NAME 	Radio_Name;
extern RADIO_CTRL	gRadioCtrl;

VOID RadioInit();
VOID RadioCtrlInit();
VOID RadioCtrlEnd();
VOID RadioStateCtrl();
VOID RadioAutoSearchStart(void);
void  ShowSearchedRadioFre(WORD Freq);
void  RadioFreqSet(void);
#endif
