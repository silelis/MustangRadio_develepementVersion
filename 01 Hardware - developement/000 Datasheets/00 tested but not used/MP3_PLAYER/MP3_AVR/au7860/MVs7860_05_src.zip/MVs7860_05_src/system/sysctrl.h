#ifndef _SYSCTRL_H_
#define _SYSCTRL_H_


// Define system volume range.
#define	VOLUME_MAX				32		
#define	VOLUME_INIT				25		
#define	VOLUME_MIN				0


// Define system control structure.
// Note: inlcude play control structure, file system control structure, device control structure.
typedef struct	_SYSTEM
{
	BOOL			IsClkDiv; 
 
	BYTE			SystemMode;
	BYTE			Volume;
	BOOL			MuteFg;
	BOOL			ModeChangeFlag;	

	BYTE			LowVoltageStatus ;
	BYTE			StatusDisCharging;		//�ŵ�״̬��0Ϊ���ŵ磬1Ϊ�ŵ磬ȱʡΪ0
} SYSTEM;


extern SYSTEM	gSys;


#endif
