#ifndef _CODING_KEY_H_
#define _CODING_KEY_H_


// Initialize coding key scan (GPIO) operation.
VOID CodingKeyScanInit();

// Key process.
BYTE CodingKeyEventGet();

// Coding key signal-A interrupt.
VOID CodingKeyInterrupt();

#endif 
