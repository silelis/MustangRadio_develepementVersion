#ifndef _DEVCTRL_H_
#define _DEVCTRL_H_


VOID DevCtrlInit();
VOID DevStateCtrl();

#endif
