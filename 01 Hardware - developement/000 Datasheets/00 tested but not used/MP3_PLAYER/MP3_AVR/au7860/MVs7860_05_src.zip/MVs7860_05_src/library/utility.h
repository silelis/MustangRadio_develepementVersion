#ifndef _UTILITY_H_
#define _UTILITY_H_


// MCU Wait Ms.
VOID WaitMs(WORD ms);	

// MCU Wait Us.
VOID WaitUs(WORD us);	

// Feed WatchDog, the "FOOD_FOR_DOG" please refer to "syscfg.h".
VOID FeedWatchDog();					

// Big endian to Little endian 16bit, Change 16bit data
// between big endian and little endian.
WORD LE16ToCPU(WORD val);

// Big endian to Little endian 32bit, Change 32bit data
// between big endian and little endian.
DWORD LE32ToCPU(DWORD val);


#endif
