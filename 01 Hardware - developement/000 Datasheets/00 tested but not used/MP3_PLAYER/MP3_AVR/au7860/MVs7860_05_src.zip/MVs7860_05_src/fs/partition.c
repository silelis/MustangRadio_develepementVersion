#include "syscfg.h"


#define SIGNATURE_OFFSET    	0x01fe            		// will contain 0x55AA
#define PARTITION_OFFSET    	0x01be            		// will contain partition table
#define COMMON_SIGNATURE    	0x55AA


//define partition structure
typedef struct _PARTITION         // Partition Entries definition    
{
    BYTE 	Active;
    BYTE 	StartHead;
    BYTE 	StartSector;
    BYTE 	StartCylinder;
    BYTE 	PartitionType;
    BYTE 	EndHead;
    BYTE 	EndSector;
    BYTE 	EndCylinder;
    DWORD 	FirstSectorNum;            
    DWORD 	SectorCount;

} PARTITION;


//define BPB structe
typedef struct
{
	BYTE 	BS_jmpBoot[3];		// 0-2
	BYTE	BS_OEMName[8];		// 3-10
	WORD	BPB_BytsPerSec;		// 11-12 
	BYTE	BPB_SecPerClus;		// 13
	WORD	BPB_RsvdSecCnt;		// 14-15
	BYTE	BPB_NumFATs;		// 16
	WORD	BPB_RootEntCnt;		// 17-18
	WORD	BPB_TotSec16;		// 19-20
	BYTE	BPB_Media;			// 21
	WORD	BPB_FATSz16;		// 22-23
	WORD	BPB_SecPerTrk;		// 24-25
	WORD	BPB_NumHeads;		// 26-27
	DWORD	BPB_HiddSec;		// 28-31
	DWORD	BPB_TotSec32;		// 32-35
	DWORD	BPB_FATSz32;		// 36-39
	WORD	BPB_ExtFlags;		// 40-41
	WORD	BPB_FSVer;			// 42-43
	DWORD	BPB_RootClus;		// 44-47
	WORD	BPB_FSInfo;			// 48-49
	WORD	BPB_BkBootSec;		// 50-51
	
} BOOT_SECTOR;

#ifdef FUNC_MULTI_PARTITION_EN
BYTE CurPartitionNum;	//��ǰ����ķ�����
#endif

// Load partition information from storage device.
BOOL PartitionLoad()
{
	DWORD		RootDirSectors;
	DWORD		BootSecNum = 0;
	DWORD		FatSize;
	DWORD		TotalSectors;
	BYTE		IndexPtb;
	BYTE		SectorSizeMul;
	DWORD		temp2;
	BYTE		ExtBootEntry=0;
	WORD		BPBRsvSectCnt;
#ifdef FUNC_MULTI_PARTITION_EN
	BYTE		TempCnt = 0;
#endif

#ifdef FUNC_USB_EN
	if(gFsInfo.DevID == DEV_ID_USB)
	{
	 	SectorSizeMul = (HostGetBlockSize()/SECTOR_SIZE);
	}
	else
#endif
	{
		SectorSizeMul = 1;
	}
//	DBG(("SectorSizeMul: %d\n", (WORD)SectorSizeMul));

LOAD_MBR:	
	//read MBR
	if(!ReadBlock(BootSecNum, (BYTE XDATA*)FAT_BUFFER, 1))
	{
		DBG(("ReadBlock() error!\n"));
		return FALSE;
	}
	gFsInfo.CurrFATSecNum = BootSecNum;

	if(*(WORD XDATA*)(FAT_BUFFER + SIGNATURE_OFFSET) != COMMON_SIGNATURE)		//if 0x55aa
    {  
		return FALSE;							
    }

	for(IndexPtb = 0; IndexPtb < 4; IndexPtb++)
	{
		PARTITION* pPart = &((PARTITION XDATA*)(FAT_BUFFER + PARTITION_OFFSET))[IndexPtb]; 		
		
		if((pPart->PartitionType == 0x05)			//Extended partition 
		&& ((ExtBootEntry == 0) || (IndexPtb >= ExtBootEntry)))
		{
			BootSecNum += LE32ToCPU(pPart->FirstSectorNum);
			ExtBootEntry = IndexPtb+1;
//			DBG(("Extended partition bootSecNum:%ld\n", (DWORD)BootSecNum));
			goto LOAD_MBR;
		}
		
		//check the partition type and get the boot sector num
		if (pPart->PartitionType == 0x04 
			|| pPart->PartitionType == 0x06 
			|| pPart->PartitionType == 0x0B 
			|| pPart->PartitionType == 0x0C
			|| pPart->PartitionType == 0x01
			|| pPart->PartitionType == 0x0E)
		{
#ifdef FUNC_MULTI_PARTITION_EN
			TempCnt++;
			if(TempCnt == CurPartitionNum)
			{
				BootSecNum += LE32ToCPU(pPart->FirstSectorNum);
				break;
			}
#else
			BootSecNum += LE32ToCPU(pPart->FirstSectorNum);
			break;
#endif
		}
	}

	if((IndexPtb == 4) && ((ExtBootEntry > 0) && (ExtBootEntry < 4)))
	{	
		//if extended parttion failed,try again.
		BootSecNum = 0;
		goto LOAD_MBR;	//���ӶԵ�һ����Ϊ��Ч��չ�����豸��֧��
	}

#ifdef FUNC_MULTI_PARTITION_EN
	if((CurPartitionNum > 1) && (TempCnt != CurPartitionNum))
	{
		return FALSE;
	}
#endif

	//read DBR
	if(!ReadBlock((BootSecNum * SectorSizeMul), (BYTE XDATA*)FAT_BUFFER, 1))
	{
		return FALSE;
	}
	gFsInfo.CurrFATSecNum = (BootSecNum * SectorSizeMul);
	
	if(*(WORD XDATA*)(FAT_BUFFER  + SIGNATURE_OFFSET) != COMMON_SIGNATURE)		//if 0x55aa
    {
		return FALSE;							
    }
	
	#define pzero_sector ((BOOT_SECTOR XDATA*)(FAT_BUFFER)) 

	//updata device information
	gFsInfo.ClusterSize = pzero_sector->BPB_SecPerClus;
	
	//get first sector of FAT
	BPBRsvSectCnt = LE16ToCPU(pzero_sector->BPB_RsvdSecCnt);
	gFsInfo.FatStart = BPBRsvSectCnt+BootSecNum; 
	
	//get sectors of boot dir
	if(pzero_sector->BPB_RootEntCnt != 0)
	{	
		RootDirSectors = (LE16ToCPU(pzero_sector->BPB_RootEntCnt)*32 + SECTOR_SIZE - 1)/SECTOR_SIZE;
	}
	else
	{
		RootDirSectors = 0;
	}

	//get FAT size
	if(pzero_sector->BPB_FATSz16 != 0)
	{
		FatSize = LE16ToCPU(pzero_sector->BPB_FATSz16);
	}
	else
	{
		FatSize = LE32ToCPU(pzero_sector->BPB_FATSz32);
	}

	//get total cluster
	if(pzero_sector->BPB_TotSec16 != 0)
	{
		TotalSectors = LE16ToCPU(pzero_sector->BPB_TotSec16);
	}
	else
	{
		TotalSectors = LE32ToCPU(pzero_sector->BPB_TotSec32);
	}

	temp2 = (TotalSectors - (BPBRsvSectCnt + FatSize * pzero_sector->BPB_NumFATs + RootDirSectors))/gFsInfo.ClusterSize;
//	DBG(("temp2:%ld\n", (DWORD)temp2));

	if(temp2 < 4085)
	{
		DBG(("FAT12\n"));
		gFsInfo.IsCpatFS = FALSE;				//FAT12
		return TRUE;
	}
	else if(temp2 < 65525)
	{
		DBG(("FAT16\n"));
		gFsInfo.FAT32 = 0;						//FAT16
		gFsInfo.IsCpatFS = TRUE;		
	}
	else
	{	
		//FAT32�豸BPB_RootEntCnt/BPB_TotSec16/BPB_FATSz16��ֵ����Ϊ��
		if(memcmp((BYTE XDATA *)(FAT_BUFFER + 0x36), "FAT16\0\0\0", 8) == 0)
		{
			//�ͻ���һ��U��(USB������)�����ݼ���ó��Ĵ���ĿӦ��ΪFAT32��ʵ��ΪFAT16ϵͳ��Ϊ֧����һ���豸����Ҫ���˴���
			DBG(("FAT16\n"));
			gFsInfo.FAT32 = 0;
		}
		else
		{
			DBG(("FAT32\n"));
			gFsInfo.FAT32 = 1;						//FAT32
		}
		gFsInfo.IsCpatFS = TRUE;	
	}
	
	gFsInfo.DataStart = gFsInfo.FatStart + (FatSize * pzero_sector->BPB_NumFATs) + RootDirSectors;		//the first sector of data
	// get max cluster number in this drive.
//	gFsInfo.MaxCluster = ((TotalSectors - gFsInfo.DataStart) / gFsInfo.ClusterSize) + 2;
	gFsInfo.MaxCluster = temp2 + 2;

	//get the data start and boot dir start
	if (gFsInfo.FAT32)				
	{
		gFsInfo.RootStart = gFsInfo.DataStart + (LE32ToCPU(pzero_sector->BPB_RootClus) - 2)*gFsInfo.ClusterSize;	
	}
	else										
	{
		gFsInfo.RootStart = gFsInfo.FatStart + FatSize * pzero_sector->BPB_NumFATs;						//FAT16 the first sector of root dir
	}

	gFsInfo.ClusterSize *= SectorSizeMul;
//	RootDirSectors *= SectorSizeMul;
	gFsInfo.FatStart *= SectorSizeMul;
	gFsInfo.DataStart *= SectorSizeMul;
	gFsInfo.MaxSector = (BootSecNum + TotalSectors)*SectorSizeMul;
	gFsInfo.RootStart *= SectorSizeMul;

	
//	DBG(("*************UDisk virtual params******************\n"));
//	DBG(("ClusterSize:%ld\n", (DWORD)gFsInfo.ClusterSize)); 
//	DBG(("RootDirSectors:%ld\n", (DWORD)RootDirSectors)); 
//	DBG(("FatStart:%ld\n", (DWORD)gFsInfo.FatStart)); 
//	DBG(("RootStart:%ld\n", (DWORD)gFsInfo.RootStart)); 
//	DBG(("DataStart:%ld\n", (DWORD)gFsInfo.DataStart));
//	DBG(("MaxCluster:%ld\n", (DWORD)gFsInfo.MaxCluster));
//	DBG(("*****************************************************\n\n"));

	return TRUE;
}



