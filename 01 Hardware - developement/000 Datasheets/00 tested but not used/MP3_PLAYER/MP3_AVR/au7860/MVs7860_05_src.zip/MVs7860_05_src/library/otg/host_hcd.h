#ifndef _HOST_HCD_H_
#define	_HOST_HCD_H_


// Endpoint number. Fixed, user should not modify.
//��ΪHOSTʱ�������Ķ˵�Ÿ������˵�ſ��Բ���ͬ
#define	HOST_CONTROL_EP				0
#define	HOST_BULK_IN_EP				1
#define	HOST_BULK_OUT_EP			1


//pipe type
#define PIPE_TYPE_CONTROL		0
#define PIPE_TYPE_ISO_IN		1
#define PIPE_TYPE_ISO_OUT		2
#define PIPE_TYPE_INT_IN		3
#define PIPE_TYPE_INT_OUT		4
#define PIPE_TYPE_BULK_IN		5
#define PIPE_TYPE_BULK_OUT		6

//control transfer direction
#define USB_DIR_OUT				0			
#define USB_DIR_IN				1

//define OTG endpoint descriptor, used for configuration endpoint information
typedef struct _PIPE_INFO
{
	BYTE	EndpointNum	;	//endpoint number
	BYTE	PipeType;		//endpoint type: ctrl, bulk, interrupt, isochronous
	BYTE	MaxPacketSize;	//max packet size

} PIPE_INFO;



BOOL HostUsbOpen();
BOOL HostIsLink();		//���USB�豸����״̬
VOID HostUsbPortReset();
VOID HostUsbSetAddress(BYTE Address); // Set device address

//�ӿ��ƶ˵����һ�δ���
BOOL HostUsbSetupPacket(BYTE* SetupPacket, BYTE Direction, BYTE* Buf, WORD Len);

//BOOL HostSendSetup(PIPE_INFO* Pipe, BYTE* Buf, BYTE Len);
BOOL HostRcvPacket(PIPE_INFO* Pipe, BYTE* Buf, WORD Len);
BOOL HostSendPacket(PIPE_INFO* Pipe, BYTE* Buf, WORD Len);

#endif