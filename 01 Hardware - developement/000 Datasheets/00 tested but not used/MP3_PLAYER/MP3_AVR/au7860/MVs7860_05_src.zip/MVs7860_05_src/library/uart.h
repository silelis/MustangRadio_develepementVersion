#ifndef _UART_H_
#define	_UART_H_


VOID FastUartOpen(WORD Baud);			//uart init function
//VOID UartSendByte(BYTE Val);		//uart send byte
//BOOL UartRecvByte(BYTE* pVal);		//uart receive byte

BOOL IsFastUartRcvOK();				//receive a byte,return TRUE,else return FALSE			
BOOL IsFastUartSendOK();			//send a byte,return TRUE,else return FALSE

VOID FastUartSendByte(BYTE Val);	//send a byte, and don't wait
BYTE FastUartRcvByte();				//if IsFastUartRcvOK() returns TRUE, FastUartRcvByte() receive the byte
VOID ClrFastUartTxFlag();			//clear fast uart tx interrupt flag

#endif
