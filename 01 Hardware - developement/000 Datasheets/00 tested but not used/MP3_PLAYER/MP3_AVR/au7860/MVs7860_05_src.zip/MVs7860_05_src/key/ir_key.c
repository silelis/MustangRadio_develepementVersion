#include "syscfg.h"


#ifdef FUNC_IR_KEY_EN

#define 	IR_KEY_SCAN_TIME			5
#define 	IR_KEY_JITTER_TIME			30
#define		IR_KEY_CP_TIME				1000	//CP condition is 1s
#define 	IR_KEY_CPH_TIME				350

#define		IR_KEY_SUM					21		//IR KEY SUM


typedef enum _IR_KEY_STATE
{
	IR_KEY_STATE_IDLE,
	IR_KEY_STATE_JITTER,
	IR_KEY_STATE_PRESS_DOWN,
	IR_KEY_STATE_CP

} IR_KEY_STATE;

static TIMER			IrKeyHoldTimer;
static TIMER			IrKeyWaitTimer;
static TIMER			IrKeyScanTimer;
static IR_KEY_STATE		IrKeyState;

static DWORD 			IrKeyVal;


//IrKeyVal[31:16]: key value
//IrKeyVal[15:0]: manu id
#define IR_MANU_ID		0xFF00		

// Customer IR key value table, fix it by case.
static CODE BYTE gIrVal[IR_KEY_SUM] = 
{
	0xBA,		// POWER
	0xB9,		// MODE
	0xB8,		// MUTE				
	
	0xBB,		// PLAY/PAUSE
	0xBF,		// PRE
	0xBC,		// NEXT
	
	0xF8,		// EQ
	0xEA,		// VOL-
	0xF6,		// VOL+
	
	0xE9,		// 0
	0xE6,		// REPEAT
	0xF2,		// USB/SD
	
	0xF3,		// 1
	0xE7,		// 2
	0xA1,		// 3
	
	0xF7,		// 4
	0xE3,		// 5
	0xA5,		// 6
	
	0xBD,		// 7
	0xAD,		// 8
	0xB5,		// 9
};

static CODE BYTE IrKeyEvent[][4] =  	 
{
//	SP					CPS					CPH					CPR	
	{MSG_POWER, 		MSG_POWER, 			MSG_NONE, 			MSG_NONE		},	// POWER
	{MSG_MODE_SW, 		MSG_NONE,			MSG_NONE, 			MSG_NONE		},	// MODE
	{MSG_MUTE, 			MSG_NONE, 			MSG_NONE, 			MSG_NONE		},	// MUTE

	{MSG_PLAY_PAUSE, 	MSG_STOP, 			MSG_NONE, 			MSG_NONE		},	// PLAY/PAUSE
	{MSG_PRE, 			MSG_FB_START, 		MSG_NONE, 			MSG_FF_FB_END	},	// PRE
	{MSG_NEXT, 			MSG_FF_START, 		MSG_NONE, 			MSG_FF_FB_END	},	// NEXT

	{MSG_EQ_SW, 		MSG_EQ_SW, 			MSG_EQ_SW, 			MSG_NONE		},	// EQ
	{MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_VOL_SUB, 		MSG_NONE		},	// VOL-
	{MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_VOL_ADD, 		MSG_NONE		},	// VOL+

	{MSG_NUM_0, 		MSG_NUM_0, 			MSG_NUM_0, 			MSG_NONE		},	// 0
	{MSG_REPEAT, 		MSG_REPEAT, 		MSG_REPEAT, 		MSG_NONE		},	// REPEAT
	{MSG_NONE, 			MSG_NONE, 			MSG_NONE, 			MSG_NONE		},	// USB/SD
	
	{MSG_NUM_1, 		MSG_NUM_1, 			MSG_NUM_1, 			MSG_NONE		},	// 1
	{MSG_NUM_2, 		MSG_NUM_2, 			MSG_NUM_2, 			MSG_NONE		},	// 2
	{MSG_NUM_3, 		MSG_NUM_3, 			MSG_NUM_3, 			MSG_NONE		},	// 3


	{MSG_NUM_4, 		MSG_NUM_4, 			MSG_NUM_4, 			MSG_NONE		},	// 4
	{MSG_NUM_5, 		MSG_NUM_5, 			MSG_NUM_5, 			MSG_NONE		},	// 5
	{MSG_NUM_6, 		MSG_NUM_6, 			MSG_NUM_6, 			MSG_NONE		},	// 6

	{MSG_NUM_7, 		MSG_NUM_7, 			MSG_NUM_7, 			MSG_NONE		},	// 7
	{MSG_NUM_8, 		MSG_NUM_8, 			MSG_NUM_8, 			MSG_NONE		},	// 8
	{MSG_NUM_9, 		MSG_NUM_9, 			MSG_NUM_9, 			MSG_NONE		},	// 9

};


//get ir key index
BYTE GetIrKeyIndex()
{
	static BYTE KeyIndex = -1;
	static BYTE IrCphCnt = 0;
    BOOL IsIrShortPrs, IsIrContinuePrs;
    
	//DBG(("[IR] Enter GetIrKeyIndex()\n"));
	if(IrIsKeyCome())
	{
	    IsIrShortPrs = TRUE;
		IsIrContinuePrs = FALSE;
		IrKeyVal = IrGetKeyCode();  
		//DBG(("Key: %08LX\n", IrKeyVal)); 
	}
    else if(IrIsContinuePrs())
    {
		IsIrShortPrs = FALSE;
		IsIrContinuePrs = TRUE;
    } 
	else
	{
	    IsIrShortPrs = FALSE;
		IsIrContinuePrs = FALSE;
	}
    if(IsIrShortPrs || IsIrContinuePrs)
    {
	    //fast response 
	    if(IsIrShortPrs)
	    {
		    IrCphCnt = 0;
	    }
	    if(IrCphCnt < 5)
	    {
		    IrCphCnt++;
	    }
	    TimeOutSet(&IrKeyHoldTimer, 70*IrCphCnt);
 		
		if(BYTE0(IrKeyVal) + BYTE1(IrKeyVal) != 0xFF)
		{
			KeyIndex = -1;
			return -1;
		}
		
		if(WORD1(IrKeyVal) == IR_MANU_ID)
		{
			for(KeyIndex = 0; KeyIndex < IR_KEY_SUM; KeyIndex++)
			{
				if(BYTE0(IrKeyVal) == gIrVal[KeyIndex])		
				{
					return KeyIndex;
				}
			}
		}
		KeyIndex = -1;
		return -1;
	}
	else if(!IsTimeOut(&IrKeyHoldTimer))
	{
		return KeyIndex;
	}
	else
	{
		IrKeyVal = 0;
		return -1;
	}
}


// IR decoder initilize.
VOID IrKeyScanInit()
{	
	IrKeyState = IR_KEY_STATE_IDLE;
	TimeOutSet(&IrKeyScanTimer, 0);

	SetGpioRegBit(GPIO_C_IE, (1 << 2));
	IrInit();
}


// Key process, image key value to key event.
BYTE IrKeyEventGet()							
{
	static 	BYTE 	PreKeyIndex = -1;
	BYTE			KeyIndex;
//	BYTE			event = MSG_NONE;

	if(!IsTimeOut(&IrKeyScanTimer))
	{
		return MSG_NONE;
	}
	TimeOutSet(&IrKeyScanTimer, IR_KEY_SCAN_TIME);	

	KeyIndex = GetIrKeyIndex();

	switch(IrKeyState)
	{
		case IR_KEY_STATE_IDLE:
			if(KeyIndex == -1)
			{
				return MSG_NONE;
			}

			PreKeyIndex = KeyIndex;
			TimeOutSet(&IrKeyWaitTimer, IR_KEY_CP_TIME);
			IrKeyState = IR_KEY_STATE_PRESS_DOWN;
			break;

		case IR_KEY_STATE_PRESS_DOWN:
			if(PreKeyIndex != KeyIndex)
			{
				//return key sp value
				//DBG(("IR KEY SP!%bu\n",PreKeyIndex));
				IrKeyState = IR_KEY_STATE_IDLE;
				return IrKeyEvent[PreKeyIndex][0];
			}
			else if(IsTimeOut(&IrKeyWaitTimer))
			{
				//return key cp value
				//DBG(("IR KEY CPS!\n"));
				TimeOutSet(&IrKeyWaitTimer, IR_KEY_CPH_TIME);
				IrKeyState = IR_KEY_STATE_CP;
				return IrKeyEvent[PreKeyIndex][1];
			}
			break;

		case IR_KEY_STATE_CP:
			if(PreKeyIndex != KeyIndex)
			{
				//return key cp value
				//DBG(("IR CPR\n"));
				IrKeyState = IR_KEY_STATE_IDLE;
				return IrKeyEvent[PreKeyIndex][3];
			}
			else if(IsTimeOut(&IrKeyWaitTimer))
			{
				TimeOutSet(&IrKeyWaitTimer, IR_KEY_CPH_TIME);
				return IrKeyEvent[PreKeyIndex][2];
			}
			break;

		default:
			IrKeyState = IR_KEY_STATE_IDLE;
			break;
	}
	return MSG_NONE;
}


#endif
