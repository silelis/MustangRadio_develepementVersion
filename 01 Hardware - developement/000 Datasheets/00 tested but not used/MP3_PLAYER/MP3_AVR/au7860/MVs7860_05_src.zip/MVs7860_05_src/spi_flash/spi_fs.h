#ifndef _SPI_FS_H_
#define	_SPI_FS_H_

//SPI flash file system initial.
BOOL SpiFsInit();

BOOL SpiFsFileOpen(FILE* File, WORD FileNum, BYTE FileType);
WORD SpiFsFileRead(FILE* File, WORD Buffer, WORD Len);
BOOL SpiFsFileSeek(FILE* File, SDWORD Offset, BYTE Base);

//���ļ��У�ֻ����1���ļ���
BOOL SpiFsFolderOpen(FOLDER* Folder, WORD FolderNum);

#endif

