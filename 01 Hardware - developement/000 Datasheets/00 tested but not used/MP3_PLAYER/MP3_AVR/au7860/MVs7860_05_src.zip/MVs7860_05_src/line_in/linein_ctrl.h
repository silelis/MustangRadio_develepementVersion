#ifndef _LINEIN_CTRL_H_
#define _LINEIN_CTRL_H_


BOOL LineInCtrlInit();

// line-in mode state control.
VOID LineInStateCtrl();


#endif
