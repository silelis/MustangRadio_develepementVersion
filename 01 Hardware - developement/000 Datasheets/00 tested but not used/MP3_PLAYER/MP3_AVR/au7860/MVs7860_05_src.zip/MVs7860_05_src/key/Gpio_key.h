#ifndef _GPIO_KEY_H_
#define _GPIO_KEY_H_


// Initialize GPIO key scan (GPIO) operation.
VOID GPIOKeyScanInit();

// Key process, image key value to key event.
BYTE GPIOKeyEventGet();

#endif 

