#ifndef _IPOD_AUTH_H_
#define _IPOD_AUTH_H_

//extern BOOL IsSupportIDPS;

BOOL IPOD_Auth();

#endif

