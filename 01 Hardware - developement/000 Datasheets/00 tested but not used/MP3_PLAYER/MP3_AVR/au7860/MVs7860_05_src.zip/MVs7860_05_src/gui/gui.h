/*
********************************************************************************
*                   Copyright (c) 2010,ZhangXiaoYong
*                         All rights reserved.
*
* File Name��   gui.h
* 
* Description:  ��ʾ�ӿ�
*
* History:      <author>          <time>        <version>       
*             ZhangXiaoYong      2010-07-06          1.0
*    desc:    ORG.
********************************************************************************
*/

#ifndef _GUI_H_
#define _GUI_H_

//#define 	IndexAddressStart	0x000080
//#define 	GlyphAddressStart	0x01a720
//#define 	GbkAddressStart		0x0c15b0
//#define 	Big5AddressStart		0x0c7f70

//#define 	TotalUnicodeCount	0x466f
//#define 	TotalGbkCount		0x1a6b

typedef enum icon_id
{
    BID_BANK,
    BID_PLAY_ICON,
    BID_PAUSE_ICON,
    BID_SPEAKER_ICON,
    //BID_CLOCK_ICON,    
    BID_STOP_ICON,
}icon_id_t;

typedef struct FONT_GLYPH
{
	BYTE x;
	BYTE y;
	BYTE DotBuffer[32];
}FONTGLYPH;

typedef struct{
	unsigned char x;
	unsigned char y;
}POSITION;

typedef struct FONT_LIB_ADDRESS
{
DWORD UnicodeIndexAddress;
DWORD UnicodeGlyphAddress;
DWORD GbkToUnicodeIndexAddress;
DWORD Big5ToUnicodeInedexAddress;
}FONTLIBADDRESS;
extern FONTGLYPH font;
VOID GetUnicodeChar(WORD k);
VOID GetUnicodeAsciiChar(WORD c);
VOID GetGB2312Char(WORD k);
extern VOID GetAsciiChar(BYTE c);
void ShowIcon1616(char icon_id,POSITION point);
BOOL InitGui(VOID);

VOID BatteryInit(VOID);
VOID GUI_ShowBattery(VOID);
void ShowRadioFre(WORD Fre);
void ShowPaceRadioFre(WORD Fre);
void ShowRadioSelectFre(WORD Fre);
void ShowRadioFre10Pixels(WORD Fre);
void ShowWholeRadioFre(WORD Fre);
void ClearFreqWin();
void ShowLrc( BYTE* String , BYTE CharSet );
void ShowLowVoltageHint( BYTE* String );
//��ʾ�����ٷְ�
void ShowChargeVolRatio(WORD Fre);
//void ShowHint( BYTE* String);
void ShowFileName( BYTE* String);
void ShowPlayTotaltime(DWORD TotalPlayTime );
void BatteryInit(VOID);
void ShowIcon1616FromAdd(char *pIcon , POSITION point);
void ShowReaderIcon1616(void);
void ShowVolume(void);
//ֻ��ʾһ��������������ˢ��������
//AddFlag Ϊ1����ʾ�����ӣ�����������
void ShowVolumeCP( BYTE AddFlag );
void ShowUnicodeString(char *string,POSITION point);
void ShowGB2312Lrc( BYTE* String  );
void ShowUnicodeStringLrc( BYTE* String  );
void ShowPauseIcon( BYTE ShowFlag );
void ShowStopIcon( BYTE ShowFlag );
void ShowWord(WORD Fre , BYTE line ) ;
void ShowString( BYTE* String , BYTE CharSet  , BYTE Row , BYTE Col );
void ShowUnicodeStringLrc_s( BYTE* String  , POSITION point);
void ShowGB2312Lrc_s( BYTE* String  , POSITION point);
void ShowORTIcon();
#endif
