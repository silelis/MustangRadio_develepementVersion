#ifndef _TIMER_H_
#define _TIMER_H_


// define softtimer structure.
typedef struct	_TIMER
{
	DWORD	TimeOutVal; 								//time out value
	DWORD	RecTickVal;			  						//softtimer setting value
	BOOL	IsTimeOut;									//time out flag
} TIMER;


extern DWORD gSysTick; 					//system tick counter


// System tick (1ms) initilization.
VOID SysTickInit();
		
VOID TimerTick();

// Get now time from system start.
DWORD TimeNow();

// Get time of some softtimer from setting to now.
DWORD PastTimeGet(TIMER* timer);

// Set time out value of softtimer.
VOID TimeOutSet(TIMER* timer, DWORD timeout);

// Check whether time out.
BOOL IsTimeOut(TIMER* timer);

// set timer count
VOID TimerCountSet(BYTE div);

#endif
