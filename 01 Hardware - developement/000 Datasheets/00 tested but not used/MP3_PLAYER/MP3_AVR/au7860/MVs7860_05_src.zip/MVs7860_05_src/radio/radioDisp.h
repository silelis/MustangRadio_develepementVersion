/*****************************************************
*							PACE Corp.
*				Copyright 2012, PACE Corp., ShengZhen, China
*							All rights reserved.
*
* Filename:			
* Description:		
* Change History:
*					
*					- created

*******************************************************/

#ifndef		_RADIO_DISP_H
#define		_RADIO_DISP_H
//---------------------------------

typedef		enum
{
	RADIO_DISP_STS_INIT=0,
	RADIO_DISP_STS_IDLE,
	RADIO_DISP_STS_FREQ,
	RADIO_DISP_STS_CH,
	RADIO_DISP_STS_CH_DISP,
	RADIO_DISP_STS_EXIT
}RADIO_DISP_STS_TYPEDEF;





#ifndef	_RADIO_DISP_C


extern	void		radioDispSetSts(RADIO_DISP_STS_TYPEDEF sts);
extern	void		radioDispPrc(void);
extern	void		radioDispFreq(void);
//extern	u8		radioDispCh(u8 ch);
extern	BYTE		radioDispCh(BYTE ch);


#endif


//---------------------------------
#endif

////////////////////////////  END FILE  ////////////////////////

