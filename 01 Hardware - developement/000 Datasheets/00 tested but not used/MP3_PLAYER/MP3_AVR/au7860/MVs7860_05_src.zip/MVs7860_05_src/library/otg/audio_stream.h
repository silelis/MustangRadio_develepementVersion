#ifndef _AUDIO_STREAM_H_
#define _AUDIO_STREAM_H_

VOID AudioStreamInit();
VOID AudioStreamProcess();


#endif
