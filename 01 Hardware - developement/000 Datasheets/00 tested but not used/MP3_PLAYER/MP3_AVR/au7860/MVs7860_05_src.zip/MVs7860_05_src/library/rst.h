#ifndef _RST_H_
#define	_RST_H_


// Set WatchDog.
// Note: set Watchdog counter byte[25:19], 
// watchdog counter has 26 bits, count down (frequency is 12MHz)
// system will be reset, max watchdog time is about 5s.
VOID SetWatchDog(BYTE Food);

// Enable WatchDog.
VOID WatchDogEn();
	
// Disable WatchDog.
VOID WatchDogDis();


//seperate reset.
VOID RstSdSpi();
VOID RstDecoder();
VOID RstDac();
VOID RstUsb();
VOID RstAdc();
VOID RstFastUart();
VOID RstRecorder();
VOID RstLcd();
VOID RstRtc();
VOID RstIr();

#endif
