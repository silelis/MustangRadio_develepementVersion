#include "syscfg.h"
#include "sysctrl.h"
#include "playctrl.h"
#include "spi_play.h"


#ifdef FUNC_SPI_PLAY_EN


typedef struct _ST_SPIFILEINFO
{
	DWORD dwStartAddr;
	DWORD dwFileSize;
	DWORD dwOffset;
	BYTE  ucFileType;

} ST_SPIFILEINFO;

ST_SPIFILEINFO gstSpiFileInfo;

BYTE gSpiPlayState = 0;

extern VOID PlayVol2Decd();



VOID SPIReadNBytes(DWORD Addr, BYTE* Buffer, WORD Lengh)
{
	ClrGpioRegBit(SPI_FLASH_CS_PORT_OUT, SPI_FLASH_CS_BIT);		//CS = 0
	SpiSendByte(0x03);
	SpiSendByte(BYTE1(Addr));
	SpiSendByte(BYTE2(Addr));
	SpiSendByte(BYTE3(Addr));
	SpiRecvBytes(Buffer, Lengh);
	SetGpioRegBit(SPI_FLASH_CS_PORT_OUT, SPI_FLASH_CS_BIT);		//CS = 1;
}


BOOL SPIFileEOF()
{
	if(gstSpiFileInfo.dwOffset >= gstSpiFileInfo.dwFileSize)
	{
		return TRUE;
	}
	return FALSE;
}


//fet file info
BOOL SPIFileGetInfo()
{
	gstSpiFileInfo.dwStartAddr = 48;
	gstSpiFileInfo.dwFileSize = 1114697;
	gstSpiFileInfo.dwOffset = 0;
	gstSpiFileInfo.ucFileType = SONG_TYPE_MP3;

	// Setting song information	
	gSongInfo.ChannelNum = 2;
	gSongInfo.IsVBR = FALSE;
	gSongInfo.Mp3MpegVersion = 3;//MPEG_1;
	gSongInfo.Mp3Layer = 1;//LAYER_3;
	gSongInfo.BytesPerSecond = 192000;
	gSongInfo.SamplesPerSecond = 48000;
	gSongInfo.SongType = SONG_TYPE_MP3;

	return TRUE;
}


// Read File data from the specified file.
WORD SpiFlashFileRd(WORD Buf, WORD Len)
{
	//DBG_SPI(("SpiFlashFileRd, rdBuff:%x, length:%x\n", (WORD)rdBuff, length));
	if((DWORD)Len > (gstSpiFileInfo.dwFileSize - gstSpiFileInfo.dwOffset))
	{
	 	Len = gstSpiFileInfo.dwFileSize - gstSpiFileInfo.dwOffset;
	}

	SPIReadNBytes((gstSpiFileInfo.dwStartAddr+gstSpiFileInfo.dwOffset), (BYTE XDATA*)Buf, Len);

	gstSpiFileInfo.dwOffset += Len;

	return Len;
}


//ָ������ʱ�䣬��ʼ��decoder����decoder���ݣ�����decoder����
//��������˻ָ�����
//���벥��״̬
BOOL SPI_SongPlayStart()
{
	//DBG(("->SPI_SongPlayStart()\n"));

	if(!SPIFileGetInfo())
	{
		DBG(("SPIFileGetInfo Error!\n"));
		return FALSE;
	}

	gSpiPlayState = SPIPLAY_STATE_START;

	SetDecoderMode(gSongInfo.SongType);	
//	PlayEQ2Decd();

	if(!SpiFlashFileRd(gSongInfo.PlayBuffer, 1024))
	{
		DBG(("SpiFlashFileRd() Failed!\n"));
		return FALSE;
	}
	
	gSys.Volume = 20;
	gPlayCtrl.RepeatMode = PLAY_MODE_REPEAT_ALL;	
	gPlayCtrl.Eq = 0;
	gPlayCtrl.Direction = PLAY_DIRECT_NEXT;

	InDacChannelSel(DAC_CH_DAC);	
	DecoderStartPlay();	
	InDacSetSampleRate(gSongInfo.SamplesPerSecond);
	PlayVol2Decd();

	gPlayCtrl.State = PLAY_STATE_PLAY;
	DBG(("<-SPI_SongPlayStart()\n"));
	gSpiPlayState = SPIPLAY_STATE_PLAY;
	return TRUE;
}


BOOL SPI_SongPlayDo()					
{
	//DBG(("->SPI_SongPlayDo()\n"));
	if(!IsDecoderDone())
	{
		return TRUE;
	}

	if(SPIFileEOF())
	{
		gSpiPlayState = SPIPLAY_STATE_STOP;
		DBG(("SPIFileEOF!\n"));
	}
	else
	{
		if(!SpiFlashFileRd(gSongInfo.PlayBuffer, 1024))
		{
			DBG(("SpiFlashFileRd() Failed,1!\n"));
			return FALSE;
		}
	
		SetDecoderData(gSongInfo.PlayBuffer, 1024);	
	}

	//DBG(("<-SPI_SongPlayDo()\n"));
	return TRUE;
}


BOOL SPI_PlayCtrl()
{	
	WatchDogDis();

	switch (gSpiPlayState)
	{
		case SPIPLAY_STATE_START:
			return SPI_SongPlayStart();

		case SPIPLAY_STATE_PLAY:
			return SPI_SongPlayDo();

		case SPIPLAY_STATE_STOP:
			DBG(("SongPlayStop()\n"));
			gSongInfo.CurPlayTime = 0;
			//�ر�DAC
			InDacMuteEn();
			gSpiPlayState = SPIPLAY_STATE_IDLE;
			return FALSE;

		default:
			return FALSE;
	}
}

#endif	