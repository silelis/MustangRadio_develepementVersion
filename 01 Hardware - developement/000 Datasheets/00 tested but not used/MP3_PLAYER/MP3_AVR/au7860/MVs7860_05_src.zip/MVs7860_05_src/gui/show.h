/*
********************************************************************************
*                   Copyright (c) 2010,ZhangXiaoYong
*                         All rights reserved.
*
* File Name��   show.h
* 
* Description:  ��ʾ�ӿ�
*
* History:      <author>          <time>        <version>       
*             ZhangXiaoYong      2010-03-12          1.0
*    desc:    ORG.
********************************************************************************
*/

#ifndef _show_H_
#define _show_H_



#define   BID_USB_ICON

typedef struct{
	unsigned char x;
	unsigned char y;
}POSITION;
typedef enum ShowMode
{
	DisplayInitMode = 0,
	DisplayMp3,
	DisplayAux,
	DisplayRadio,
	DisplayStandby
}Lcd_Dsip_Mode;

typedef struct{
	WORD ucode;
	BYTE x;
	BYTE y;
	BYTE dot[32];
}FILENAMEDOT;


#if 1		//ICON ˳��������ݶ�Ӧ
typedef enum icon_id
{
    BID_BANK,
    BID_PLAY_ICON,
    BID_PAUSE_ICON,
    BID_SPEAKER_ICON,
    BID_CLOCK_ICON,    
}icon_id_t;

typedef enum icon_battery_id
{
    BID_BAT0_ICON,
    BID_BAT1_ICON,
    BID_BAT2_ICON,
    BID_BAT3_ICON,
    BID_BAT4_ICON,
    BID_BAT5_ICON,
    
    BID_FOLDER_ICON,
    BID_VOL_ICON,
    BID_MUTE_ICON,

    BID_REPONE_ICON,       
    BID_REPFOLD_ICON,
    BID_REPALL_ICON, 
    BID_REPRAN_ICON,
    BID_INTRO_ICON,
    
}icon_battery_id;

typedef enum icon_12832
{
    BID_12832_AUDIO,
    BID_12832_LINEINT,
    BID_12832_USBREAD,
    BID_12832_EDIFIER,
      
}icon_12832_t;

typedef enum icon_3232
{
    MENU_SYSTEM_ICON = 0,
    MENU_SELECT_ICON,
    MENU_SET_ICON,
    MENU_AREA_ICON, 
     MENU_REP_ICON,
    MENU_EQ_ICON,
	
    MENU_BLACKLIGHT_ICON,
    MENU_LANG_ICON,
    MENU_READER_ICON,
    MENU_VERSIONS_ICON,

    MENU_RESET_ICON,  

    MENU_DIR_ICON,
    MENU_RETURN_ICON,
    
}icon_3232_t;

typedef enum FM_MHZ_ID
{
    BID_FM_76MHZ,
    BID_FM_87MHZ,
    BID_FM_91MHZ,
    BID_FM_108MHZ,    
}FM_MHZ_ID_T;


#endif



extern WORD		DisplayRefreshFlag;
#define	Refresh_BATTERY	0x8000
#define	Refresh_TIME		0x4000

#define	MP3_ALL			0xffff

#define	MP3_ICON			0x0001
#define	MP3_FILENAME		0x0002
#define	MP3_TOTALTIME		0x0004
#define	MP3_CURTIME		0x0008
#define	MP3_EQ				0x0010
#define	MP3_VOL			0x0020
#define	MP3_REP			0x0040
#define	MP3_PLAYSTATE		0x0080
#define	MP3_SPK			0x0100


#define	AUX_ALL			0xffff

#define	AUX_ICON			0x0001
#define	AUX_VOL			0x0002
#define	AUX_SPK			0x0004


#define	Radio_ALL			0xffff

#define	Radio_ICON			0x0001
#define	Radio_VOL			0x0002
#define	Radio_STA			0x0004
#define	Radio_FRE			0x0008
#define	Radio_SPK			0x0010

#define	RTC_ALL				0xffff

#define	RTC_ICON			0x0001
#define	RTC_YEAR			0x0002
#define	RTC_MONTH			0x0004
#define	RTC_DAY			0x0008
#define	RTC_HOUR			0x0010
#define	RTC_MIN			0x0020
#define	RTC_SEC			0x0040
#define	RTC_WDAY			0x0080

#if 1
	//B[6] for POWER_LED
	#define		POWER_LED_PORT_OUT		GPIO_C_OUT
	#define		POWER_LED_PORT_OE		GPIO_C_OE
	#define		POWER_LED_PORT_PU		GPIO_C_PU
	#define		POWER_LED_PORT_PD		GPIO_C_PD
	#define 		POWER_LED_BIT				(1 << 2)				
#endif



extern	void ShowRadio(void);
extern	void ShowAux(void);

extern VOID ShowLryicString(BYTE * LrcBuffer,char Length);
extern void ShowMp3(void);
extern void ShowClock(void);
extern void ShowOpenLogo(void);

extern	void ScrollScreenInit(void);
extern	VOID ShowShortNameFile(void);

void ClearScreen(void);
	
void ShowString(char *string,POSITION point);
void ShowDev(void);
void ShowBatteryIcon();
void ShowVol(void);
void ShowPlayState(void);
void LcdMp3FileNumber(void);
void ShowPlayCurrtime(void);
void ShowPlayTotaltime(void);
void ShowLoading(void);
void ShowMp3Loading(BOOL DevFlag);
void Mp3ScrollScreen(void);


void ShowRadioFre(WORD Fre);
void ShowRadioStation(BYTE CurStation,BYTE StationSum);
VOID ShowLryicScroInit(BYTE * LrcBuffer,char Length);
void ShowFolderName(void);
void ShowLongFileName(void);
void ShowRepeatmode(void);
void ClearRadioFre(void);
void ShowMute(void);
void ClearVOLline(void);
void ShowUsbRead(void);
void ShowAudio(void);
void ShowAudioLeve(char *Buff,POSITION pointy);
void ShowVolBar(void);

void ShowNoDev(void);

void ShowStationClear(void);

void ClearAudioLeve(void);

void ShowMenu(icon_3232_t MenuLeve,BYTE Line,BYTE StartLine);
void ShowFolderNameBrowser(BYTE *ShortName,BYTE Line,BOOL Mode);

void ShowNoReadSd(BYTE Type);
void ShowMp3NoFile(void);
#endif   //_show_H_
