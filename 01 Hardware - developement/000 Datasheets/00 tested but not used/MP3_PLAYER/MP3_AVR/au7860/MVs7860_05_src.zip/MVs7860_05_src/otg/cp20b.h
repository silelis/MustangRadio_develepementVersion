#ifndef _CP20B_H_
#define _CP20B_H_


VOID CP20B_Init();	
VOID CP20B_ReadBytes(BYTE Addr, BYTE* Buf, BYTE Len);
VOID CP20B_WriteBytes(BYTE Addr, BYTE* Buf, BYTE Len);

#endif
