#include "syscfg.h"
#include "device_hcd.h"
#include "device_stor.h"
#include "gui.h"

#ifdef FUNC_READER_EN

//PID and VID
WORD ReaderVID = 0x0000;
WORD ReaderPID = 0x0000;

BYTE* ReaderString_Manu = "MVSILICON.INC.";			//max length: 32bytes
BYTE* ReaderString_Product = "MV CARD READER";		//max length: 32bytes
BYTE* ReaderString_SerialNumber = "2011090112345";	//max length: 32bytes


//mass-storage device initial
VOID DeviceStorCtrlInit()
{	
	//��ʾ������ͼ��
	ClearFreqWin();
	ShowReaderIcon1616();

	
	DeviceStorInit();

#ifdef FUNC_FAST_READER_EN
	DeviceStorFastMode();
#endif
}


//mass-storage device initial
VOID DeviceStorCtrlEnd()
{	
	UsbDeviceDisConnect();
}


//mass-storage device process
VOID DeviceStorStateCtrl()
{	
	MESSAGE event ;

	DeviceStorProcess();
	event = MessageGet(MSG_FIFO_KEY);

	switch(event)
	{
		case MSG_RETURN_VOLTAGE:
		{			
			//��ʱӦ��ʾ��ͣ״̬ͼ��
			//���ԭ����ʾ����
			ClearFreqWin();
			//��ʾԭ��ͼ��
			ShowReaderIcon1616();
			break ;
		}
		default :
		{
			break;
		}
	}
}

#endif