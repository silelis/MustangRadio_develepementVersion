#include "syscfg.h"
#include "i2c.h"
#include "radio_ctrl.h"
#include "utility.h"
#include "debug.h"
#include "QN8035.h"



#ifdef FUNC_RADIO_EN

#define QN8025_CHIP_ADDR 	0x20

#define R_TXRX_MASK    0x30
#define R_FMAM_MASK    0xc0


//#define UINT8 BYTE
//BYTE	RSSIn = 255;
BYTE	prevMode;

#if 1
//WORD  qnd_RSSInBB[QND_BAND_NUM+1];          
//BYTE  qnd_StepTbl[3]={5,10,20};
//BYTE  qnd_RSSIn[QND_BAND_NUM];
//BYTE  qnd_RSSIns = 255;
//WORD qnd_ClearChannel = 0;

BYTE	qnd_R16;
BYTE	qnd_R17;
BYTE	qnd_R46;

#endif

/*
*****************************************************
*   �������ƣ�QN8025WriteReg
*   ��    	�ܣ�
*   ���������
*   ���������
*   ˵   		����������ģ��д��N  ���ֽ�
******************************************************
*/
BOOL QN8025WriteReg(
					BYTE addr,//unsigned char addr, 					//address
					BYTE dat)			 
{
//	BYTE* Temp;
//	Temp = (&dat);
//	return I2C_WriteNByte(QN8025_CHIP_ADDR,addr,Temp,1);
	return I2C_WriteNByte(QN8025_CHIP_ADDR,(WORD)addr,(BYTE*)&dat,1);
}

/*
************************************************
*   �������ƣ�QN8025ReadReg
*   ��    	�ܣ�
*   ���������
*   ���������
*   ˵    	����������ģ���ȡ1  ���ֽ�
*************************************************
*/
//state=0->success  state=1->fail
// /*
BYTE
	QND_ReadReg(
		BYTE regaddr
		)
{
	BYTE	TempData;

	//DBG((" FM ReadAdr = %BU\n", regaddr));
	
	I2C_ReadNByte(QN8025_CHIP_ADDR, (WORD)regaddr,(BYTE*)&TempData,(BYTE)1);

	//DBG((" FM ReadVal = %BU\n", TempData));

	return TempData;
}


/*
************************************************
*   �������ƣ�QN8025SetRegBit
*   ��    	�ܣ�
*   ���������
*   ���������
*   ˵    	����������ģ���ȡN  ���ֽ�
*************************************************
*/
//state=0->success  state=1->fail

VOID	QNF_SetRegBit(
		BYTE regaddr,
		BYTE bitMask,
		BYTE dataval
		)
{
	BYTE  temp;
	temp = QND_ReadReg(regaddr);
	temp &= (~bitMask);
	temp |= dataval & bitMask;
	//temp |= dataval;
	QN8025WriteReg( regaddr, temp);//QN8025WriteReg(regaddr, temp);
}



/**********************************************************************
WORD QNF_GetCh()
**********************************************************************
Description: get channel frequency of CCS

Parameters:
None
Return Value:
channel frequency
**********************************************************************/
//WORD QNF_GetCh()
//{
//	BYTE tCh;
//	BYTE  tStep; 
//	unsigned short ch;
//	// set to reg: CH_STEP
//	tStep = QND_ReadReg(CH_STEP);//I2C_ReadByte(QN8025_CHIP_ADDR, CH_STEP);//QND_ReadReg(CH_STEP);
//	tStep &= CH_CH;
//	ch = tStep;
//	tCh = QND_ReadReg(CH);//I2C_ReadByte(QN8025_CHIP_ADDR, CH);//QND_ReadReg(CH);  
//	ch = (ch << 8) + tCh;
//	return CHREG2FREQ(ch);
//}



/**********************************************************************
BYTE QNF_SetCh(WORD freq)
**********************************************************************
Description: set specified frequency 

Parameters:
		freq:  specified frequency that is set
Return Value:
         1: set success
**********************************************************************/
BYTE QNF_SetCh(WORD freq) 
{

    // calculate ch parameter used for register setting
    BYTE tStep;
    BYTE tCh;
    WORD f; 
    WORD pll_dlt;
#if 0    
    if(freq == 854 || freq == 855 || freq == 856)
    {
        pll_dlt = (WORD)qnd_R16 >> 3;       
        pll_dlt |=(WORD)qnd_R17 << 5;    
        pll_dlt -= 1039;  
        QN8025WriteReg(0x16, (BYTE)pll_dlt << 3);
        QN8025WriteReg(0x17, (BYTE)(pll_dlt >> 5));         
        if(freq == 854) QN8025WriteReg(0x46, 0x9D);
        else if(freq == 855) QN8025WriteReg(0x46, 0x69);
        else QN8025WriteReg(0x46, 0x34);
        freq = 8570;
    }
    else
    {
        QN8025WriteReg(0x16, qnd_R16);
        QN8025WriteReg(0x17, qnd_R17);
        QN8025WriteReg(0x46, qnd_R46);
    }   
    
    f = FREQ2CHREG(freq); 
    // set to reg: CH
    tCh = (BYTE) f;
    QN8025WriteReg(CH, tCh);
    // set to reg: CH_STEP
    tStep = QND_ReadReg(CH_STEP);
    tStep &= ~CH_CH;
    tStep |= ((BYTE) (f >> 8) & CH_CH);
    QN8025WriteReg(CH_STEP, tStep);
    return 1;
#else
	BYTE temp;

	 f = FREQ2CHREG(freq); 
	//writing lower 8 bits of CCA channel start index
	QN8025WriteReg(CH_START, (BYTE)f);
	//writing lower 8 bits of CCA channel stop index
	QN8025WriteReg(CH_STOP, (BYTE)f);
	//writing lower 8 bits of channel index
	QN8025WriteReg(CH, (BYTE)f);
	//writing higher bits of CCA channel start,stop and step index
	temp = (BYTE) ((f >> 8) & CH_CH);
	temp |= ((BYTE)(f >> 6) & CH_CH_START);
	temp |= ((BYTE) (f >> 4) & CH_CH_STOP);
	temp |= QND_STEP_CONSTANT;//(step << 6);
	QN8025WriteReg(CH_STEP, temp);
    return 1;	
#endif
}

/**********************************************************************
void QNF_RXInit()
**********************************************************************
Description: set to SNR based MPX control. Call this function before 
             tune to one specific channel

Parameters:
None
Return Value:
None
**********************************************************************/
void QNF_RXInit()
{
#if 0
    QNF_SetRegBit(0x1B,0x08,0x00);  //Let NFILT adjust freely
    QNF_SetRegBit(0x2C,0x3F,0x12);
    QNF_SetRegBit(0x1D,0x40,0x00);
    QNF_SetRegBit(0x41,0x0F,0x0A);
    QN8025WriteReg(0x45,0x50);
    QNF_SetRegBit(0x40,0x70,0x70);
    QNF_SetRegBit(0x19,0x80,0x80);
    QNF_SetRegBit(0x3E,0x80,0x80);
    QNF_SetRegBit(0x41,0xE0,0xC0);
    QNF_SetRegBit(0x42,0x10,0x10);
    QNF_SetRegBit(0x34, 0x7F,SMSTART_VAL);
    QNF_SetRegBit(0x35,0x7F,SNCSTART_VAL);
    QNF_SetRegBit(0x36,0x7F,HCCSTART_VAL);
#endif
}
/**********************************************************************
void QNF_ConfigScan(WORD start,WORD stop, BYTE step)
**********************************************************************
Description: config start, stop, step register for FM/AM CCA or CCS

Parameters:
	start
		Set the frequency (10kHz) where scan will be started,
		eg: 76.00MHz will be set to 7600.
	stop
		Set the frequency (10kHz) where scan will be stopped,
		eg: 108.00MHz will be set to 10800.
	step		
		1: set leap step to (FM)100kHz / 10kHz(AM)
		2: set leap step to (FM)200kHz / 1kHz(AM)
		0:  set leap step to (FM)50kHz / 9kHz(AM)
Return Value:
         None
**********************************************************************/
void QNF_ConfigScan(WORD start,WORD stop, BYTE step) 
{
#if 0
	// calculate ch para
	BYTE tStep = 0;
	BYTE tS;
	WORD fStart;
	WORD fStop;
	fStart = FREQ2CHREG(start);
	fStop = FREQ2CHREG(stop);
		// set to reg: CH_START
	tS = (BYTE) fStart;
	QN8025WriteReg((WORD)CH_START, tS);
	tStep |= ((BYTE) (fStart >> 6) & CH_CH_START);
	// set to reg: CH_STOP
	tS = (BYTE) fStop;
	QN8025WriteReg((WORD)CH_STOP, tS);
	tStep |= ((BYTE) (fStop >> 4) & CH_CH_STOP);
	// set to reg: CH_STEP
	tStep |= step << 6;
	QN8025WriteReg((WORD)CH_STEP, tStep);
#endif
}



/**********************************************************************
**********************************************************************/
#if 0
BYTE QNvol[16]=		// volume control  (increasing)
{
		0x28,	//-41
		0x10,	//-38
		0x29,	//-35
		0x11,	//-32
		0x2A,	//-29
		0x12,	//-26
		0x2B,	//-23
		0x13,	//-20
		0x2C,	//-17
		0x14,	//-14
		0x2D,	//-11
		0x15,	//-8
		0x2E,	//-5
		0x16,	//-2
		0x27,	//+2
		0x07	//+6
};
#endif
/*
**************************************************
*   �������ƣ�QN8025SetVol
*   ��    	�ܣ���������ģ������
*   ���������
*   ���������
*   ˵    	����
***************************************************
*/
VOID QN8035_VolumeSet( VOID )
{
//	BYTE temp1;
//	temp1 = QND_ReadReg(0x14);
//��������ֵ���Զ���MUTE
//	temp1 = (temp1 & 0xC0) | 0x07;//QNvol[vol];
//	QN8025WriteReg((WORD)0x14,temp1);

	QN8025WriteReg((WORD)0x14, (QND_ReadReg(0x14) & 0xC0) | 0x07);
}
/**************************************************************************************
*   �������ƣ�
*   ��    �ܣ�
*   ���������
*   ���������
*   ˵    ����
**************************************************************************************/

void QN_ChipInitialization()
{  
#if 0
	QN8025WriteReg(0x00, 0x81); 
	WaitMs(10);
	QN8035_Mute(TRUE);
	 QNF_SetRegBit(0x01,0x80,0x00);//setting clock source type:sine-wave clock or digital clock
#if 1
	if(MACRADIO_XTAL_12M)					// 12M CLK Enable
	{
		QN8025WriteReg(XTAL_DIV0, 0x6E);
		QN8025WriteReg(XTAL_DIV1, 0x01);
		QN8025WriteReg(XTAL_DIV2, 0x54); 
	}
	else
#endif
	{										// 32768 CLK Enable
		QN8025WriteReg(XTAL_DIV0, 0x01);
		QN8025WriteReg(XTAL_DIV1, 0x08);
		QN8025WriteReg(XTAL_DIV2, 0x5C); 
	}
	WaitMs(10);
	QN8025WriteReg(0x54, 0x47);//mod pll setting
	QN8025WriteReg(0x19, 0x40);//AGC setting
	QN8025WriteReg(0x2d, 0xD6);//notch filter threshold adjusting
	QN8025WriteReg(0x43, 0x10);//notch filter threshold enable    
	QN8025WriteReg(0x49, 0x7A);
	qnd_R16 = QND_ReadReg(0x16);
	qnd_R17 = QND_ReadReg(0x17);
	qnd_R46 = QND_ReadReg(0x46);
	WaitMs(50);
#else
	QN8025WriteReg(0x00, 0x81); 
    WaitMs(10);
   	QN8035_Mute(TRUE);
    /*********User sets chip working clock **********/
    //Following is where change the input clock wave type,as sine-wave or square-wave.
    //default set is 32.768KHZ square-wave input.
	QN8025WriteReg(0x01,QND_SINE_WAVE_CLOCK );
#if 1
	//if(1)//(MACRADIO_XTAL_12M)					// 12M CLK Enable
	{
		QN8025WriteReg(XTAL_DIV0, 0x6E);
		QN8025WriteReg(XTAL_DIV1, 0x01);
		QN8025WriteReg(XTAL_DIV2, 0x54); 
	}
	//else
#else
	{										// 32768 CLK Enable
		QN8025WriteReg(XTAL_DIV0, 0x01);
		QN8025WriteReg(XTAL_DIV1, 0x08);
		QN8025WriteReg(XTAL_DIV2, 0x5C); 
	}

#endif

	WaitMs(10);
	/********User sets chip working clock end ********/
	
    QN8025WriteReg(0x54, 0x47);//mod PLL setting
    //select SNR as filter3,SM step is 2db
	QN8025WriteReg(0x19, 0xc4);
    QN8025WriteReg(0x2d, 0xd6);//notch filter threshold adjusting
    QN8025WriteReg(0x43, 0x10);//notch filter threshold enable 
	QN8025WriteReg(0x47,0x39); 	
	//QN8025WriteReg(0x57, 0x21);//only for qn8035B test	
	WaitMs(50);
    //enter receiver mode directly
    QN8025WriteReg(0x00, 0x11);
	//Enable the channel condition filter3 adaptation,Let ccfilter3 adjust freely  
     QN8025WriteReg(0x1d,0xa9);       

	DBG((" FM REG16 = %BU\n",(QND_ReadReg(0x16) & 0xFF)));
	DBG((" FM REG17 = %BU\n",(QND_ReadReg(0x17) & 0xFF)));
	DBG((" FM REG46 = %BU\n",(QND_ReadReg(0x46) & 0xFF)));
	
//    QN8035_Mute(1);
#endif
}
/**********************************************************************
int QND_Init()
**********************************************************************
Description: Initialize device to make it ready to have all functionality ready for use.

Parameters:
None
Return Value:
1: Device is ready to use.
0: Device is not ready to serve function.
**********************************************************************/
BOOL QN8035_Init() 
{
	QN_ChipInitialization();

	DBG(("QN8035: Init() --1 \n"));

	
//	QNF_RXInit();	//17/06/2010
//	QND_SetSysMode(QND_MODE_RX |QND_MODE_FM); 


	QN8035_FreqSet(875);//gSys.RadioCtrl.Freq);

	DBG(("QN8035: Init() --2 \n"));

	
	QN8035_VolumeSet();//15);

	//QN8035_FreqSet(1043);//gSys.RadioCtrl.Freq);

	DBG(("QN8035: Init() \n"));
	
	return TRUE;
}
/**************************************************************************************
*   �������ƣ�
*   ��    �ܣ�
*   ���������
*   ���������
*   ˵    ����
**************************************************************************************/
//VOID QN8035_PowerDownDisable()
//{
#if 0
	BYTE val;
	val = (BYTE)((QND_MODE_RX |QND_MODE_FM) >> 8);		
	if (val)
	{
		val = val >> 3;
		if(val&0x10)
		{
			// set to new mode if it's not same as old
			if((QND_ReadReg(SYSTEM1) & R_TXRX_MASK) != val)
			{
				QN8035_Mute(TRUE);
				QNF_SetRegBit(SYSTEM1, R_TXRX_MASK, val); 
			}
		}
	} 	
#endif
//}


VOID QN8035_PowerDownEnable()
{
	QN8035_Mute(TRUE);
	//QNF_SetRegBit(0x48, 0x80, 0x00);
	//prevMode = QND_ReadReg(SYSTEM1);//I2C_ReadByte(QN8025_CHIP_ADDR, SYSTEM1);//QND_ReadReg(SYSTEM1);		
	//QNF_SetRegBit(SYSTEM1, R_TXRX_MASK, STNBY); 		
}
/**********************************************************************
void QND_SetSysMode(WORD mode)
***********************************************************************
Description: Set device system mode(like: sleep ,wakeup etc) 
Parameters:
mode:
set the system mode , it will be set by  some macro define usually:
	SLEEP:  it will set device system work on sleep mode
	WAKEUP: it will wakeup device system 
	TX:     it will set device system work on TX mode
	RX:     it will set device system work on RX mode
	FM:     it will set device system work on FM mode
	AM:     it will set device system work on AM mode
	TX|FM:  it will set device system work on FM,TX mode
	RX|AM;  it will set device system work on AM,RX mode
	RX|FM:	it will set device system work on FM,RX mode
Return Value:
	None	 
**********************************************************************/
void QND_SetSysMode(WORD mode) 
{	
#if 0
	BYTE val;
	switch(mode)		
	{		
		case QND_MODE_SLEEP:                       //set sleep mode		
			QNF_SetRegBit(0x48, 0x80, 0x00);
			prevMode = QND_ReadReg(SYSTEM1);//I2C_ReadByte(QN8025_CHIP_ADDR, SYSTEM1);//QND_ReadReg(SYSTEM1);		
			QNF_SetRegBit(SYSTEM1, R_TXRX_MASK, STNBY); 		
			break;		
		case QND_MODE_WAKEUP:                      //set wakeup mode		
			QN8025WriteReg((WORD)SYSTEM1, prevMode);		
			break;		
		case QND_MODE_DEFAULT:
			QNF_SetRegBit(SYSTEM2,0x30,0x10);
			break;
		default:	
			val = (BYTE)(mode >> 8);		
			if (val)
			{
				val = val >> 3;
				if(val&0x10)
				{
					// set to new mode if it's not same as old
					if((QND_ReadReg(SYSTEM1) & R_TXRX_MASK) != val)
					{
						QN8035_Mute(TRUE);
						QNF_SetRegBit(SYSTEM1, R_TXRX_MASK, val); 
					}
				}
			}    
			break;		
	}	
#endif
}

/**********************************************************************
void QND_TuneToCH(WORD ch)
**********************************************************************
Description:	Tune to the specified channel. Before use this function
make sure the QND_SetSysMode() has been called. If system is working 
on FM&TX mode,it will turn FM to ch, and start Transmit; If system is
working on FM&RX mode,it will turn FM to ch, and start FM play.
Parameters:
ch
Set the frequency (10kHz) to be tuned,
eg: 101.30MHz will be set to 10130.
Return Value:
	None
**********************************************************************/
BOOL QN8035_FreqSet(WORD Frep) 
{
#if 0
    BYTE reg;
    WORD Frep;
    Frep = gRadioCtrl.Freq;
    
//    QNF_RXInit();						// move to init //17/06/2010
    QN8035_Mute(TRUE);
    if((Frep==843) ||(Frep==729) ||(Frep==691))  //Peter has a list of channel to flip IMR. Please ask him for update
    {
        QNF_SetRegBit(CCA, IMR, IMR);           //this is a software patch
    }
    else
    {
        QNF_SetRegBit(CCA, IMR, 0x00);  
    }  
    QNF_ConfigScan(Frep, Frep, 1); 
    QNF_SetCh(Frep);
    QNF_SetRegBit(0x00, 0x33, 0x13);  //Enter CCA mode. This speed up the channel locking. 
    //Auto tuning
    QN8025WriteReg(0x4F, 0x80);
    reg = QND_ReadReg(0x4F);
    reg >>= 1;
    QN8025WriteReg(0x4F, reg);
    WaitMs(10);	 
    return TRUE;
#else
	 BYTE reg;
    //WORD Frep;
    //Frep = gRadioCtrl.Freq;

	QN8035_Mute(TRUE);
	//increase reference PLL charge pump current.
    QN8025WriteReg(REG_REF,0x7a);
	
	/********** QNF_RXInit ****************/
    QN8025WriteReg(0x1b,0x70);  //Let NFILT adjust freely
	//QNF_SetRegBit(0x2C,0x3F,0x12);  ///When SNR<ccth31, ccfilt3 will work
	//setting the threshold of Filter3 will be worked.
	QN8025WriteReg(0x2c,0x52);	
	//QNF_SetRegBit(0x1D,0x40,0x00);  ///Let ccfilter3 adjust freely
	//QNF_SetRegBit(0x41,0x0F,0x0A);  ///Set a hcc index to trig ccfilter3's adjust
    QN8025WriteReg(0x45,0x50);        ///Set aud_thrd will affect ccfilter3's tap number
	//QNF_SetRegBit(0x40,0x70,0x70);  ///snc/hcc/sm snr_rssi_sel; snc_start=0x40; hcc_start=0x30; sm_start=0x20
	QN8025WriteReg(0x40,0x70);
	//QNF_SetRegBit(0x19,0x80,0x80);  ///Use SNR for ccfilter selection criterion
	//selecting SNR as filter3 filter condition
	//QN8025WriteReg(0x19, 0xC2);
	//QNF_SetRegBit(0x3E,0x80,0x80);  ///it is decided by programming this register
	//QNF_SetRegBit(0x41,0xE0,0xC0);  ///DC notching High pass filter bandwidth; remove low freqency dc signals        
    QN8025WriteReg(0x41,0xca);
	QN8025WriteReg(0x34,SMSTART_VAL); ///set SMSTART
    QN8025WriteReg(0x35,SNCSTART_VAL); ///set SNCSTART
    QN8025WriteReg(0x36,HCCSTART_VAL); ///set HCCSTART
	/********** End of QNF_RXInit ****************/

	//WaitMs(50);
	
//    QN8035_Mute(1);   
    QNF_SetCh(Frep);    
    //enable CCA mode with user write into frequency
    QN8025WriteReg(0x00, 0x13); 
    //Auto tuning
    QN8025WriteReg(0x4f, 0x80);
    reg = QND_ReadReg(0x4f);
    reg >>= 1;
    QN8025WriteReg(0x4f, reg);
    ///avoid the "POP" noise.
    WaitMs(CH_SETUP_DELAY_TIME);
    ///decrease reference PLL charge pump current.
    QN8025WriteReg(REG_REF,0x70);   
//    QN8035_Mute(0);  
//    WaitMs(10);	 

	QN8035_Mute(FALSE);

	DBG((" FM SET FREQ = %d\n",Frep));

    return TRUE;
#endif
}
/***********************************************************************
void QND_RXSetTH(UINT8 th)
***********************************************************************
Description: Setting the threshold value of automatic scan channel 
th:
  Setting threshold for quality of channel to be searched,
  the range of th value:CCA_SENSITIVITY_LEVEL_0 ~ CCA_SENSITIVITY_LEVEL_9   
Return Value:
  None
***********************************************************************/
VOID QN8035_AutoScan_Init(VOID)//VOID QND_RXSetTH()//BYTE th) 
{  
#if 0
	BYTE rssiTH;
	BYTE snrTH;
//	WORD rssi_snr_TH;
#if 0
	WORD rssi_snr_TH_tbl [10] = 
			{ 
				CCA_SENSITIVITY_LEVEL_0,CCA_SENSITIVITY_LEVEL_1,
                            CCA_SENSITIVITY_LEVEL_2,CCA_SENSITIVITY_LEVEL_3,
                            CCA_SENSITIVITY_LEVEL_4,CCA_SENSITIVITY_LEVEL_5,
                            CCA_SENSITIVITY_LEVEL_6,CCA_SENSITIVITY_LEVEL_7,
                            CCA_SENSITIVITY_LEVEL_8,CCA_SENSITIVITY_LEVEL_9                                    
			};
#endif                                  
//	rssi_snr_TH = CCA_SENSITIVITY_LEVEL_1;//rssi_snr_TH_tbl[th];
	rssiTH = 0x1E;//(BYTE) (rssi_snr_TH >> 8);
	snrTH = 0x0A;//0x07//(BYTE) (rssi_snr_TH & 0xff);

	QNF_SetRegBit(GAIN_SEL,0x08,0x08);//NFILT program is enabled 
	//selection filter:filter3
	QNF_SetRegBit(CCA1,0x30,0x30);
	//Enable the channel condition filter3 adaptation,Let ccfilter3 adjust freely  
	QNF_SetRegBit(SYSTEM_CTL2,0x40,0x00);
	QN8025WriteReg(PLT1,0x00);
	//selection pilot threshold: 2/250(default) 
	QNF_SetRegBit(PLT2,0x1C,0x08);
	QN8025WriteReg(CCA_CNT1,0x00);
	QNF_SetRegBit(CCA_CNT2,0x3F,0x01);
	//selection the time of CCA FSM wait SNR calculator to settle:20ms
	//0x00:	    20ms(default)
	//0x40:	    40ms
	//0x80:	    60ms
	//0xC0:	    100m
	QNF_SetRegBit(CCA_SNR_TH_1 , 0xC0, 0x00);  //0x00
	//selection the time of CCA FSM wait RF front end and AGC to settle:20ms
	//0x00:     10ms
	//0x40:     20ms(default)
	//0x80:     40ms
	//0xC0:     60ms                            
	QNF_SetRegBit(CCA_SNR_TH_2, 0xC0, 0x80);  //0x80
	QNF_SetRegBit(CCA, 0x3F, rssiTH);  //setting RSSI threshold for CCA
	QNF_SetRegBit(CCA_SNR_TH_1 , 0x3F, snrTH); //setting SNR threshold for CCA
#else
	QN8035_Mute(TRUE);

	QN8025WriteReg(0x4f, 0x00);//enable auto tunnging in CCA mode
    ///increase reference PLL charge pump current.
    QN8025WriteReg(REG_REF,0x7a);
	//NFILT program is enabled 
    QN8025WriteReg(0x1b,0x78);
	//using Filter3
    QN8025WriteReg(CCA1,0x75);    
    //setting CCA IF counter error range value(256).
    QN8025WriteReg(CCA_CNT2,0x05);
#if PILOT_CCA   
    QN8025WriteReg(PLT1,0x00); 
#endif    
	//selection the time of CCA FSM wait SNR calculator to settle:20ms
	//0x00:	    20ms(default)
	//0x40:	    40ms
	//0x80:	    60ms
	//0xC0:	    100m
	//    QNF_SetRegBit(CCA_SNR_TH_1 , 0xC0, 0x00);     
    //selection the time of CCA FSM wait RF front end and AGC to settle:20ms
    //0x00:     10ms
	//0x40:     20ms(default)
    //0x80:     40ms
	//0xC0:     60ms                            
	//    QNF_SetRegBit(CCA_SNR_TH_2, 0xC0, 0x40); 
	//    QNF_SetRegBit(CCA, 30);  //setting CCA RSSI threshold is 30
	QN8025WriteReg(CCA,QND_ReadReg(CCA)&0xc0|25);
#if PILOT_CCA	
	QN8025WriteReg(CCA_SNR_TH_1,8+0); //setting SNR threshold for CCA
#else
	QN8025WriteReg(CCA_SNR_TH_1,9+0); //setting SNR threshold for CCA	
#endif

#endif
}

#if 0
VOID QN8035_AutoScan_Init(VOID)
{
	QND_RXSetTH();		//5--7 
}
#endif
BOOL QN8035_SeekStart(WORD freq)//,BYTE Direction)//, BYTE db)
{
//	Direction = Direction;
	//WORD freq;
	//freq = gRadioCtrl.Freq;
	QN8035_Mute(TRUE);
#if 0
	QNF_ConfigScan(freq,  freq, 1);
	QNF_SetRegBit(SYSTEM1,RXCCA_MASK,RX_CCA);
#endif
	QN8035_AutoScan_Init();
    QNF_SetCh(freq);   
	//QNF_SetRegBit(SYSTEM1,0x03,0x02);//enter channel scan mode,channel frequency is decided by internal CCA
	//entering into RX mode and CCA mode,channels index decide by CCA.
	QN8025WriteReg(0x00, 0x12);
	QN8035_Mute(TRUE);
	return TRUE;
	
}
BYTE QN8035_SeekResultGet(VOID)//WORD pFreq)
{
	BYTE regValue;
//	static	BYTE	timeOut = 0;
//	BYTE readCnt ,stereoCount;
//	pFreq = pFreq;
//	WaitMs(30);
#if 1
#if 1
	regValue = QND_ReadReg(SYSTEM1);
	if((!(regValue & CHSC))/* || (timeOut > 100)*/)
	{
		//timeOut = 0;
		regValue = QND_ReadReg(STATUS1) & RXCCA_FAIL;
		if(regValue)
		{       
			return 0;// RADIO_SEEK_STC;
		}
	#if 0
		WaitMs(60);
		regValue = QND_ReadReg(SNR);
		if(regValue <= CCA_PILOT_SNR_FILTER)
		{
			stereoCount = 0;
			for(readCnt = 0;readCnt < CCA_PILOT_READ_COUNT;readCnt++)
			{
				WaitMs(CCA_PILOT_READ_COUNT_DELAY);
				stereoCount += QND_ReadReg(STATUS1) & ST_MO_RX; 	      
			} 
			if(stereoCount >= CCA_PILOT_TH)
			{
				return RADIO_SEEK_STC;
//				return RADIO_SEEK_VALIDSTATION;
			}
		}
	#endif
		return 1;//RADIO_SEEK_VALIDSTATION;   
	}
	//timeOut++;
	return 0;//RADIO_SEEK_FALSE;
#endif

#else
	BYTE regValue;
	static	BYTE timeOut;
	BYTE isValidChannelFlag; 	
#if PILOT_CCA    
	BYTE snr,readCnt,stereoCount=0;
#endif 
	WORD freq;
   	freq = gRadioCtrl.Freq;

    QNF_SetCh(freq);   
	//QNF_SetRegBit(SYSTEM1,0x03,0x02);//enter channel scan mode,channel frequency is decided by internal CCA
	//entering into RX mode and CCA mode,channels index decide by CCA.
	QN8025WriteReg(0x00, 0x12);
	timeOut = 20;
	do
    {
        regValue = QND_ReadReg(SYSTEM1);
         WaitMs(5);   //delay 5ms
        timeOut--;
    } 
    //if it seeks a potential channel or time out,the loop will be quited     
    while((regValue & CHSC) && timeOut);
    //TRACE("CHSC:%d,timeOut:%d \n",regValue&CHSC,timeOut);
    //reading out the rxcca_fail flag of RXCCA status 
    isValidChannelFlag = (QND_ReadReg(STATUS1) & RXCCA_FAIL ? 0:1) && timeOut;	
	if(isValidChannelFlag)
	{
#if PILOT_CCA
		 WaitMs(100);  
		snr = QND_ReadReg(SNR);       
		if(snr> 25) return RADIO_SEEK_VALIDSTATION;		
		for(readCnt=10;readCnt>0;readCnt--)
		{
			 WaitMs(2);
			stereoCount += ((QND_ReadReg(STATUS1) & ST_MO_RX) ? 0:1); 	      
			if(stereoCount >= 3) return RADIO_SEEK_VALIDSTATION;                 
		} 	
#else
		return RADIO_SEEK_VALIDSTATION;   
#endif
	}
	return RADIO_SEEK_STC;
#endif
}

/**************************************************************************************
*   �������ƣ�QN8025_FM_MUTE
*   ��    �ܣ�
*   ���������MUTEFLAG
*   ���������
*   ˵    ����MUTE  QN8025 FM Volume
**************************************************************************************/
VOID QN8035_Mute(BOOL MUTEFLAG)
{
#if 1
	if(MUTEFLAG)
	{
//		QNF_SetRegBit(0x4C, 0x0B, 0x0B);
		QN8025WriteReg(0x4A, 0x30);
	}
	else
	{
		WaitMs(200);
//		QNF_SetRegBit(0x4C, 0x0B, 0x00);
		QN8025WriteReg(0x4A, 0x10);
	}

#else
	QN8025WriteReg(0x4a, MUTEFLAG?0x30:0x10); 
#endif
}
/*
**************************************************
*   �������ƣ�QND_8025_GetFMID
*   ��    	�ܣ�
*   ���������
*   ���������
*   ˵    	����
***************************************************
*/
BOOL QN8035_ReadID(void)
{
	if ((QND_ReadReg(0x06) & 0xFF) == 0x84)//I2C_ReadByte(QN8025_CHIP_ADDR, 0x06)&0xf0) == 0x80)//QND_ReadReg(0x06) & 0xf0) == 0x80)
		//|| ((QND_ReadReg(0x06) & 0xF0) == 0x80))
	{
		DBG((" FM QN8035\n"));
		return TRUE;
	}
	else
	{
		DBG((" FM REG06 = %BU\n",(QND_ReadReg(0x06) & 0xFF)));
		return FALSE;
	}
}


#endif

