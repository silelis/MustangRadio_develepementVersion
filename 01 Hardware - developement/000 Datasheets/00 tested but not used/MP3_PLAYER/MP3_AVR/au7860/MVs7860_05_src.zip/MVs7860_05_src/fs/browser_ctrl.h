#ifndef _BROWSER_CTRL_H_
#define _BROWSER_CTRL_H_


//Browser initial.
VOID FileBrowseInit();

//Browser control.
VOID PlayStateBrowseOp();

#endif
