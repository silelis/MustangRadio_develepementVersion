#ifndef _SPI_FLASH_H_
#define	_SPI_FLASH_H_


//Inital SPI device structure.
VOID SpiFlashInit();

//Read data to memory from spi flash.
VOID SpiFlashRead(DWORD StartAddr, BYTE* Buffer, WORD Len);

//Write data to spi flash from memory.
BOOL SpiFlashWrite(DWORD StartAddr, BYTE* Buffer, WORD Len);

//Erase chip.
BOOL SpiFlashStartChipErase();

//Get busy status.
BOOL SpiFlashIsBusy();

//Get link status.
BOOL SpiFlashIsLink();


#endif

