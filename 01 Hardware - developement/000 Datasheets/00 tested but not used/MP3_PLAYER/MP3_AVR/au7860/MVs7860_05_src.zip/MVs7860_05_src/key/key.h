#ifndef _KEY_H_
#define _KEY_H_


// Initialize key scan operation.
VOID KeyScanInit();

// Key process.
VOID KeyEventGet();
VOID ChkBKLightStatus();
/*********************************************************************
* LcdBkLightOpt
* ���Ʊ�����/����
* OptVal == 1 :��,������
*********************************************************************/
VOID LcdBkLightOpt( BYTE OptVal );

#endif 
