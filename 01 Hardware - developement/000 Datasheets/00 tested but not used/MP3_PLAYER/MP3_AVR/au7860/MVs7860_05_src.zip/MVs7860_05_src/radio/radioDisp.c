/*****************************************************
*							PACE Corp.
*				Copyright 2012, PACE Corp., ShengZhen, China
*							All rights reserved.
*
* Filename:			
* Description:		
* Change History:
*					
*					- created

*******************************************************/

#include "syscfg.h"
#include "sysctrl.h"
#include "timer.h"
#include "utility.h" 
#include "radio_ctrl.h"
#include "message.h"
#include "key.h"
#include "debug.h"

//#include	"..\pace\paceLib\paceLib.h" //LXL COMENT

#define u8 BYTE
#define		_RADIO_DISP_C
#include	"radioDisp.h"

TIMER	radioTimer;

RADIO_DISP_STS_TYPEDEF		radioDispSts=RADIO_DISP_STS_INIT;
#ifdef FUNC_RADIO_EN
//extern	u8		RadioChkChNum(u8 fg); //lxl 7-19
#endif

/******************************************************
Function:
Input:
Output:
Description:

******************************************************/
void		radioDispFreq(void)
{
		WORD	frq=gRadioCtrl.Freq;
		BYTE	wk=0;
		wk=(BYTE)(frq/1000);
		if (wk == 0)
		{
			//paceDispChar(0, ' '); //LXL
		}
		else
		{
			//paceDispChar(0, wk+'0');
		}
		wk=(BYTE)((frq%1000)/100);
		//paceDispChar(1, wk+'0');
		wk=(BYTE)(((frq%1000)%100)/10);
		//paceDispChar(2, wk+'0');
		wk=(BYTE)(frq%10);
		//paceDispChar(3, wk+'0');
}

/******************************************************
Function:
Input:
Output:
Description:

******************************************************/
u8		radioDispCh(u8 ch)
{
	u8	ch_buff=ch;
	if (ch == 0)
		return 0;
	//paceDispChar(0, 'C'); //LXL COMMENT
	//paceDispChar(1, 'H');
	//paceDispChar(2, (ch_buff/10)+0x30);
	//paceDispChar(3, (ch_buff%10)+0x30);
	return 1;
}

/******************************************************
Function:
Input:
Output:
Description:

******************************************************/

void		radioDispPrc(void)
{
#if 0	//commented by lxl 7-19
	if (paceAudioDispChk())
	{
		radioDispSts = RADIO_DISP_STS_FREQ;
		return;
	}
#endif
	switch (radioDispSts)
	{
		case	RADIO_DISP_STS_INIT:
			//paceDispIcon(ICON_ID_FM, DISP_ON); //lxl
#ifdef FUNC_RADIO_EN
		#if 0
			if (RadioChkChNum(1) == 1)
				radioDispSts = RADIO_DISP_STS_CH;
			else
		#endif		
				radioDispSts = RADIO_DISP_STS_FREQ;
#endif			
			break;

		case	RADIO_DISP_STS_IDLE:
			{
				static	WORD	frq_buff=0xffff;
				if (frq_buff != gRadioCtrl.Freq)
				{
					frq_buff = gRadioCtrl.Freq;
					radioDispFreq();
				}
			}
			break;

		case	RADIO_DISP_STS_FREQ:	
			radioDispFreq();
			radioDispSts = RADIO_DISP_STS_IDLE;
			break;

		case	RADIO_DISP_STS_CH:
			if (radioDispCh(gRadioCtrl.CurCh))
			{
				TimeOutSet(&radioTimer, 1000);
				radioDispSts = RADIO_DISP_STS_CH_DISP;
			}
			else
			{
				radioDispSts = RADIO_DISP_STS_FREQ;
			}
			break;

		case	RADIO_DISP_STS_CH_DISP:
			if (IsTimeOut(&radioTimer))
			{
				radioDispSts = RADIO_DISP_STS_FREQ;
			}
			break;

		case	RADIO_DISP_STS_EXIT:
//			paceDispIcon(ICON_ID_FM, DISP_OFF); //lxl comment
			DBG(("Radio Display Exit!\n"));
			break;
		default:
			break;
	}
}






/******************************************************
Function:
Input:
Output:
Description:

******************************************************/
void		radioDispSetSts(RADIO_DISP_STS_TYPEDEF sts)
{
#if 0
	radioDispSts = sts;
	radioDispPrc();
#else
		//lxl 7-24
#endif
}


////////////////////////////  END FILE  ///////////////////////

