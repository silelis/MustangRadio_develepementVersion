#include "syscfg.h"
#include "message.h"
#include "rtc_ctrl.h"

    
#ifdef FUNC_RTC_EN


// RTC control state.
typedef enum _RTC_STATE
{
	RTC_STATE_IDLE,
	RTC_STATE_SET_TIME,
	RTC_STATE_SET_ALARM,

} RTC_STATE;


typedef enum _RTC_SUB_STATE
{
	RTC_SET_NONE = 0,
    RTC_SET_ALARM_NUM,
    RTC_SET_ALARM_MODE,
	RTC_SET_YEAR,
	RTC_SET_MON,
	RTC_SET_DATE,
	RTC_SET_WEEK,
	RTC_SET_HR,
	RTC_SET_MIN,
	RTC_SET_SCE,
	
} RTC_SUB_STATE;



BYTE RtcState;
BYTE RtcSubState;
BYTE RtcUpdateDisplay = FALSE;
BYTE RtcFlag = 1;


static TIMER RtcReadTimer;
static TIMER RtcAutoOutTimer;	

#define RTC_AUTO_OUT_TIME	5000

RTC_DATE_TIME gRtcTime;

#ifdef FUNC_ALARM_EN
BYTE RtcAlarmNum = 1;	
RTC_DATE_TIME gAlarmTime;
BYTE gAlarmMode = ALARM_MODE_PER_WEEK;

SBYTE modeDisp[3][21] = 
{
    {"ALARM_MODE_ONCE_ONLY"},
    {"ALARM_MODE_PER_DAY"},
    {"ALARM_MODE_PER_WEEK"}
};

#endif


static VOID RtcTimeDown(RTC_DATE_TIME* Time)
{
	switch(RtcSubState)
	{
#ifdef FUNC_ALARM_EN
        case RTC_SET_ALARM_NUM:
            RtcAlarmNum--;	
            if(RtcAlarmNum < 1)
            {
                RtcAlarmNum = 8;    
            }
            DBG(("RtcAlarmNum:%bu\n",RtcAlarmNum));	
            break;

        case RTC_SET_ALARM_MODE:
            gAlarmMode--;
            if(gAlarmMode < 1)
            {
                gAlarmMode = 3;    
            }
            DBG(("gAlarmMode[%bu]=%s\n",gAlarmMode,modeDisp[gAlarmMode-1]));
            break;
#endif
		case RTC_SET_YEAR:
			Time->Year--;
			if(Time->Year < RTC_START_YEAR)
			{
				Time->Year = RTC_END_YEAR;
			}
			break;
	
		case RTC_SET_MON:
			Time->Mon--;
			if(Time->Mon == 0)
			{
				Time->Mon = 12;
			}
			if(Time->Date > GetMonthDays(Time->Year, Time->Mon))
			{
				Time->Date = GetMonthDays(Time->Year, Time->Mon);
			}
			break;
	
		case RTC_SET_DATE:
			Time->Date--;
			if(Time->Date == 0)
			{
				Time->Date = GetMonthDays(Time->Year, Time->Mon);
			}
			break;
	
		case RTC_SET_WEEK:
			if(Time->WDay > 0)
			{
				Time->WDay--;			
			}
			else
			{
				Time->WDay = 6;	
			}
			break;
	
		case RTC_SET_HR:
			Time->Sec = 0;
			Time->Hour--;
			if(Time->Hour > 23)
			{
				Time->Hour = 23;
			}
			break;
	
		case RTC_SET_MIN:
			Time->Sec = 0;
			Time->Min--;
			if(Time->Min > 59)
			{
				Time->Min = 59;
			}
			break;

		default:
			break;
	}
}

static VOID RtcTimeUp(RTC_DATE_TIME* Time)
{
	switch(RtcSubState)
	{
#ifdef FUNC_ALARM_EN
        case RTC_SET_ALARM_NUM:
            RtcAlarmNum++;	
            if(RtcAlarmNum > 8)
            {
                RtcAlarmNum = 1;    
            }
            DBG(("RtcAlarmNum:%bu\n",RtcAlarmNum));	
            break;

        case RTC_SET_ALARM_MODE:
            gAlarmMode++;
            if(gAlarmMode > 3)
            {
                gAlarmMode = 1;    
            }
            DBG(("gAlarmMode[%bu]=%s\n",gAlarmMode,modeDisp[gAlarmMode-1]));
            break;
#endif
    	case RTC_SET_YEAR:
            DBG(("Time->Year:%u\n",Time->Year));
			Time->Year++;
			if(Time->Year > RTC_END_YEAR)
			{
				Time->Year = RTC_START_YEAR;
			}
			break;
	
		case RTC_SET_MON:
			Time->Mon++;
			if(Time->Mon > 12)
			{
				Time->Mon = 1;
			}
			if(Time->Date > GetMonthDays(Time->Year, Time->Mon))
			{
				Time->Date = GetMonthDays(Time->Year, Time->Mon);
			}
			break;
	
		case RTC_SET_DATE:
			Time->Date++;
			if(Time->Date > GetMonthDays(Time->Year, Time->Mon))
			{
				Time->Date = 1;
			}
			break;

		case RTC_SET_WEEK:
			if(Time->WDay < 6)
			{
				Time->WDay++;			
			}
			else
			{
				Time->WDay = 0;	
			}
			break;
	
		case RTC_SET_HR:
			Time->Sec = 0;
			Time->Hour++;
			if(Time->Hour > 23)
			{
				Time->Hour = 0;
			}
			break;
	
		case RTC_SET_MIN:
			Time->Sec = 0;
			Time->Min++;
			if(Time->Min > 59)
			{
				Time->Min = 0;
			}
			break;

		default:
			break;
	}
}


static VOID RtcNextSubState()
{
	switch(RtcSubState)
	{
#ifdef FUNC_ALARM_EN
        case RTC_SET_ALARM_NUM:
            DBG(("RTC_SET_ALARM_MODE\n"));
            RtcSubState = RTC_SET_ALARM_MODE;
            break;

        case RTC_SET_ALARM_MODE:
            switch(gAlarmMode)
            {
                case 1:
                    DBG(("RTC_SET_YEAR\n"));
			        RtcSubState = RTC_SET_YEAR;
                    break;
                    
                case 2:
                    DBG(("RTC_SET_HR\n"));
			        RtcSubState = RTC_SET_HR;
                    break;
                    
                case 3:
                    DBG(("RTC_SET_WEEK\n"));
                    RtcSubState = RTC_SET_WEEK;
                    break;
                    
                default:
                    break;   
            }
            break;
#endif
		case RTC_SET_YEAR:
			DBG(("RTC_SET_MON\n"));
			RtcSubState = RTC_SET_MON;
			break;
	
		case RTC_SET_MON:
			DBG(("RTC_SET_DATE\n"));
			RtcSubState = RTC_SET_DATE;
			break;
	
		case RTC_SET_DATE:
			DBG(("RTC_SET_HR\n"));
			RtcSubState = RTC_SET_HR;
			break;

		case RTC_SET_WEEK:
			DBG(("RTC_SET_HR\n"));
			RtcSubState = RTC_SET_HR;
			break;

		case RTC_SET_HR:
			DBG(("RTC_SET_MIN\n"));
			RtcSubState = RTC_SET_MIN;
			break;

        case RTC_SET_MIN:
		case RTC_SET_NONE:
		default:
			if(RtcState == RTC_STATE_SET_TIME)
			{
				DBG(("RTC_SET_YEAR\n"));
				RtcSubState = RTC_SET_YEAR;
			}
#ifdef FUNC_ALARM_EN
            else if(RtcState == RTC_STATE_SET_ALARM)
            {
                DBG(("RTC_SET_ALARM_NUM\n"));
                RtcSubState = RTC_SET_ALARM_NUM;
            }
#endif	
			break;
	}
}

#ifdef FUNC_LUNAR_EN
static VOID DisplayLunarDate()
{
	//ũ���������
	BYTE CODE LunarYearName[12][2] = {"��", "ţ", "��", "��", "��", "��", "��", "��", "��", "��", "��", "��"};
	
	//ũ���·�����
	BYTE CODE LunarMonthName[12][2] = {"��", "��", "��", "��", "��", "��", "��", "��", "��", "ʮ", "��", "��"};
	
	//ũ����������
	BYTE CODE LunarDateName[30][4] = {"��һ", "����", "����", "����", "����", "����", "����", "����", "����", "��ʮ", 
									  "ʮһ", "ʮ��", "ʮ��", "ʮ��", "ʮ��", "ʮ��", "ʮ��", "ʮ��", "ʮ��", "��ʮ",
									  "إһ", "إ��", "إ��", "إ��", "إ��", "إ��", "إ��", "إ��", "إ��", "��ʮ"};
	
	//ũ���������
	BYTE CODE HeavenlyStemName[10][2] = {"��", "��", "��", "��", "��", "��", "��", "��", "��", "��"};
	
	//ũ����֧����
	BYTE CODE EarthlyBranchName[12][2] = {"��", "��", "��", "î", "��", "��", "��", "δ", "��", "��", "��", "��"};
	
	RTC_LUNAR_DATE LunarDate;

	SolarToLunar(&gRtcTime, &LunarDate);	
	DBG(("ũ�� %d�� ", (WORD)LunarDate.Year));
	DBG(("%-.2s%-.2s�� ", HeavenlyStemName[GetHeavenlyStem(LunarDate.Year)], 
						  EarthlyBranchName[GetEarthlyBranch(LunarDate.Year)]));
	DBG(("%-.2s�� ", LunarYearName[GetEarthlyBranch(LunarDate.Year)]));
	if(LunarDate.IsLeapMonth)
	{
		DBG(("��"));
	}
	DBG(("%-.2s��", LunarMonthName[LunarDate.Month - 1]));
	
	if(LunarDate.MonthDays == 29)
	{
		DBG(("(С)"));
	}
	else
	{
		DBG(("(��)"));
	}
	
	DBG(("%-.4s ", LunarDateName[LunarDate.Date - 1]));

	if((LunarDate.Month == 1) && (LunarDate.Date == 1))			//����
	{
		DBG(("����"));
	}
	else if((LunarDate.Month == 1) && (LunarDate.Date == 15))	//Ԫ����
	{
		DBG(("Ԫ����"));
	}
	else if((LunarDate.Month == 5) && (LunarDate.Date == 5))	//�����
	{
		DBG(("�����"));
	}
	else if((LunarDate.Month == 7) && (LunarDate.Date == 7))	//��Ϧ���˽�
	{
		DBG(("��Ϧ���˽�"));
	}
	else if((LunarDate.Month == 7) && (LunarDate.Date == 15))	//��Ԫ��
	{
		DBG(("��Ԫ��"));
	}
	else if((LunarDate.Month == 8) && (LunarDate.Date == 15))	//�����
	{
		DBG(("�����"));
	}
	else if((LunarDate.Month == 9) && (LunarDate.Date == 9))	//������
	{
   		DBG(("������"));
	}
	else if((LunarDate.Month == 12) && (LunarDate.Date == 8))	//���˽�
	{
	 	DBG(("���˽�"));
	}
	else if((LunarDate.Month == 12) && (LunarDate.Date == 23))	//С��
	{
		DBG(("С��"));
	}
	else if((LunarDate.Month == 12) && (LunarDate.Date == LunarDate.MonthDays))	//��Ϧ
	{
		DBG(("��Ϧ"));
	}
}

#endif

VOID RtcDisplay()
{
	static BYTE TempSec = -1;
    
	//Display RTC time
	if(IsTimeOut(&RtcReadTimer))
	{
		TimeOutSet(&RtcReadTimer, 500);
		GetRTCCurrTime(&gRtcTime);
		if(gRtcTime.Sec != TempSec)
		{
			TempSec = gRtcTime.Sec;	
			RtcUpdateDisplay = TRUE;
		}
	}

	if(RtcUpdateDisplay)
	{
		RtcUpdateDisplay = FALSE;
		
        if(RtcFlag == 1)
        {
    		//YYYY-MM-DD(W) HH:MM:SS
    		DBG(("%d-%-.2d-%-.2d(%d) ", 
    			(WORD)gRtcTime.Year, 
    			(WORD)gRtcTime.Mon, 
    			(WORD)gRtcTime.Date, 
    			(WORD)gRtcTime.WDay));

#ifdef FUNC_LUNAR_EN  
    		DisplayLunarDate();
#endif
    				
    		DBG((" %-.2d:%-.2d:%-.2d  ",  
    			(WORD)gRtcTime.Hour, 
    			(WORD)gRtcTime.Min, 
    			(WORD)gRtcTime.Sec));
    		DBG(("\n"));
        }
#ifdef FUNC_ALARM_EN
        else if(RtcFlag == 2)
        {
            //YYYY-MM-DD(W) HH:MM:SS
    		DBG(("%d-%-.2d-%-.2d(%d) ", 
    			(WORD)gAlarmTime.Year, 
    			(WORD)gAlarmTime.Mon, 
    			(WORD)gAlarmTime.Date, 
    			(WORD)gAlarmTime.WDay));
    				
    		DBG((" %-.2d:%-.2d:%-.2d  ",  
    			(WORD)gAlarmTime.Hour, 
    			(WORD)gAlarmTime.Min, 
    			(WORD)gAlarmTime.Sec));
    		DBG(("\n"));    
        }
#endif
	}
}


VOID RtcCtrlInit()
{
	InitRTC();
	TimeOutSet(&RtcReadTimer, 0);
	RtcState = RTC_STATE_IDLE;
}


VOID RtcStateCtrl()
{
	MESSAGE event = MessageGet(MSG_FIFO_RTC);	
	
	if(RtcState == RTC_STATE_IDLE)
	{
		switch(event)
		{	
			case MSG_RTC_SET:
				DBG(("RTC_SET\n"));
                RtcFlag = 1;
				RtcUpdateDisplay = TRUE;
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				RtcState = RTC_STATE_SET_TIME;
				RtcSubState = RTC_SET_NONE;
				RtcNextSubState();
				break;
#ifdef FUNC_ALARM_EN
			case MSG_ALARM_SET:
				DBG(("ALARM_SET\n"));
                RtcFlag = 2;
				RtcUpdateDisplay = TRUE;
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				RtcState = RTC_STATE_SET_ALARM;
				RtcSubState = RTC_SET_NONE;
				RtcNextSubState();
				break;
#endif  
			default:
				break;
		}
	}
	else if(RtcState == RTC_STATE_SET_TIME)
	{
		switch(event)
		{
			case MSG_RTC_DOWN:
				DBG(("RTC_DOWN\n"));
				RtcUpdateDisplay = TRUE;
				GetRTCCurrTime(&gRtcTime);
				RtcTimeDown(&gRtcTime);
				SetRTCCurrTime(&gRtcTime);
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				break;

			case MSG_RTC_UP:
				DBG(("RTC_UP\n"));
				RtcUpdateDisplay = TRUE;
				GetRTCCurrTime(&gRtcTime);
				RtcTimeUp(&gRtcTime);
				SetRTCCurrTime(&gRtcTime);
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				break;

			case MSG_RTC_SW:
				RtcUpdateDisplay = TRUE;
				RtcNextSubState();
				TimeOutSet(&RtcAutoOutTimer, 5000);
				break;

			default:
				break;
		}

		if(IsTimeOut(&RtcAutoOutTimer))
		{
			DBG(("EXIT RTC_STATE_SET_TIME!\n"));			
			RtcState = RTC_STATE_IDLE;
			RtcSubState = RTC_SET_NONE;
		}
	}
#ifdef FUNC_ALARM_EN
	else if(RtcState == RTC_STATE_SET_ALARM)
	{
		switch(event)
		{
			case MSG_RTC_DOWN:
				DBG(("ALARM RTC_DOWN\n"));
				RtcUpdateDisplay = TRUE;

                if(GetAlarmStatus(RtcAlarmNum) == 2)      //DBG(("���Ӳ�����\n")); 
                {
                    gAlarmTime.Year = 1980;
                	gAlarmTime.Mon = 1;
                	gAlarmTime.Date = 1;
                	gAlarmTime.WDay = 2;
                	gAlarmTime.Hour = 0;
                	gAlarmTime.Min = 0;
                	gAlarmTime.Sec = 0;   
                    SetAlarmTime(RtcAlarmNum, gAlarmMode, &gAlarmTime); 
                }
                
				RtcTimeDown(&gAlarmTime);
				SetAlarmTime(RtcAlarmNum, gAlarmMode, &gAlarmTime);
                TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				break;

			case MSG_RTC_UP:
				DBG(("ALARM RTC_UP\n"));
				RtcUpdateDisplay = TRUE;

                if(GetAlarmStatus(RtcAlarmNum) == 2)      //DBG(("���Ӳ�����\n")); 
                {
                    gAlarmTime.Year = 1980;
                	gAlarmTime.Mon = 1;
                	gAlarmTime.Date = 1;
                	gAlarmTime.WDay = 2;
                	gAlarmTime.Hour = 0;
                	gAlarmTime.Min = 0;
                	gAlarmTime.Sec = 0;   
                    SetAlarmTime(RtcAlarmNum, gAlarmMode, &gAlarmTime); 
                }
                
				RtcTimeUp(&gAlarmTime);
				SetAlarmTime(RtcAlarmNum, gAlarmMode, &gAlarmTime);
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				break;

			case MSG_RTC_SW:
				RtcUpdateDisplay = TRUE;
				RtcNextSubState();		
				TimeOutSet(&RtcAutoOutTimer, RTC_AUTO_OUT_TIME);
				break;

			default:
				break;
		}

		if(IsTimeOut(&RtcAutoOutTimer))
		{
			DBG(("EXIT RTC_STATE_SET_TIME!\n"));		
			RtcState = RTC_STATE_IDLE;
			RtcSubState = RTC_SET_NONE;

            RtcFlag = 1;		
		}
	}
#endif

#ifdef FUNC_ALARM_EN	
	//Check alarm
	if(CheckRtcAlarmFlag())
	{
		DBG(("RTC ALARM COME!\n"));
	}
#endif
	//Display time
	RtcDisplay();
}


#endif
