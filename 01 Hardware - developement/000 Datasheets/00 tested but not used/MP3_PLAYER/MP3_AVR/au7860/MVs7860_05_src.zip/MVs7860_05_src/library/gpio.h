#ifndef _GPIO_H_
#define	_GPIO_H_


extern volatile BYTE XDATA	baGPIOCtrl[];


//////////////////////////////////////////////////////////
// GPIO control register index.
// Bank A
#define		GPIO_A_IN						0x00
#define		GPIO_A_OUT						0x01
#define		GPIO_A_IE						0x02
#define		GPIO_A_OE						0x03
#define		GPIO_A_DS						0x04
#define		GPIO_A_PU						0x05
#define		GPIO_A_PD						0x06
                                			
// Bank B                       			
#define		GPIO_B_IN						0x10
#define		GPIO_B_OUT						0x11
#define		GPIO_B_IE	 					0x12
#define		GPIO_B_OE						0x13
#define		GPIO_B_DS						0x14
#define		GPIO_B_PU						0x15
#define		GPIO_B_PD						0x16
#define		GPIO_B_PD_1_2MA					0x17
#define		GPIO_B_PD_2_4MA					0x18
                                			                                			
// Bank C                       			
#define		GPIO_C_IN						0x20
#define		GPIO_C_OUT						0x21
#define		GPIO_C_IE						0x22
#define		GPIO_C_OE						0x23
#define		GPIO_C_DS						0x24
#define		GPIO_C_PU						0x25
#define		GPIO_C_PD						0x26
#define		GPIO_C_INTE						0x27
#define		GPIO_C_PTRIG					0x28
#define		GPIO_C_CTRL						0x29
#define		GPIO_C_INTS						0x2A


// Bank D
#define		GPIO_D_IN						0x30
#define		GPIO_D_OUT						0x31
#define		GPIO_D_IE						0x32
#define		GPIO_D_OE						0x33
#define		GPIO_D_DS						0x34
#define		GPIO_D_PU						0x35       
#define		GPIO_D_PD						0x36  

// Bank E
#define		GPIO_E_IN						0x40
#define		GPIO_E_OUT						0x41
#define		GPIO_E_IE						0x42
#define		GPIO_E_OE						0x43
#define		GPIO_E_DS						0x44
#define		GPIO_E_PU						0x45         
#define		GPIO_E_PD						0x46   


//////////////////////////////////////////////////////////
// Multiplex functions' IO index.
#define		GPIO_CFG0_REG					0x50
	// bit mask of GPIO_TYPE_REG  
	#define		MASK_FAST_UART_TO_A0A1CLR	(1 << 0) 	   //10, A[0] is fast uart_txdo	 A[1] is fast uart_rdxi
	#define		MASK_FAST_UART_TO_A0A1SET	(1 << 1) 	   
	#define		MASK_FAST_UART_TO_B0B1		(3 << 0)	   //11, B[0] is fast uart_txdo	 B[1] is fast uart_rdxi	
	#define		MASK_I51_UART_SEL			(1 << 2)		//

	                				
                                    	
#define		GPIO_CFG1_REG					0x51
	// bit mask of GPIO_CFG1_REG   	
	#define		MASK_SPI_SEL				(3 << 0)	
	#define		MASK_SD_TO_A5A4A3			(1 << 2)		//ѡ��A[5��3]��ΪSD�ӿ�	


//E2: ADC_CHANNEL_E2
#define SET_E2_ADC_IN()			ClrGpioRegBit(GPIO_E_OE, 0x04),\
								ClrGpioRegBit(GPIO_E_PU, 0x04),\
								SetGpioRegBit(GPIO_E_PD, 0x04)

//E3: ADC_CHANNEL_E3
#define SET_E3_ADC_IN()			ClrGpioRegBit(GPIO_E_OE, 0x08),\
								ClrGpioRegBit(GPIO_E_PU, 0x08),\
								SetGpioRegBit(GPIO_E_PD, 0x08)

//E4��Ϊ����adc�ţ�ORT����
#define SET_E4_ADC_IN()			ClrGpioRegBit(GPIO_E_OE, 0x10),\
								ClrGpioRegBit(GPIO_E_PU, 0x10),\
								SetGpioRegBit(GPIO_E_PD, 0x10)

//A0��Ϊ��ص���������adc�ţ�ORT����
#define SET_A0_ADC_IN()			ClrGpioRegBit(GPIO_A_OE, 0x01),\
								ClrGpioRegBit(GPIO_A_PU, 0x01),\
								SetGpioRegBit(GPIO_A_PD, 0x01)

//#ifdef ORT	
 
#define SET_GPIO_C1_INOUT()		SetGpioRegBit(GPIO_C_OE, 0x02),\
								SetGpioRegBit(GPIO_C_IE, 0x02),\
								ClrGpioRegBit(GPIO_C_PU, 0x02),\
								SetGpioRegBit(GPIO_C_PD, 0x02)
								
#define SET_GPIO_C2_IN()		ClrGpioRegBit(GPIO_C_OE, 0x04),\
								SetGpioRegBit(GPIO_C_IE, 0x04),\
								ClrGpioRegBit(GPIO_C_PU, 0x04),\
								SetGpioRegBit(GPIO_C_PD, 0x04)

	//ORT
	//GPIO_C1����Ϊ����Դ������Ϊ1ʱ���磬��Ϊ0ʱ�ϵ�
	#define POWERKEY_PORT_OE		GPIO_C_OE
	#define POWERKEY_PORT_OUT		GPIO_C_OUT	
	#define POWERKEY_PORT_MASK	(1<<1)
	#define POWERKEY_EN_OUT		SetGpioRegBit(POWERKEY_PORT_OE,POWERKEY_PORT_MASK);
	#define POWERKEY_SET			SetGpioRegBit(POWERKEY_PORT_OUT,POWERKEY_PORT_MASK);
	#define POWERKEY_CLR			ClrGpioRegBit(POWERKEY_PORT_OUT,POWERKEY_PORT_MASK);	//����ģʽ�²��ø�ǿ�ƶϵ緽ʽ

	#define POWERKEY_PORT_LED_CTRL_IE			GPIO_C_IE
	#define POWERKEY_PORT_LED_CTRL_IN		GPIO_C_IN
	#define POWERKEY_PORT_LED_CTRL_MASK		(1<<2)
	#define POWERKEY_PORT_LED_CTRL_IN_EN		SetGpioRegBit(POWERKEY_PORT_LED_CTRL_IE,POWERKEY_PORT_LED_CTRL_MASK);
	#define POWERKEY_PORT_LED_CTRL_GET		(GetGpioReg(POWERKEY_PORT_LED_CTRL_IN) & POWERKEY_PORT_LED_CTRL_MASK)
	

	//C0�ֵ�Ͳ���ƽ�	
	#define POWERKEY_PORT_LED_POW_OE		GPIO_C_OE
	#define POWERKEY_PORT_LED_POW_OUT		GPIO_C_OUT
	#define POWERKEY_PORT_LED_POW_MASK		(1<<0)

	#define POWERKEY_PORT_LED_POW_EN		SetGpioRegBit(POWERKEY_PORT_LED_POW_OE,POWERKEY_PORT_LED_POW_MASK);
	#define POWERKEY_PORT_LED_POW_SET		SetGpioRegBit(POWERKEY_PORT_LED_POW_OUT,POWERKEY_PORT_LED_POW_MASK);
	#define POWERKEY_PORT_LED_POW_CLR		ClrGpioRegBit(POWERKEY_PORT_LED_POW_OUT,POWERKEY_PORT_LED_POW_MASK);
	#define POWERKEY_PORT_LED_POW_GET		(GetGpioReg(POWERKEY_PORT_LED_POW_OUT) & POWERKEY_PORT_LED_POW_MASK)

	//ORT�汾�У�B1��Ϊ�������Ŀ��ƶ˿ڣ����
	#define PORT_BATTERY_CTRL_OE		GPIO_B_OE
	#define PORT_BATTERY_CTRL_OUT		GPIO_B_OUT
	#define PORT_BATTERY_CTRL_MASK	(1<<1)

	//��س��״̬���� B0
	#define BATTERY_CHARGING_PORT_IE				GPIO_B_IE
	#define BATTERY_CHARGING_PORT_IN				GPIO_B_IN
	#define BATTERY_CHARGING_PORT_MASK			(1 << 0)
	#ifdef CHARGTING_CHK_STATUS
		#define BATTERY_CHARGING_PORT_EN_IN			SetGpioRegBit(BATTERY_CHARGING_PORT_IE ,BATTERY_CHARGING_PORT_MASK); 
		#define GET_BATTERY_CHARGING_PORT_STATUS	(GetGpioReg(BATTERY_CHARGING_PORT_IN) & BATTERY_CHARGING_PORT_MASK)
	#else
		#define BATTERY_CHARGING_PORT_EN_IN			
		#define GET_BATTERY_CHARGING_PORT_STATUS	0
	#endif


#ifdef BATTERY_RESET_FLAG
	#define PORT_BATTERY_CTRL_OUT_EN 	SetGpioRegBit(PORT_BATTERY_CTRL_OE , PORT_BATTERY_CTRL_MASK);	
	#define PORT_BATTERY_CTRL_SET		SetGpioRegBit(PORT_BATTERY_CTRL_OUT , PORT_BATTERY_CTRL_MASK);
	#define PORT_BATTERY_CTRL_CLR		ClrGpioRegBit(PORT_BATTERY_CTRL_OUT , PORT_BATTERY_CTRL_MASK);
#else
	#define PORT_BATTERY_CTRL_OUT_EN 	
	#define PORT_BATTERY_CTRL_SET		
	#define PORT_BATTERY_CTRL_CLR
#endif

	/**************************LCD���Ʋ���*****************************/
	//#ifdef ORT
#define LCD_BK_LIGHT_MASK 	(1 << 0)
//#endif
#define LCD_PORT_OE			GPIO_D_OE
#define LCD_PORT_IN			GPIO_D_IN
#define LCD_PORT_OUT		GPIO_D_OUT
#define LCD_RES_MASK		(1 << 2)
#define LCD_SI_MASK			(1 << 3)
#define LCD_SCL_MASK		(1 << 4)
#define LCD_A0_MASK 		(1 << 5)
#define LCD_CE_MASK 		(1 << 6)
	//#ifdef ORT
	#define LCD_BKLIGHT_EN_OUT		SetGpioRegBit(LCD_PORT_OE,LCD_BK_LIGHT_MASK); 
	//#else
	//#define LCD_BKLIGHT_EN_OUT		//SDK��E0,E1��I2Cʹ��
	//#endif

	//#ifdef ORT �ߵ�ƽ��
	#define LCD_BKLIGHT_CLOSE		SetGpioRegBit(LCD_PORT_OUT,LCD_BK_LIGHT_MASK); 
	//#else
	//#define LCD_BKLIGHT_CLOSE		//SDK��E0,E1��I2Cʹ��
	//#endif

	//#ifdef ORT	�͵�ƽ��Ч
	#define LCD_BK_LIGHT_OPEN	(baGPIOCtrl[LCD_PORT_OUT] &= (~LCD_BK_LIGHT_MASK)); 
	#define GET_LCD_BK_LIGHT		(GetGpioReg(LCD_PORT_OUT) & LCD_BK_LIGHT_MASK)
	//#else
	//#define LCD_BK_LIGHT_OPEN
	//#endif
	/*******************************************************/

/////////SD BUS CONFIG/////////////////////////////////////////////////////
//A3:SD_DAT, A4:SD_CMD, A5:SD_CLK			
#define SET_A5A4A3_SD_BUS()		SetGpioRegBit(GPIO_CFG1_REG, MASK_SD_TO_A5A4A3)
//B4:MISO,B6:MOSI,B5:CLK
#define SET_B4B5B6_SPI_BUS()	SetGpioRegBit(GPIO_B_OE, 0x60),\
								ClrGpioRegBit(GPIO_B_OE, 0x10),\
								ClrGpioRegBit(GPIO_B_IE, 0x60),\
								SetGpioRegBit(GPIO_B_IE, 0x10),\
								SetGpioRegBit(GPIO_CFG1_REG, 0x02),\
								ClrGpioRegBit(GPIO_CFG1_REG, 0x01)
							
//sd bus disconnect to gpio			
#define SET_NO_SD_BUS()			ClrGpioRegBit(GPIO_CFG1_REG, MASK_SD_TO_A5A4A3)


//A[7:6]����ΪFM-IN(Analog Input)ģʽ.
#define SET_A6A7_FMIN()			ClrGpioRegBit(GPIO_A_OE, 0xC0),\
								SetGpioRegBit(GPIO_A_IE, 0xC0),\
								ClrGpioRegBit(GPIO_A_PU, 0xC0),\
								SetGpioRegBit(GPIO_A_PD, 0xC0)
//A[7:6]����Ϊ��ͨGPIO,Inputģʽ,ʹ���ڲ�����.
#define SET_A6A7_GPIO()			ClrGpioRegBit(GPIO_A_OE, 0xC0),\
								SetGpioRegBit(GPIO_A_IE, 0xC0),\
								ClrGpioRegBit(GPIO_A_PU, 0xC0),\
								ClrGpioRegBit(GPIO_A_PD, 0xC0)

//C[1:0]����ΪFM-IN(Analog Input)ģʽ.
#define SET_C0C1_FMIN()			ClrGpioRegBit(GPIO_C_OE, 0x03),\
								SetGpioRegBit(GPIO_C_IE, 0x03),\
								ClrGpioRegBit(GPIO_C_PU, 0x03),\
								SetGpioRegBit(GPIO_C_PD, 0x03)
//C[1:0]����Ϊ��ͨGPIO,Inputģʽ,ʹ���ڲ�����.
#define SET_C0C1_GPIO()			ClrGpioRegBit(GPIO_C_OE, 0x03),\
								SetGpioRegBit(GPIO_C_IE, 0x03),\
								ClrGpioRegBit(GPIO_C_PU, 0x03),\
								ClrGpioRegBit(GPIO_C_PD, 0x03)


// Set GPIO register value
VOID SetGpioReg(BYTE regIndex, BYTE val);

// Get GPIO register value
BYTE GetGpioReg(BYTE regIndex);

// Set GPIO register bit
VOID SetGpioRegBit(BYTE regIndex, BYTE mask);

// Clear gpio register bit
VOID ClrGpioRegBit(BYTE regIndex, BYTE mask);


#endif
