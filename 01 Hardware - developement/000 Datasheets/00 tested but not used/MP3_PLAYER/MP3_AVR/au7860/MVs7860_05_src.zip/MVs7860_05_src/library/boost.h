#ifndef _BOOST_H_
#define	_BOOST_H_


//Enable Boost
//E4 use as BOOST-PIN
VOID BoostEnable();

//Disable Boost
VOID BoostDisable();


#endif
