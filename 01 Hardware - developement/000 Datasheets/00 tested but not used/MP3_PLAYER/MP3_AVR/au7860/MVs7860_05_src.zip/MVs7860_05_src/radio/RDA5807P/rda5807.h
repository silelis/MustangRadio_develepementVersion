
/*
*****************************************************************************
*					Mountain View Silicon Tech. Inc.
*	Copyright 2007, Mountain View Silicon Tech. Inc., ShangHai, China
*					All rights reserved.
*
* Filename:			
* Description:		
*
* Change History:
*			tom.tong	- 03/01/2012
*						- created

******************************************************************************
*/
#ifndef __RDA5807_H__
#define __RDA5807_H__



/*
**********************************************************
*					GLOBAL VARIABLE
**********************************************************
*/

extern BOOL RDA5807P_ReadID();
extern VOID RDA5807P_Init(VOID);	
extern VOID RDA5807P_Mute( BOOL MuteFg);
extern VOID RDA5807P_PowerDownEn();
extern VOID RDA5807P_PowerDownDis();
extern VOID RDA5807P_FreqSet(WORD Freq);
extern BYTE RDA5807P_SeekResultGet( VOID );//BYTE RDA5807P_SeekResultGet(WORD* pFreq);


#endif

