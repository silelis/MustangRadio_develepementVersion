#ifndef _SPI_FLASH_UPDATA_H_
#define	_SPI_FLASH_UPDATA_H_

extern BOOL gIsMVFFileFind;
extern FILE gUpdataFile;


VOID DownloadMVFToFsh();

#endif

