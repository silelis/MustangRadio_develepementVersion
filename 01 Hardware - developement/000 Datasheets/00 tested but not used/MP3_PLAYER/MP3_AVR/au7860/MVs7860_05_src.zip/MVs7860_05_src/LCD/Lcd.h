/*
********************************************************************************
*                   Copyright (c) 2010,ZhangXiaoYong
*                         All rights reserved.
*
* File Name��   Lcd.h
* 
* Description:  ��ʾ�ӿ�
*
* History:      <author>          <time>        <version>       
*             ZhangXiaoYong      2010-03-12          1.0
*    desc:    ORG.
********************************************************************************
*/

#ifndef _LCD_H_
#define _LCD_H_


typedef struct{
	unsigned char x;
	unsigned char y;
	unsigned char w;
	unsigned char h;
}WINDOWS;

extern void write_data(bit direction, unsigned char trans_data);
extern void lcd_init(void);
extern void Lcd_ClearScreen(WINDOWS win);
extern void Lcd_Update_Win(char *buffer, WINDOWS win,bit mode);
extern void Lcd_SetContrast(char n);
extern void lcd_off(void);

/*
********************************************************************************
*
*                         End of Lcd.h
*
********************************************************************************
*/
#endif
