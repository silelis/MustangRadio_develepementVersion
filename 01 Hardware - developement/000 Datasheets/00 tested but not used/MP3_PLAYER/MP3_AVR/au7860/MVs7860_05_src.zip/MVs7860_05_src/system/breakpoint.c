#include "syscfg.h"
#include "playctrl.h"
#include "breakpoint.h"
#include "sysctrl.h"
#include "24Cxx.h"

extern PLAY_CTRL gPlayCtrl;

#ifdef FUNC_BREAK_POINT_EN
		
// Save the break point information.
BP_INFO		gBreakPointInfo;

static BP_INFO CODE s_InitBreakPointData =
{	
	BP_SIGNATURE, 				//Signature

#ifdef IDLE_MODE_EN		
	SYS_MODE_IDLE,		//Ϊʡ�磬����IDLEģʽ
#else
	SYS_MODE_USB,				//SystemMode
#endif							
//	0x0000,						//USB_DeviceID
	0,							//USB_FolderSum
	0,							//USB_FileSum
	1,							//USB_CurFolderNum
	1,							//USB_CurFileNum
	0,							//USB_CurPlayTime
	
	//"        ",					//USB_FileName

//	0x0000,						//SD_DeviceID
	0,							//SD_FolderSum
	0,							//SD_FileSum
	1,							//SD_CurFolderNum
	1,							//SD_CurFileNum
	0,							//SD_CurPlayTime
	
	//"        ",					//SD_FileName

	//0,

	VOLUME_INIT,					//Volume
	0,							//Eq
	PLAY_MODE_REPEAT_ALL,		//Mode
};


//#ifdef FUNC_UARTDBG_EN
//static VOID BP_InfoDisplay()
//{
//	DBG(("**********************************\n"));
//	DBG(("*  Signature:%X\n", (WORD)gBreakPointInfo.Signature));		
//	DBG(("*\n"));	
//	DBG(("*  USB_Signature:%X\n", (WORD)gBreakPointInfo.USB_Signature));		
//	DBG(("*  USB_CurFolderNum:%d\n", (WORD)gBreakPointInfo.USB_CurFolderNum));
//	DBG(("*  USB_CurFileNum:%d\n", (WORD)gBreakPointInfo.USB_CurFileNum));
//	DBG(("*  USB_CurPlayTime:%ld\n", (DWORD)gBreakPointInfo.USB_CurPlayTime));
//	DBG(("*  USB_FolderSum:%ld\n", (DWORD)gBreakPointInfo.USB_FolderSum));
//	DBG(("*  USB_FileSum:%ld\n", (DWORD)gBreakPointInfo.USB_FileSum));
//	DBG(("*  USB_FileSum:%-.8s.MP3\n", (DWORD)gBreakPointInfo.USB_FileName));
//	
//
//	DBG(("*\n"));	
//	DBG(("*  SD_Signature:%X\n", (WORD)gBreakPointInfo.SD_Signature));		
//	DBG(("*  SD_CurFolderNum:%d\n", (WORD)gBreakPointInfo.SD_CurFolderNum));
//	DBG(("*  SD_CurFileNum:%d\n", (WORD)gBreakPointInfo.SD_CurFileNum));
//	DBG(("*  SD_CurPlayTime:%ld\n", (DWORD)gBreakPointInfo.SD_CurPlayTime));
//	DBG(("*  SD_FolderSum:%ld\n", (DWORD)gBreakPointInfo.SD_FolderSum));
//	DBG(("*  SD_FileSum:%ld\n", (DWORD)gBreakPointInfo.SD_FileSum));
//	DBG(("*  SD_FileName:%-.8s.MP3\n", gBreakPointInfo.SD_FileName));
//	DBG(("*\n"));	
//	DBG(("*  SystemMode:%d\n", (WORD)gBreakPointInfo.SystemMode));
//	DBG(("*\n"));	
//	DBG(("*  Volume:%d\n", (WORD)gBreakPointInfo.Volume));
//	DBG(("*  Eq:%d\n", (WORD)gBreakPointInfo.Eq));
//	DBG(("*  Mode:%d\n", (WORD)gBreakPointInfo.RepeatMode));
//	DBG(("**********************************\n"));
//}
//#endif


// Load break point information from EEPROM
VOID BP_LoadInfo()
{
	//BP_InfoDisplay();
	
	gBreakPointInfo.Signature = EEPROM_ReadByte( EEP_ADR_BP_SIGNATURE );
	if(gBreakPointInfo.Signature != BP_SIGNATURE)
	{
		DBG(("Break point information is invalid!\n"));
		memcpy(&gBreakPointInfo, &s_InitBreakPointData, sizeof(BP_INFO));
		//BP_InfoDisplay();
		return ;
	}
	DBG(("Break point information is OK!\n"));
	if(gBreakPointInfo.USB_CurFileNum == 0)
	{
		gBreakPointInfo.USB_CurPlayTime = 0;
	}
	
	if(gBreakPointInfo.SD_CurFileNum == 0)
	{
		gBreakPointInfo.SD_CurPlayTime = 0;
	}

	//if(  SYS_MODE_USB == EEPROM_ReadByte( (BYTE)EEP_ADR_SYSTEMMODE  ) )
	{
		gBreakPointInfo.USB_CurFileNum   = EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FILENUM_MSB )<<8 ;
		gBreakPointInfo.USB_CurFileNum += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FILENUM_LSB );	
		
		gBreakPointInfo.USB_CurPlayTime = EEPROM_ReadByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_3 )<<24 ;
		gBreakPointInfo.USB_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_2 )<<16 ;
		gBreakPointInfo.USB_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_1 )<<8 ;
		gBreakPointInfo.USB_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_0 ) ;

		gBreakPointInfo.USB_FolderSum   = EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FOLDERSUM_MSB )<<8 ;
		gBreakPointInfo.USB_FolderSum += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FOLDERSUM_LSB );	
		gBreakPointInfo.USB_FileSum =  EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FILESUM_MSB )<<8;
		gBreakPointInfo.USB_FileSum += EEPROM_ReadByte( (BYTE)EEP_ADR_USB_FILESUM_LSB );
		DBG(("LoadBreak   gBreakPointInfo.USB_FolderSum = %d!\n" , gBreakPointInfo.USB_FolderSum));
		DBG(("LoadBreak   gBreakPointInfo.USB_FileSum = %d!\n" , gBreakPointInfo.USB_FileSum ));
	}
	//else if(  SYS_MODE_SD == EEPROM_ReadByte( (BYTE)EEP_ADR_SYSTEMMODE  ) )
	{
		gBreakPointInfo.SD_CurFileNum   = EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FILENUM_MSB )<<8 ;
		gBreakPointInfo.SD_CurFileNum += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FILENUM_LSB );	

		gBreakPointInfo.SD_CurPlayTime = EEPROM_ReadByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_3 )<<24 ;
		gBreakPointInfo.SD_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_2 )<<16 ;
		gBreakPointInfo.SD_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_1 )<<8 ;
		gBreakPointInfo.SD_CurPlayTime += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_0 ) ;
		
		gBreakPointInfo.SD_FolderSum   = EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FOLDERSUM_MSB )<<8 ;
		gBreakPointInfo.SD_FolderSum += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FOLDERSUM_LSB );	
		gBreakPointInfo.SD_FileSum =  EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FILESUM_MSB )<<8;
		gBreakPointInfo.SD_FileSum += EEPROM_ReadByte( (BYTE)EEP_ADR_SD_FILESUM_LSB );
		DBG(("LoadBreak   gBreakPointInfo.SD_FolderSum = %d!\n" , gBreakPointInfo.SD_FolderSum));
		DBG(("LoadBreak   gBreakPointInfo.SD_FileSum = %d!\n" , gBreakPointInfo.SD_FileSum ));
	}

	gBreakPointInfo.Volume = EEPROM_ReadByte( (BYTE)EEP_ADR_VOLUME );
	if( ( VOLUME_MAX < gBreakPointInfo.Volume ) || ( VOLUME_MIN > gBreakPointInfo.Volume ) )
	{
		//��ƬʱEEPROMΪ�գ����������쳣
		gBreakPointInfo.Volume = VOLUME_INIT ;
	}
	gBreakPointInfo.Eq = 0;	//EEPROM_ReadByte( (BYTE)EEP_ADR_EQ );
	gBreakPointInfo.SystemMode = EEPROM_ReadByte( (BYTE)EEP_ADR_SYSTEMMODE );
	gBreakPointInfo.RepeatMode = PLAY_MODE_REPEAT_ALL ;
	DBG(("LoadBreak   gBreakPointInfo.Volume = %d!\n" , (short)gBreakPointInfo.Volume));			
	DBG(("LoadBreak   gBreakPointInfo.Eq = %d!\n" , (short)gBreakPointInfo.Eq));
	DBG(("LoadBreak   gBreakPointInfo.SystemMode = %d!\n" , (short)gBreakPointInfo.SystemMode));
	
}


// Save break point information to EEPROM
//�ú�����Ҫ������Ϊ����Ƶ�����µ���Ϣ�������������б���
VOID BP_SaveInfo()
{
//	DBG(("*****BP_SaveInfo()*****\n"));
	gBreakPointInfo.Signature = BP_SIGNATURE;
	gBreakPointInfo.SystemMode = gSys.SystemMode;

	EEPROM_WriteByte( (BYTE)EEP_ADR_BP_SIGNATURE , (BYTE)gBreakPointInfo.Signature);
	EEPROM_WriteByte( (BYTE)EEP_ADR_SYSTEMMODE, (BYTE)gBreakPointInfo.SystemMode);
	
	if( gSys.SystemMode == SYS_MODE_USB )
	{
//		DBG(("DEV_CNCT_MAP_USB\n"));
//		gBreakPointInfo.USB_Signature = gFsInfo.DevSignature;
#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.USB_CurFolderNum = gPlayCtrl.FolderNum;
#endif

		gBreakPointInfo.USB_CurFileNum = gPlayCtrl.FileNum;
		gBreakPointInfo.USB_CurPlayTime = gSongInfo.CurPlayTime;

#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.USB_FolderSum = gFsInfo.ValidFolderSum;
#endif
		gBreakPointInfo.USB_FileSum = gFsInfo.FileSum;
		//memcpy(&gBreakPointInfo.USB_FileName[0], &gPlayCtrl.File.ShortName[0], 8);

		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERSUM_MSB , (BYTE)(gBreakPointInfo.USB_FolderSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERSUM_LSB , (BYTE)(gBreakPointInfo.USB_FolderSum));	
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILESUM_MSB , (BYTE)(gBreakPointInfo.USB_FileSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILESUM_LSB , (BYTE)(gBreakPointInfo.USB_FileSum));	
		
	}
	else if(gSys.SystemMode == SYS_MODE_SD)
	{
//		DBG(("DEV_CNCT_MAP_SD\n"));
//		gBreakPointInfo.SD_Signature = gFsInfo.DevSignature;
#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.SD_CurFolderNum = gPlayCtrl.FolderNum;
#endif

		gBreakPointInfo.SD_CurFileNum = gPlayCtrl.FileNum;	
		gBreakPointInfo.SD_CurPlayTime = gSongInfo.CurPlayTime;

#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.SD_FolderSum = gFsInfo.ValidFolderSum;
#endif

		gBreakPointInfo.SD_FileSum = gFsInfo.FileSum;
//		memcpy(&gBreakPointInfo.SD_FileName[0], &gPlayCtrl.File.ShortName[0], 8);


		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERSUM_MSB , (BYTE)(gBreakPointInfo.SD_FolderSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERSUM_LSB , (BYTE)(gBreakPointInfo.SD_FolderSum));	
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILESUM_MSB , (BYTE)(gBreakPointInfo.SD_FileSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILESUM_LSB , (BYTE)(gBreakPointInfo.SD_FileSum));
		
	}
	gBreakPointInfo.Volume = gSys.Volume;
	gBreakPointInfo.Eq = gPlayCtrl.Eq;
	gBreakPointInfo.RepeatMode = gPlayCtrl.RepeatMode;

	EEPROM_WriteByte( (BYTE)EEP_ADR_VOLUME , (BYTE)gBreakPointInfo.Volume);
	EEPROM_WriteByte( (BYTE)EEP_ADR_EQ, (BYTE)gBreakPointInfo.Eq);
	EEPROM_WriteByte( (BYTE)EEP_ADR_REPEATMODE, (BYTE)gBreakPointInfo.RepeatMode);
}

//����������Ϣ
VOID BP_SaveVolumeInfo()
{
	gBreakPointInfo.Volume = gSys.Volume;
	

	EEPROM_WriteByte( (BYTE)EEP_ADR_VOLUME , (BYTE)gBreakPointInfo.Volume);
	
}

#ifdef FUNC_FOLDER_EN
WORD BP_GetCurFolderNum()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_CurFolderNum;
	}
	else if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{
		return gBreakPointInfo.SD_CurFolderNum;
	}
	else	
	{
		return 0;				
	} 
}
#endif


WORD BP_GetCurFileNum()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_CurFileNum;
	}
	else //if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{				
		return gBreakPointInfo.SD_CurFileNum;
	}
//	else
//	{
//	 	return 0;
//	}
}


DWORD BP_GetCurPlayTime()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_CurPlayTime;
	}
	else //if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{			
		return gBreakPointInfo.SD_CurPlayTime;
	}
//	else
//	{
//	 	return 0;
//	}
}

//#ifdef FUNC_FOLDER_EN
WORD BP_GetFolderSum()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_FolderSum;
	}
	else if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{				
		return gBreakPointInfo.SD_FolderSum;
	}
	else
	{
	 	return 0;
	}
}
//#endif

WORD BP_GetFileSum()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_FileSum;
	}
	else //if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{			
		return gBreakPointInfo.SD_FileSum;
	}
//	else
//	{
//	 	return 0;
//	}
}

#if 0		//lxl comment for reduce target size
BYTE* BP_GetFileName()
{
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		return gBreakPointInfo.USB_FileName;
	}
	else //if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{			
		return gBreakPointInfo.SD_FileName;
	}
//	else
//	{
//	 	return NULL;
//	}
}
#endif
//���2402C���ݣ�ģ���������Ӻ��һ���������
void BP_SaveNULLBK()
{
	EEPROM_WriteByte( (BYTE)0, (BYTE)0);
}

BYTE BP_GetSystemMode()
{
	return gBreakPointInfo.SystemMode;
}

void BP_SaveSystemMode()
{
	gBreakPointInfo.Signature = BP_SIGNATURE;
	EEPROM_WriteByte( (BYTE)EEP_ADR_BP_SIGNATURE , (BYTE)gBreakPointInfo.Signature);
	
	gBreakPointInfo.SystemMode = gSys.SystemMode;
	EEPROM_WriteByte( (BYTE)EEP_ADR_SYSTEMMODE, (BYTE)gBreakPointInfo.SystemMode);
}

//���沥���ļ�����Ϣ������Ŀ¼��ţ��ļ����
void BP_SaveFileNO()
{
	WORD	CurFolderNum ,  CurFileNum ;
	
	CurFolderNum = gPlayCtrl.FolderNum ;
	CurFileNum = 	gPlayCtrl.FileNum ;
	
	if( gSys.SystemMode == SYS_MODE_USB )
	{
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERNUM_MSB, (BYTE)(CurFolderNum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERNUM_LSB, (BYTE)(CurFolderNum));
		gBreakPointInfo.USB_CurFolderNum = gPlayCtrl.FolderNum ;
			
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILENUM_MSB, (BYTE)(CurFileNum>>8) );
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILENUM_LSB, (BYTE)(CurFileNum) );
		gBreakPointInfo.USB_CurFileNum =	gPlayCtrl.FileNum ;
	}
	else
	{
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERNUM_MSB, (BYTE)(CurFolderNum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERNUM_LSB, (BYTE)(CurFolderNum));
		gBreakPointInfo.SD_CurFolderNum = gPlayCtrl.FolderNum ;
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILENUM_MSB, (BYTE)(CurFileNum>>8) );
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILENUM_LSB, (BYTE)(CurFileNum) );
		gBreakPointInfo.SD_CurFileNum = gPlayCtrl.FileNum ;
	}
}

//�����ļ�Ŀ¼��Ϣ,�ļ�������Ϣ
VOID BP_SaveFolderInfo()
{
	
	if( gSys.SystemMode == SYS_MODE_USB )
	{
//#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.USB_FolderSum = gFsInfo.ValidFolderSum;
//#endif
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERSUM_MSB , (BYTE)(gFsInfo.ValidFolderSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FOLDERSUM_LSB , (BYTE)(gFsInfo.ValidFolderSum));	

		gBreakPointInfo.USB_FileSum = gFsInfo.FileSum;
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILESUM_MSB , (BYTE)(gBreakPointInfo.USB_FileSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_FILESUM_LSB , (BYTE)(gBreakPointInfo.USB_FileSum));
	}
	else if(gSys.SystemMode == SYS_MODE_SD)
	{
//#ifdef	FUNC_FOLDER_EN
		gBreakPointInfo.SD_FolderSum = gFsInfo.ValidFolderSum;
//#endif
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERSUM_MSB , (BYTE)(gFsInfo.ValidFolderSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FOLDERSUM_LSB , (BYTE)(gFsInfo.ValidFolderSum));

		gBreakPointInfo.SD_FileSum = gFsInfo.FileSum;
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILESUM_MSB , (BYTE)(gBreakPointInfo.SD_FileSum>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_FILESUM_LSB , (BYTE)(gBreakPointInfo.SD_FileSum));
	}
	
}

//���浱ǰ����ʱ���
DWORD BP_SaveCurPlayTime()
{
	DWORD CurPlayTime = gSongInfo.CurPlayTime ;
	if(gSys.SystemMode == SYS_MODE_USB)			//USB
	{
		gBreakPointInfo.USB_CurPlayTime = CurPlayTime;
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_3, (BYTE)(CurPlayTime>>24));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_2, (BYTE)(CurPlayTime>>16));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_1, (BYTE)(CurPlayTime>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_USB_CURPLAYTIME_0, (BYTE)(CurPlayTime));
	}
	else //if(gSys.SystemMode == SYS_MODE_SD)		//SD 
	{			
		gBreakPointInfo.SD_CurPlayTime = CurPlayTime;
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_3, (BYTE)(CurPlayTime>>24));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_2, (BYTE)(CurPlayTime>>16));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_1, (BYTE)(CurPlayTime>>8));
		EEPROM_WriteByte( (BYTE)EEP_ADR_SD_CURPLAYTIME_0, (BYTE)(CurPlayTime));
	}
//	else
//	{
//	 	return 0;
//	}
}
//WORD BP_GetDevSignature()
//{
//	if(gSys.SystemMode == SYS_MODE_USB)			//USB
//	{
//		return gBreakPointInfo.USB_Signature;
//	}
//	else if(gSys.SystemMode == SYS_MODE_SD)		//SD 
//	{			
//		return gBreakPointInfo.SD_Signature;
//	}
//	else
//	{
//	 	return 0;
//	}
//}

#endif