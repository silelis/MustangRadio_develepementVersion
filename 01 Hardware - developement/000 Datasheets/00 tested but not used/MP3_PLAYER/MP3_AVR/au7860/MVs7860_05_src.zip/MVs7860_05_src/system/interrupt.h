#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_


// Interrupts control initialize operation.
VOID ExInt1Init();

VOID Timer1_CountSet(BYTE div);

VOID Timer1_Init();


#endif
