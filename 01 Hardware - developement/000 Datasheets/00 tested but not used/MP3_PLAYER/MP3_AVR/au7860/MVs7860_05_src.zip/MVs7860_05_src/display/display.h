#ifndef _DISPLAY_H_
#define _DISPLAY_H_


VOID DispInit();


#endif
