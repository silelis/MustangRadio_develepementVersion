#include "syscfg.h"
#include "sysctrl.h"
#include "playctrl.h"
#include "breakpoint.h"
#include "browser_ctrl.h"
#include "gui.h"
#include "key.h"


//���ż��Ӷ�ʱ��
#define PLAY_WATCH_TIME				10000
static TIMER	s_PlayWatchTimer;

static TIMER 	VolumeUpTimer;
//static BOOL 	IsFastPlayResume;
static BOOL 	IsVolumeUpEnd;							//jack_090905, for code size
static BYTE	IsActed = 0 ;						//�����жϱ�־,�ж��Ƿ񰴼������豸��ζ���

//�����и趨ʱ��
#ifdef FUNC_OPEN_FILE_DELAY_EN
#define	OPEN_FILE_DELAY_TIME		500
static TIMER	s_OpenFileDelayTimer;
static BOOL		s_IsOpenFileDelay;
#endif

BYTE 	Status_DisVol = 0 ;					//0 ��ʾδ��ʾ����ͼ��1�෴,��ʾ����ͼ��ʱ,�������ʵȲ���ʾ
											//??�迼�Ǻ� ��������ʾ��ͻ


//�޲���ϵͳ���߶�ʱ��
TIMER	s_SleepTimer;
//#define 		OUTTIME_SLEEPTIMER	(300000)		//5���Ӳ�����������

//���ż�ʱ��ʱ��
DWORD 	g_StartPlayTime;
TIMER	g_PlayTimer;
DWORD 	g_OldPlayTime = -1;


PLAY_CTRL 		gPlayCtrl;
BOOL	s_BreakPointFlag;

#ifdef FUNC_REPEAT_AB_EN
//IDLE״̬�£���һ��REPEAT_AB������¼��A��ʱ�䣬����SET״̬
//SET״̬�£���һ��REPEAT_AB������¼��B��ʱ�䣬����PLAY״̬
//           ��������ת��Aʱ��㲥�ţ��˺�ʼ����Aʱ��㵽Bʱ���֮�䷴������
//PLAY״̬�£���һ��REPEAT_AB��������IDLE״̬
//ÿ�׸�����ʼ����ʱ���ὫAB����״̬����ΪIDLE
#define	REPEAT_AB_STATE_IDLE	0
#define	REPEAT_AB_STATE_SET		1
#define	REPEAT_AB_STATE_PLAY	2

BYTE s_RepeatAB_State;
DWORD s_RepeatAB_SecondsA;
DWORD s_RepeatAB_SecondsB;

#endif


//�����ܵ�EQ������Ŀ
//�û��ɸ�����Ҫ������ʵ��ʹ�õ�EQ����
#define 	DECD_EQ_SUM				11
	
//����ÿ��EQ������
#define		DECD_EQ_NORMAL			0
#define		DECD_EQ_ROCK			1
#define		DECD_EQ_POP				2
#define		DECD_EQ_CLASSIC			3
#define		DECD_EQ_JASS			4		
#define		DECD_EQ_BLUE			5
#define		DECD_EQ_HALL			6
#define		DECD_EQ_BASS			7
#define		DECD_EQ_SOFT			8
#define		DECD_EQ_COUNTRY			9
#define		DECD_EQ_OPERA			10
	

//EQ���飬��10���ֶΣ�ÿ���ֶε�Ƶ�ʷ�Χ�ֱ��ǣ�
//20HZ-680HZ,		680HZ-1.3KHZ,	1.3KHZ-2.1KHZ,	2.1KHZ-2.8KHZ,	2.8KHZ-3.5KHZ,
//3.5KHZ-4.1KHZ,	4.1KHZ-5.5KHZ,	5.5KHZ-8.3KHZ,	8.3KHZ-13.7KHZ,	13.7KHZ-22.0KHZ
//ÿ���ֶ���һ���ֽھ�����Ƶ���ڵ�˥�����ȣ�-9��+3����ʾ-9dB��+3dB
BYTE CODE gDecdEQ[][EQ_BANDS_NUM] = 
{
	{ 0,	 0,		 0,		 0,		 0,		 0,		 0,		 0,  	 0, 	 0	},	//normal
	{ 2,	-6,		-4,		-3,		-2,		-4,		-6,		-6,		 2,		 2	},	//ROCK			
	{-1,	 2,		-1,		-3,		-6,		-6,		-6,		-3,		-1,		 2	},	//POP			
	{ 2,	-1,		-1,		 0,		 2,		 2,		 2,		 2,		-3,		-6	},	//classic			
	{-6,	-1,		 2,		 0,		-1,		 0,		 2,		 2,		 1,		-1	},	//JAZZ			
	{-2,	-6,		-2,		-2,		-2,		-4,		-6,		-2,		 2,		-2	},	//blue		
	{ 2,	-1,		-1,		-3,		-6,		-6,		-6,		-6,		 2,		 2	},	//hall 	  		
	{ 2,	 1,		 1,		-1,		-2,		-2,		-2,		-3,		-3,		-3	},	//bass		
	{-6,	-6,		-1,		 1,		 2,		 2,		 2,		 2,		 2,		-1	},	//soft		
	{-3,	 2,		 2,		 2,		 2,		 2,		 2,		-3,		 2,		 2	},	//country 	  		
	{-1,	-6,		-1,		 2,		 2,		 2,		 2,		 2,		 2,		 2	},	//opera
};


// Volume table in dB set.
WORD CODE gVolArr[VOLUME_MAX + 1] =
{
	0,
	26,		31,		36,		42,		49,		58,		67,		78,		
	91,		107,	125,	147,	173,	204,	240,	282,	
	332,	391,	460,	541,	636,	748,	880,	1035,	
	1218,	1433,	1686,	1984,	2334,	2746,	3230,	3800//�������Լ930mVrms
};


VOID DisplayPlayInfo();
VOID ShowSongInfo(VOID);

///////////////////////���ż�ʱ��غ���////////////////////////////////////////////////////////
//��ʼʹ�ö�ʱ����ʱ
VOID SongPlayTimeStart()
{
	TimeOutSet(&g_PlayTimer, 0);
	g_StartPlayTime = gSongInfo.CurPlayTime*1000;
	g_OldPlayTime = -1;
}

//��ͣ��ʱ����ʱ
VOID SongPlayTimePause()
{
	g_StartPlayTime += PastTimeGet(&g_PlayTimer);
	TimeOutSet(&g_PlayTimer, 0);
	g_OldPlayTime = -1;
}

//�ָ���ʱ����ʱ
VOID SongPlayTimeResume()
{
	TimeOutSet(&g_PlayTimer, 0);
	g_OldPlayTime = -1;
}


//���²���ʱ��
//����ʱ���ɱ�ģ���ʱ�������ǽ����µ�������Ϣ�ṹ����
//���������ʱ����decoder�ײ��ʱ
VOID SongPlayTimeUpdate()			
{
	DWORD CurPlayTime;

	if(gPlayCtrl.State == PLAY_STATE_PLAY)
	{
		CurPlayTime = (g_StartPlayTime + PastTimeGet(&g_PlayTimer))/1000;
		gSongInfo.CurPlayTime = CurPlayTime; 
	}

	if(gSongInfo.CurPlayTime != g_OldPlayTime)
	{
		g_OldPlayTime = gSongInfo.CurPlayTime;
		//���浱ǰ����ʱ���
		BP_SaveCurPlayTime();	
		DBG1(("gSongInfo.CurPlayTime = %lu  \n" , gSongInfo.CurPlayTime ));
		if(( 1 != Status_DisVol ) && ( !gPlayCtrl.LrcFlag) && ( PLAY_STATE_PLAY == gPlayCtrl.State )  )
		{
			ShowPlayTotaltime(gSongInfo.CurPlayTime );	
		}
		if((gPlayCtrl.State == PLAY_STATE_PLAY)
		|| (gPlayCtrl.State == PLAY_STATE_FF)
		|| (gPlayCtrl.State == PLAY_STATE_FB))
		{
			DisplayPlayInfo();
#ifdef FUNC_BREAK_POINT_EN

		//�˴��ᵼ�²��Ÿ������ļ�ʱ���ֿ���
		//BP_SaveInfo(); //δ����ϵ���Ϣ,Ӧ�ñ���,�ұ����ϴβ��Ÿ���

		//���沥��ʱ����Ϣ,�ļ�����ʱ������ϢӦ��0
		//??????????????????????????????????
		
#endif
		}
	}	
}


#ifdef FUNC_UARTDBG_EN
//��������ǰ����ʾ������Ϣ
VOID DisplaySongInfo()
{
	BYTE CODE* CODE Str_MpegVersion[] = {"2.5", "UNKNOWN", "2", "1"};
	BYTE CODE* CODE Str_Layer[] = {"UNKNOWN", "3", "2", "1"};

#ifdef FUNC_LONG_NAME_EN
	{
		BYTE LongFileName[66];	 
		BOOL Ret;
		WORD* p;
	
		//Ret = FileGetLongName(&gPlayCtrl.File, LongFileName);
#if 0		
		ShowFileName( gPlayCtrl.File.ShortName);
		ShowFileName( LongFileName);
		ShowPlayTotaltime(gSongInfo.TotalPlayTime );
#endif		
		DBG(("%d\n", (WORD)Ret));
		for(p = (WORD*)LongFileName; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));
	}
#endif

#ifdef FUNC_LRC_EN
	if(gPlayCtrl.LrcFlag)
	{
		DBG(("Find a LRC file!\n"));
	}
	else
	{
		DBG(("No suited LRC file!\n"));
	}
#endif

#ifdef FUNC_TAG_EN
	//��ʾTAG��Ϣ
	DBG(("\n"));
	if(gTagInfo.TagType == TAG_ID3V1)
	{
		DBG(("********ID3V1***************\n"));
	}
	else if(gTagInfo.TagType == TAG_ID3V2)
	{
		DBG(("********ID3V2***************\n"));
	}
	else if(gTagInfo.TagType == TAG_WMA)
	{
		DBG(("*********WMA****************\n"));
	}
	else
	{
		DBG(("******No TAG info!**********\n"));
	}

	if((gTagInfo.TagCharSet == CHAR_SET_UTF_16) || (gTagInfo.TagCharSet == CHAR_SET_UTF_8))
	{
		WORD* p;

		//SDK�в�֧��UTF-16��UTF-8�ַ���
		DBG(("UTF-16 OR UTF-8\n"));

		DBG(("Title: "));
		for(p = (WORD*)gTagInfo.Title; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));

		DBG(("Artist: "));
		for(p = (WORD*)gTagInfo.Artist; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));

		DBG(("Album: "));
		for(p = (WORD*)gTagInfo.Album; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));

		DBG(("Comment: "));
		for(p = (WORD*)gTagInfo.Comment; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));

		DBG(("Year: "));
		for(p = (WORD*)gTagInfo.Year; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));
	}
	else if(gTagInfo.TagCharSet == CHAR_SET_ISO_8859_1)
	{
	 	DBG(("ISO-8859-1\n"));
		DBG(("Title: %s\n", gTagInfo.Title));
		DBG(("Artist: %s\n", gTagInfo.Artist));
		DBG(("Album: %s\n", gTagInfo.Album));
		DBG(("Comment: %s\n", gTagInfo.Comment));
		DBG(("Year: %s\n", gTagInfo.Year));
	}
	else
	{
		DBG(("Unkown char set!\n"));
	}

	DBG(("****************************\n"));
	DBG(("\n"));
#endif

	DBG(("********SONG INFO*************\n"));
	//��ӡ������Ϣ
	switch(gSongInfo.SongType)
	{
		case SONG_TYPE_MP3:
			DBG(("SongType: MP3\n"));
			break;

		case SONG_TYPE_WMA:
			DBG(("SongType: WMA\n"));
			break;

		case SONG_TYPE_PCM_1CH:
			DBG(("SongType: PCM_1CH\n"));
			break;

		case SONG_TYPE_PCM_2CH:
			DBG(("SongType: PCM_2CH\n"));
			break;

		case SONG_TYPE_IMA_ADPCM:
			DBG(("SongType: ADPCM\n"));
			break;

		default:
			DBG(("SongType: UNKOWN\n"));
			break;
	}
	
	DBG(("ChannelNum:       %u\n", (WORD)gSongInfo.ChannelNum));
	DBG(("SamplesPerSecond: %u\n", (WORD)gSongInfo.SamplesPerSecond));
	//kbps = (BytesPerSecond*8)/1000 = BytesPerSecond/125
	DBG(("BytesPerSecond:   %lu (%lukbps)\n", (DWORD)gSongInfo.BytesPerSecond, (DWORD)(gSongInfo.BytesPerSecond/(1000/8))));
	DBG(("TotalPlayTime:    %lu\n", (DWORD)gSongInfo.TotalPlayTime));
	DBG(("CurPlayTime:      %lu\n", (DWORD)gSongInfo.CurPlayTime));
	DBG(("FrameLen:         %lu\n", (DWORD)gSongInfo.FrameLen));
	DBG(("FrameNum:         %lu\n", (DWORD)gSongInfo.FrameNum));	
	DBG(("FileHeaderLen:    %lu\n", (DWORD)gSongInfo.FileHeaderLen));
	DBG(("IsVBR:            %u\n", (WORD)gSongInfo.IsVBR));
	DBG(("Mp3MpegVersion:   %s\n", Str_MpegVersion[gSongInfo.Mp3MpegVersion]));
	DBG(("Mp3Layer:         %s\n", Str_Layer[gSongInfo.Mp3Layer]));
	
	DBG(("****************************\n"));
	DBG(("\n"));		
}
#endif

VOID ShowSongInfo(VOID)
{
	//BYTE CODE* CODE Str_MpegVersion[] = {"2.5", "UNKNOWN", "2", "1"};
	//BYTE CODE* CODE Str_Layer[] = {"UNKNOWN", "3", "2", "1"};

#ifdef FUNC_LONG_NAME_EN
	{
		BYTE LongFileName[66];	 
		BOOL Ret;
		WORD* p;
	
		//Ret = FileGetLongName(&gPlayCtrl.File, LongFileName);
		ShowFileName( gPlayCtrl.File.ShortName);
		//ShowFileName( LongFileName);
		
		if( 1 != Status_DisVol )
		{
			//ShowPlayTotaltime(gSongInfo.TotalPlayTime );
		}
		
		DBG(("%d\n", (WORD)Ret));
		for(p = (WORD*)LongFileName; *p != 0; p++)
		{
			DBG(("%-.2BX %-.2BX ", ((BYTE*)p)[0], ((BYTE*)p)[1]));
		}
		DBG(("\n"));
	}
#endif



}

#ifdef FUNC_LRC_EN
VOID SongLrcDisplay()
{
	if(gPlayCtrl.LrcFlag)
	{
		LRC_ROW* pLrcRow;
		pLrcRow = GetLrcRow((gSongInfo.CurPlayTime + 1) * 10);
		if(pLrcRow != NULL)
		{
#ifdef FUNC_UARTDBG_EN
			BYTE i;

			for(i = 0; i < pLrcRow->Len; i++)
			{
				if((pLrcRow->pLrcData)[i])
				{
					DBG(("%c", ((pLrcRow->pLrcData)[i])));
				}
			}
			DBG(("\n"));
#endif
			//ClearFreqWin();
			DBG(("bUnicode = %x\n" , (short)bUnicode));
			if( 1 != Status_DisVol )
			{
				if(bUnicode)
				{
					ShowLrc(pLrcRow->pLrcData , 1 );
				}
				else
				{
					ShowLrc(pLrcRow->pLrcData , 0 );
				}
			}
			//ShowLrc("һ�����������߰˾�ʮһ�����������߰˾�ʮ" , 0 );
		}		
	}
}
#endif


//���������У���ʾ������Ϣ
VOID DisplayPlayInfo()
{	
	BYTE CODE RepeatName[][4] = {"ALL", "RAN", "ONE", "INT"};
	BYTE CODE EqName[][5] = {"NORM", "ROCK", "POP ", "CLAS", "JAZZ", "BLUE", "HALL", "BASS", "SOFT", "COUN", "OPER"};

	if(gPlayCtrl.FolderEnable)
	{
		DBG(("F"));
	}
	else
	{
		DBG(("D"));
	}

	DBG(("(%-.3d, %-.3d)", gPlayCtrl.FolderNum, gPlayCtrl.FileNum));
		
	DBG(("%-.8s.%-.3s ", 
		&gPlayCtrl.File.ShortName[0],
		&gPlayCtrl.File.ShortName[8]));

	DBG(("%-.2d:%-.2d ", 
		(WORD)(gSongInfo.CurPlayTime/60), 
		(WORD)(gSongInfo.CurPlayTime%60)));

	DBG(("%-.2d ", (WORD)gSys.Volume));
	DBG(("%s ", RepeatName[gPlayCtrl.RepeatMode]));
	DBG(("%s ", EqName[gPlayCtrl.Eq]));

	DBG(("\n"));

#ifdef FUNC_LRC_EN
	if(gPlayCtrl.State == PLAY_STATE_PLAY)
	{
		SongLrcDisplay();
	}
#endif
}


// Send volume to decoder.
VOID PlayVol2Decd()							
{
	InDacSetVolume(gVolArr[gSys.Volume]);
	//InDacMuteDis();
}


// Send system EQ to decoder.
VOID PlayEQ2Decd()	
{
	DecoderSetEQ(gDecdEQ[gPlayCtrl.Eq]);
}


// Play song, update song data for playing.
BOOL SongPlayDo()					
{
	BYTE Retry = 10;
	
	while(Retry--)
	{	
		//ÿ��ѭ���ж����һ���ļ��Ƿ񵽽�β
		//������ļ���β��ֱ�ӷ���TRUE
		//����ִ�е�FileRead()�л᷵��FALSE������REPEAT ONEģʽ��Ҳ���е���һ��
		if((gPlayCtrl.State != PLAY_STATE_PLAY) || FileEOF(&gPlayCtrl.File))
		{
		 	return TRUE;
		}

		if(!IsDecoderDone())
		{
			//decoder���Ӷ�ʱ�����
			if(IsTimeOut(&s_PlayWatchTimer))
			{
				DBG(("Play Watcher Over!\n"));
				return FALSE;
			}
			return TRUE;
		}

		TimeOutSet(&s_PlayWatchTimer, PLAY_WATCH_TIME);

		if(!FileRead(&gPlayCtrl.File, gSongInfo.PlayBuffer, 1024))
		{
			DBG(("FileRead() FALSE 002!\n"));
			return FALSE;
		} 
		SetDecoderData(gSongInfo.PlayBuffer, 1024);	
	}

	return TRUE;			
}


// Stop decoding and go to stop state.
VOID SongPlayStop()						
{
	DBG(("SongPlayStop()\n"));
	FileRewind(&gPlayCtrl.File);
	//gSongInfo.CurPlayTime = 0;

	//�����ļ�����ʱ����Ϣ��2402C��
	//????????????????????

	
	//�ر�DAC
	InDacMuteEn();
	gPlayCtrl.State = PLAY_STATE_STOP;
}


//ָ������ʱ�䣬��ʼ��decoder����decoder���ݣ�����decoder����
//��������˻ָ�����
//���벥��״̬
BOOL SongPlayStart()
{	
	SetDecoderMode(gSongInfo.SongType);	
	PlayEQ2Decd();
	DecoderSeekToTime(gSongInfo.CurPlayTime);  //ָ������ʱ��
	if(!FileRead(&gPlayCtrl.File, gSongInfo.PlayBuffer, 1024))
	{
		DBG(("FileRead() FALSE 001!\n"));
		return FALSE;
	}
	SetDecoderData(gSongInfo.PlayBuffer + gSongInfo.DataOffset, 1024 - gSongInfo.DataOffset); 	
	DecoderStartPlay();
	InDacSetSampleRate(gSongInfo.SamplesPerSecond);
	PlayVol2Decd();
	if((gSongInfo.SongType == SONG_TYPE_PCM_1CH)
	|| (gSongInfo.SongType == SONG_TYPE_PCM_2CH)
	|| (gSongInfo.SongType == SONG_TYPE_IMA_ADPCM))
	{	
		//��POP��
		WaitMs(100);	
	}
	SongPlayTimeStart();
	TimeOutSet(&s_PlayWatchTimer, PLAY_WATCH_TIME);
	IsVolumeUpEnd = FALSE;	 
	//����ǿ�������ˡ��ϵ㲥�ţ����ǴӸ�����ͷ���ţ�����ʱһ��ʱ���ٴ�DAC������������pop����
	TimeOutSet(&VolumeUpTimer, (gSongInfo.CurPlayTime > 0) ? 200 : 0);	
	gPlayCtrl.State = PLAY_STATE_PLAY;

	//����и�ʣ����Զ���������
	if( gPlayCtrl.LrcFlag )
	{
		LcdBkLightOpt( 1 );
	}
	
	return TRUE;
}


//��ʼһ�׸����Ĳ���: ���ļ��������ļ�����ʼ��decoder
BOOL SongPlayInit()
{
	FOLDER* Folder = NULL;
					
#ifdef FUNC_FOLDER_EN
	if(gPlayCtrl.FolderEnable)
	{
		Folder = &gPlayCtrl.Folder;
	}
#endif
	
	//���ļ�	
	DBG1((" SongPlayInit  filenum = %d  \n" , gPlayCtrl.FileNum ));
	if(!FileOpenByNum(&gPlayCtrl.File, Folder, gPlayCtrl.FileNum))
	{
		DBG(("FileOpenByNum() error!\n"));
		return FALSE;
	}

#ifdef FUNC_FOLDER_EN
	if(gPlayCtrl.Folder.FolderNum != gPlayCtrl.File.FolderNum)
	{
		// ����gPlayCtrl.Folder����
		gPlayCtrl.FolderNum = GetValidFolderNum(gPlayCtrl.File.FolderNum);
		if(!FolderOpenByValidNum(&gPlayCtrl.Folder, NULL, gPlayCtrl.FolderNum))
		{
			//DBG(("****FolderOpenyBNum(%d) Failed!\n", gPlayCtrl.File.FolderNum));
			return FALSE;
		}
	}
#endif

	//����LRC
#ifdef FUNC_LRC_EN
	FileGetLongName(&gPlayCtrl.File, gstLrcLongFileName.Name);
	gPlayCtrl.LrcFlag = ParseLrc(&gPlayCtrl.Folder, &gPlayCtrl.File.ShortName);
#endif

#ifdef FUNC_TAG_EN
	LoadTagInfo(&gPlayCtrl.File, TAG_ID3V2, TAG_NONE, TAG_WMA);
#endif
	
	//�����ļ�
	if(!DecoderAnalysis(&gPlayCtrl.File))
	{
		return FALSE;
	}
		
#ifdef FUNC_UARTDBG_EN
	DisplaySongInfo();	
#endif
					
	ClearFreqWin();		//������Ļ������֮ǰ���ݲ���
	ShowSongInfo();	//��������ʾ��������,ʱ������Ϣ
	gSongInfo.CurPlayTime = 0;

	
#ifdef FUNC_BREAK_POINT_EN
	//�˴����沥���ļ���Ŀ¼�ŵ�2402C��
	//???????????????????????????????????????????
	//???????????????????????????????????????????
	BP_SaveFileNO(  );		//��һ������Ϊ0���ݲ�����folderģʽ

	if(s_BreakPointFlag)
	{
		DBG1(("gSongInfo.CurPlayTime = %lu  \n" , gSongInfo.CurPlayTime ));
		s_BreakPointFlag = FALSE;
		gSongInfo.CurPlayTime = BP_GetCurPlayTime();	
	}
#endif

#ifdef FUNC_REPEAT_AB_EN
	s_RepeatAB_State = REPEAT_AB_STATE_IDLE;
#endif
//	IsFastPlayResume = FALSE;

	//��ʼ��decoder�������벥��״̬
	if(!SongPlayStart())
	{
		return FALSE;
	}

	return TRUE;
}


static VOID GetNextSongNum(BYTE Direction)
{
	WORD	SongSum;
	WORD	Temp;
	BYTE	StepCnt;

#ifdef	FUNC_FOLDER_EN	
	DBG1(("filder en \n"));
	if(gPlayCtrl.FolderEnable)
	{
		//����ļ��к��б仯�������´�
		if(gPlayCtrl.FolderNum != gPlayCtrl.Folder.ValidFolderNum)
		{
			if(!FolderOpenByValidNum(&gPlayCtrl.Folder, NULL, gPlayCtrl.FolderNum))
			{
				DBG(("FolderOpenByValidNum() error!\n"));
				return;
			}
		}		
		SongSum = gPlayCtrl.Folder.IncFileCnt;
	}
	else
	{
		SongSum = gFsInfo.FileSum;
	}
#else
	SongSum = gFsInfo.FileSum;
#endif

	

	if(SongSum == 0)
	{
		return;
	}
	DBG1(("filder en SongSum = %d \n" , SongSum ));
	switch (gPlayCtrl.RepeatMode)
	{	
		case PLAY_MODE_REPEAT_ONE:
		case PLAY_MODE_REPEAT_ALL: 		
		case PLAY_MODE_INTRO:  
			DBG1((" 1111111111111111111 \n"));
			if(Direction == PLAY_DIRECT_NEXT_10)
			{
				StepCnt = 10;
				Direction = PLAY_DIRECT_NEXT;
			}
			else if(Direction == PLAY_DIRECT_PRE_10)
			{
			 	StepCnt = 10;
				Direction = PLAY_DIRECT_PRE;
			}
			else
			{
			 	StepCnt = 1;
			} 
			DBG1(("filder en gPlayCtrl.FileNum = %d \n" , gPlayCtrl.FileNum ));
			if(Direction == PLAY_DIRECT_NEXT)
			{
				if((gPlayCtrl.FileNum + StepCnt) > SongSum)
				{
					gPlayCtrl.FileNum = 1;
				}
				else
				{
					gPlayCtrl.FileNum += StepCnt;
				}
				DBG1(("filder en gPlayCtrl.FileNum = %d \n" , gPlayCtrl.FileNum ));
			}
			else if(Direction == PLAY_DIRECT_PRE)
			{
				if(gPlayCtrl.FileNum <= StepCnt)
				{
					gPlayCtrl.FileNum = SongSum;
				}
				else
				{
					gPlayCtrl.FileNum -= StepCnt;
				}
			}
			break;

		case PLAY_MODE_RANDOM:	
#ifdef FUNC_NEW_RANDOM_EN
			gPlayCtrl.FileNum = GetRandomNum(SongSum);
#else
			DBG1((" 2222222222222222222222 \n"));
			Temp = (gSysTick%SongSum) + 1;
			if(Temp == gPlayCtrl.FileNum)
			{
				Temp++;
			}

			if(Temp > SongSum)
			{
				Temp = 1;	
			}

			gPlayCtrl.FileNum = Temp;
#endif
			break;

		default:
			DBG1((" 33333333333333333333 \n"));
			break;
	}
	
	gPlayCtrl.Direction = Direction;
	return;
}


// Play state process.
VOID PlayStatePlayOp()					
{	
	//�������Ž����������������10�룬�л�����
	//�����ǰ�ǲ��ŵ��ļ�ĩβ������Ҫ�ȴ�PCM FIFO�е����ݲ�����ϡ�
	if((FileEOF(&gPlayCtrl.File) && (DecoderGetSampleCnt() < 100))
	||((gPlayCtrl.RepeatMode == PLAY_MODE_INTRO) && (gSongInfo.CurPlayTime > 10)))
	{
		DBG(("Song play end!\n"));
		//�ȴ�PCM����ȫ����ȡ��
		SongPlayStop();	
		if(gPlayCtrl.RepeatMode != PLAY_MODE_REPEAT_ONE)
		{	   
			GetNextSongNum(PLAY_DIRECT_NEXT);
		}
		if(!SongPlayInit())
		{
		 	MessageSend(MSG_FIFO_KEY, MSG_NEXT);	
			gPlayCtrl.State = PLAY_STATE_STOP;
			return;
		}
	}

#ifdef FUNC_REPEAT_AB_EN
	if((s_RepeatAB_State == REPEAT_AB_STATE_PLAY)
	&&(gSongInfo.CurPlayTime >= s_RepeatAB_SecondsB))
	{
		DBG(("Replay\n"));
		InDacMuteEn();
		gSongInfo.CurPlayTime = s_RepeatAB_SecondsA;
		if(!SongPlayStart())
		{
			MessageSend(MSG_FIFO_KEY, MSG_NEXT);	
			gPlayCtrl.State = PLAY_STATE_STOP;
		}
	}

#endif

	if(IsTimeOut(&VolumeUpTimer) && (!gSys.MuteFg) && (!IsVolumeUpEnd))
	{
		InDacMuteDis();
		IsVolumeUpEnd = TRUE;
	}

	if(!SongPlayDo())
	{
		SongPlayStop();
		MessageSend(MSG_FIFO_KEY, MSG_NEXT);	
		gPlayCtrl.State = PLAY_STATE_STOP;	
		return;
	}

	switch(gPlayCtrl.Event)
	{
		case MSG_RETURN_VOLTAGE:
		case MSG_NO_SHOW_VOLUME:
		{			
			{
				//��ʱӦ��ʾ��ͣ״̬ͼ��
				//���ԭ����ʾ����
				ClearFreqWin();
				//��ʾ�ļ���
				ShowSongInfo();
				//��ʾʣ�ಥ��ʱ��
				ShowPlayTotaltime(gSongInfo.CurPlayTime );
			}
			break ;
		}
		case MSG_PLAY_PAUSE:
			DBG(("PAUSE\n"));
			InDacMuteEn();
			DecoderPause();
			SongPlayTimePause();
			gPlayCtrl.State = PLAY_STATE_PAUSE;
#ifdef ORUITE_ICON_IN_PLAYMODE

			//��ʾORUITEͼ��
	#ifdef ORTICON	
			ShowORTIcon();
	#else
			ShowString( "ŷ����" , 0  , 0 , 1 );
			ShowString( "ORUITE" , 0 , 1 , 1 );
	#endif	
#else
			if( gPlayCtrl.LrcFlag )	//����Ļ�ļ�������²���Ҫˢ����ʾ�ļ�����ʱ��
			{
				//��ʱӦ��ʾ��ͣ״̬ͼ��
				//���ԭ����ʾ����
				ClearFreqWin();
				//��ʾ�ļ���
				ShowSongInfo();
				//��ʾʣ�ಥ��ʱ��
				ShowPlayTotaltime(gSongInfo.CurPlayTime );
			}
#endif			
			ShowPauseIcon(1);
			break;

		case MSG_STOP:
			DBG(("STOP\n"));
			SongPlayStop();	
#ifdef ORUITE_ICON_IN_PLAYMODE
			//��ʾORUITEͼ��
	#ifdef ORTICON	
			ShowORTIcon();
	#else
			ShowString( "ŷ����" , 0  , 0 , 1 );
			ShowString( "ORUITE" , 0 , 1 , 1 );
	#endif			
#else			
			if( gPlayCtrl.LrcFlag )	//����Ļ�ļ�������²���Ҫˢ����ʾ�ļ�����ʱ��
			{
				//��ʾֹͣ״̬��Ϣ��ʾ
				//���ԭ����ʾ����
				ClearFreqWin();
				//��ʾ�ļ���
				ShowSongInfo();
			}
			//��ʾʣ�ಥ��ʱ��
			ShowPlayTotaltime( 0 );
#endif			
			ShowStopIcon(1);
			break;

#ifdef FUNC_FAST_PLAY_EN
		case MSG_FF_START:
			DBG(("FF_START\n"));
			InDacMuteEn();
			DecoderFastPlaySet(FAST_FORWARD, 8);
			gPlayCtrl.State = PLAY_STATE_FF;
			break;

		case MSG_FB_START:
			DBG(("FB_START\n"));
			InDacMuteEn();
			DecoderFastPlaySet(FAST_BACKWARD, 8);
			gPlayCtrl.State = PLAY_STATE_FB;
			break;
#endif
		default:
			break;
	}
}


// Play pause state process.
VOID PlayStatePauseOp()					
{	
	switch (gPlayCtrl.Event)
	{	
		case MSG_RETURN_VOLTAGE:
		case MSG_NO_SHOW_VOLUME:
		{
			//if( gPlayCtrl.LrcFlag )	//����Ļ�ļ�������²���Ҫˢ����ʾ�ļ�����ʱ��
			{
				//��ʱӦ��ʾ��ͣ״̬ͼ��
				//���ԭ����ʾ����
				ClearFreqWin();
				//��ʾ�ļ���
				ShowSongInfo();
				//��ʾʣ�ಥ��ʱ��
				ShowPlayTotaltime(gSongInfo.CurPlayTime );
				ShowPauseIcon(1);
			}
			break ;
		}
		case MSG_PLAY_PAUSE:
			DBG(("RESUME\n"));
			PlayVol2Decd();	
			InDacMuteDis();
			DecoderStartPlay();
			SongPlayTimeResume();
			TimeOutSet(&s_PlayWatchTimer, PLAY_WATCH_TIME);
			gPlayCtrl.State = PLAY_STATE_PLAY;
#ifdef ORUITE_ICON_IN_PLAYMODE
			//ȥORUITEͼ��
			//���ԭ����ʾ����
			ClearFreqWin();
			//��ʾ�ļ�����ʱ����Ϣ
			ShowSongInfo( );
#endif
			//ȥ����ͣ��־
			ShowPauseIcon(0);
			
			break;	
		
		case MSG_STOP:
			DBG(("STOP\n"));
			SongPlayStop();	
			//ʣ�ಥ��ʱ����ʾΪ 0
			ShowPlayTotaltime( 0);
			ShowStopIcon(1);
			break;
	
		default:
			break;			
	}	
}


// Play stop state process.
VOID PlayStateStopOp()				
{
	switch (gPlayCtrl.Event)
	{
		case MSG_RETURN_VOLTAGE:
		case MSG_NO_SHOW_VOLUME:
		{						
			//��ʱӦ��ʾ��ͣ״̬ͼ��
			//���ԭ����ʾ����
			ClearFreqWin();
			//��ʾ�ļ���
			ShowSongInfo();
			//��ʾʣ�ಥ��ʱ��
			ShowPlayTotaltime(0 );
			ShowStopIcon(1);
			break ;
		}
		case MSG_NEXT:
		case MSG_PRE:
			break;
					
		case MSG_PLAY_PAUSE:
			DBG(("PLAY\n"));	
			if(!SongPlayInit())
			{
				gPlayCtrl.State = PLAY_STATE_STOP;
			}
			else
			{
				ShowStopIcon( 0 );
			}
			break;	
			
		default:
			break;			
	}
}


#ifdef FUNC_FAST_PLAY_EN
// Play State fast forward control.
VOID PlayStateFF_FBOp()
{
	DecoderFastPlayProc();
	
	switch(gPlayCtrl.Event)
	{
		case MSG_FF_FB_END:
//			IsFastPlayResume = TRUE;
			if(!SongPlayStart())
			{
			 	MessageSend(MSG_FIFO_KEY, MSG_NEXT);	
				gPlayCtrl.State = PLAY_STATE_STOP;
			}			
			break;

		default:
			break;
	}
}
#endif

VOID StartSleepTimer( VOID )
{
	//�������߶�ʱ��
	//TimeOutSet(&s_SleepTimer, OUTTIME_SLEEPTIMER);

	return ;
}

// Play state control.
VOID PlayStateCtrl()									
{	
	gPlayCtrl.Event = MessageGet(MSG_FIFO_KEY);

#ifdef FUNC_OPEN_FILE_DELAY_EN
	if(s_IsOpenFileDelay)
	{	
		if((gPlayCtrl.Event == MSG_NONE) && IsTimeOut(&s_OpenFileDelayTimer))
		{
			if(!SongPlayInit())
			{
				MessageSend(MSG_FIFO_KEY, (gPlayCtrl.Direction == PLAY_DIRECT_PRE) ? MSG_PRE : MSG_NEXT);
				gPlayCtrl.State = PLAY_STATE_STOP; 
			}
			s_IsOpenFileDelay = FALSE;
		}
	}
#endif
	//Status_DisVol = 0 ;
#if 0
	//���һ��ʱ�����޲���,������
	//������ģʽ��,������ģʽ�²�����
	//DBG(("SSSSSSSSSSSSSSSSSSSS Send POWER-MSG enent = %u \n" , (short)gPlayCtrl.Event));
	if( ( PLAY_STATE_STOP == gPlayCtrl.State  )  ||( PLAY_STATE_PAUSE == gPlayCtrl.State )  || ( PLAY_STATE_STOP == gPlayCtrl.State ) )
	{
		if( 0 == gPlayCtrl.Event )
		{
			//���¼�����
			//if( ( PLAY_STATE_STOP == gPlayCtrl.State  )  ||( PLAY_STATE_PAUSE == gPlayCtrl.State )  || ( PLAY_STATE_STOP == gPlayCtrl.State ) )
			{
				//�������ڼ���״̬�в��ް�������
				//IsActed = 0 ;
				if(IsTimeOut(&s_SleepTimer))
				{
					//�Ѿ���ʱ,��������״̬
					MessageSend( MSG_FIFO_DEV_CTRL , MSG_POWER );
					DBG(("SSSSSSSSSSSSSSSSSSSS Send POWER-MSG \n"));
				}
			}
		}
		else
		{
			//�������߶�ʱ��
			//StartSleepTimer();
			TimeOutSet(&s_SleepTimer, OUTTIME_SLEEPTIMER);
		}
	}	
#endif
	if( ( 0 != gPlayCtrl.Event ) || ( !GET_BATTERY_CHARGING_PORT_STATUS) || ( 1 == gSys.StatusDisCharging ))
	{
		//�а��� ����ŵ�״̬�²��ػ������������������߶�ʱ��
		
		TimeOutSet(&s_SleepTimer, OUTTIME_SLEEPTIMER);
	}
	if(IsTimeOut(&s_SleepTimer))
	{
		if( ( PLAY_STATE_STOP == gPlayCtrl.State  )  ||( PLAY_STATE_PAUSE == gPlayCtrl.State )  || ( PLAY_STATE_IDLE == gPlayCtrl.State )  )
		{
			//��ŵ�״̬�²��Զ��ػ�
			//�Ѿ���ʱ,��������״̬
			MessageSend( MSG_FIFO_DEV_CTRL , MSG_POWER );
			//DBG1(("SSSSSSSSSSSSSSSSSSSS Send POWER-MSG \n"));
			return ;
		}
	}
	
	if(gPlayCtrl.State != PLAY_STATE_BROWSE)
	{
		//��������״̬�µ�ͨ���¼�
		switch (gPlayCtrl.Event)
		{							
			case MSG_VOL_ADD:
			{
				DBG(("VOL+\n"));
				if(gSys.Volume < VOLUME_MAX)
				{ 
					gSys.Volume++;
				}
				
				PlayVol2Decd(); 
				DisplayPlayInfo();
				ShowVolume( );			//�����渳ֵ���˳���ܵߵ�,�����Ӱ���������ʱ����ʾЧ��
				Status_DisVol = 1 ;	
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveVolumeInfo();
#endif
				break;
			}
			case MSG_VOL_ADD_CP:
			{
				DBG(("VOL+\n"));
				if(gSys.Volume < VOLUME_MAX)
				{ 
					gSys.Volume++;
				}
				
				PlayVol2Decd(); 
				DisplayPlayInfo();
				ShowVolumeCP(1 );			//�����渳ֵ���˳���ܵߵ�,�����Ӱ���������ʱ����ʾЧ��
				Status_DisVol = 1 ;	
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveVolumeInfo();
#endif
				break;
			}
			case MSG_VOL_SUB:
			{
				DBG(("VOL-\n"));
				if(gSys.Volume > VOLUME_MIN)
				{ 
					gSys.Volume--;
				} 
				
				PlayVol2Decd();
				DisplayPlayInfo();
				ShowVolume( );
				Status_DisVol = 1 ;
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveVolumeInfo();
#endif
				break;
			}
			case MSG_VOL_SUB_CP:
			{
				DBG(("VOL-\n"));
				if(gSys.Volume > VOLUME_MIN)
				{ 
					gSys.Volume--;
				} 
				
				PlayVol2Decd();
				DisplayPlayInfo();
				ShowVolumeCP(0 );
				Status_DisVol = 1 ;
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveVolumeInfo();
#endif
				break;
			}
			case MSG_REPEAT:
				DBG(("REPEAT\n"));
				gPlayCtrl.RepeatMode++;
				if(gPlayCtrl.RepeatMode >= PLAY_MODE_SUM)
				{
					gPlayCtrl.RepeatMode = 0;
				}
				DisplayPlayInfo();
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveInfo();
#endif
				break;
	
			case MSG_EQ_SW:
				DBG(("EQ\n"));	
				gPlayCtrl.Eq++;
				if(gPlayCtrl.Eq >= DECD_EQ_SUM)
				{
					gPlayCtrl.Eq = 0; 	
				}
				PlayEQ2Decd();
				DisplayPlayInfo();
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveInfo();
#endif
				break;
				
			case MSG_MUTE:
				if(gSys.MuteFg)
				{
					DBG(("UNMUTE\n"));
					gSys.MuteFg = FALSE;
					PlayVol2Decd();
					InDacMuteDis();
				}
				else
				{
					DBG(("MUTE\n"));
					gSys.MuteFg = TRUE;
					InDacMuteEn();
				}	
				break;
	
			case MSG_NEXT:
				ClearFreqWin();
				DBG(("NEXT\n"));
				SongPlayStop();
				GetNextSongNum(PLAY_DIRECT_NEXT);
				DBG1(("FileNum: %d\n", gPlayCtrl.FileNum));

#ifdef FUNC_OPEN_FILE_DELAY_EN
				TimeOutSet(&s_OpenFileDelayTimer, OPEN_FILE_DELAY_TIME);
				s_IsOpenFileDelay = TRUE;
#else
				if(!SongPlayInit())
				{
					MessageSend(MSG_FIFO_KEY, MSG_NEXT);
					gPlayCtrl.State = PLAY_STATE_STOP; 
				}
#endif
				break;
	
			case MSG_PRE:
				ClearFreqWin();
				DBG(("PRE\n"));	
				SongPlayStop();
				GetNextSongNum(PLAY_DIRECT_PRE);
				DBG1(("FileNum: %d\n", gPlayCtrl.FileNum));

#ifdef FUNC_OPEN_FILE_DELAY_EN
				TimeOutSet(&s_OpenFileDelayTimer, OPEN_FILE_DELAY_TIME);
				s_IsOpenFileDelay = TRUE;
#else
				if(!SongPlayInit())
				{
					MessageSend(MSG_FIFO_KEY, MSG_PRE);
					gPlayCtrl.State = PLAY_STATE_STOP; 
				}
#endif				
				break;
	
			case MSG_FOLDER_EN:
				if(gPlayCtrl.FolderEnable)
				{
					DBG(("FOLDER_DIS\n"));
					gPlayCtrl.FolderEnable = FALSE;
					gPlayCtrl.FileNum = gPlayCtrl.File.FileNumInDisk;
				}
				else
				{
					DBG(("FOLDER_EN\n"));
					gPlayCtrl.FolderEnable = TRUE;
					gPlayCtrl.FileNum = gPlayCtrl.File.FileNumInFolder;
				}	
#ifdef FUNC_BREAK_POINT_EN
				BP_SaveInfo();
#endif
				break;
	
			case MSG_NEXT_FOLDER:
				DBG(("NEXT_FOLDER\n"));	
				gPlayCtrl.FolderEnable = TRUE;

#ifdef FUNC_OPEN_FILE_DELAY_EN
				s_IsOpenFileDelay = FALSE;
#endif

				SongPlayStop();
				if(gPlayCtrl.FolderNum < gFsInfo.ValidFolderSum)
				{
					gPlayCtrl.FolderNum++;
				}
				else
				{
					gPlayCtrl.FolderNum = 1;
				}
	
				if(!FolderOpenByValidNum(&gPlayCtrl.Folder, NULL, gPlayCtrl.FolderNum))
				{
					DBG(("FolderOpenByValidNum() error!\n"));
					//while(1);
					MessageSend(MSG_FIFO_KEY, MSG_NEXT_FOLDER);
					return;
				}

#ifdef FUNC_NEW_RANDOM_EN
				if(gPlayCtrl.RepeatMode == PLAY_MODE_RANDOM)
				{
					gPlayCtrl.FileNum = GetRandomNum(gPlayCtrl.Folder.IncFileCnt);
				}
				else
				{
					gPlayCtrl.FileNum = 1;
				}
#else
				gPlayCtrl.FileNum = 1;
#endif

				if(!SongPlayInit())
				{
				 	MessageSend(MSG_FIFO_KEY, MSG_NEXT); 
				}
				break;
	
			case MSG_PRE_FOLDER:
				DBG(("PRE_FOLDER\n"));	
				gPlayCtrl.FolderEnable = TRUE;

#ifdef FUNC_OPEN_FILE_DELAY_EN
				s_IsOpenFileDelay = FALSE;
#endif

				SongPlayStop();
				if(gPlayCtrl.FolderNum > 1)
				{
					gPlayCtrl.FolderNum--;
				}
				else
				{
					gPlayCtrl.FolderNum = gFsInfo.ValidFolderSum;
				}
	
				if(!FolderOpenByValidNum(&gPlayCtrl.Folder, NULL, gPlayCtrl.FolderNum))
				{
					DBG(("FolderOpenByValidNum() error!\n"));
					//while(1);
					MessageSend(MSG_FIFO_KEY, MSG_PRE_FOLDER);
					return;
				}
	
#ifdef FUNC_NEW_RANDOM_EN
				if(gPlayCtrl.RepeatMode == PLAY_MODE_RANDOM)
				{
					gPlayCtrl.FileNum = GetRandomNum(gPlayCtrl.Folder.IncFileCnt);
				}
				else
				{
					gPlayCtrl.FileNum = 1;
				}
#else
				gPlayCtrl.FileNum = 1;
#endif
				
				if(!SongPlayInit())
				{
				 	MessageSend(MSG_FIFO_KEY, MSG_NEXT); 
				}
				break;
	
#ifdef FUNC_FILE_BROWSER_EN
			case MSG_BROWSE_START:
				FileBrowseInit();
				SongPlayStop();
				gPlayCtrl.State = PLAY_STATE_BROWSE;
				gPlayCtrl.Event = MSG_NONE;
				break;
#endif

#ifdef FUNC_REPEAT_AB_EN
			case MSG_REPEAT_AB:
				if(s_RepeatAB_State == REPEAT_AB_STATE_IDLE)
				{
					DBG(("Set A time: %ld\n", (DWORD)gSongInfo.CurPlayTime));
					s_RepeatAB_SecondsA = gSongInfo.CurPlayTime;
					s_RepeatAB_State = REPEAT_AB_STATE_SET;
				}
				else if(s_RepeatAB_State == REPEAT_AB_STATE_SET)
				{
					DBG(("Set B time: %ld\n", (DWORD)gSongInfo.CurPlayTime));
					s_RepeatAB_SecondsB = gSongInfo.CurPlayTime;
					s_RepeatAB_State = REPEAT_AB_STATE_PLAY;
				}
				else	//REPEAT_AB_STATE_PLAY
				{
					DBG(("Stop repeat AB!\n"));
					s_RepeatAB_State = REPEAT_AB_STATE_IDLE;
				}
				break;
#endif
	
			default:
				break;
		}
	}

 	switch(gPlayCtrl.State)
	{
		case PLAY_STATE_PLAY:
			PlayStatePlayOp();
			break;

		case PLAY_STATE_PAUSE:
			PlayStatePauseOp();
			break;

		case PLAY_STATE_STOP:
			PlayStateStopOp();
			break;

#ifdef FUNC_FAST_PLAY_EN
		case PLAY_STATE_FF:			
		case PLAY_STATE_FB:			
			PlayStateFF_FBOp();
			break;
#endif
		
#ifdef FUNC_FILE_BROWSER_EN
		case PLAY_STATE_BROWSE:
			PlayStateBrowseOp();
			break;
#endif

		default:
			break;
	}
	
	SongPlayTimeUpdate();
}


// Initialize playing control structure extend.
BOOL PlayCtrlInit()
{
	DBG1(("PlayCtrlInit()\n"));
	
//	StartSleepTimer();
	TimeOutSet(&s_SleepTimer, OUTTIME_SLEEPTIMER);
	
#ifdef FUNC_OPEN_FILE_DELAY_EN
	s_IsOpenFileDelay = FALSE;
#endif

#ifdef FUNC_BREAK_POINT_EN
	DBG1(("%d %d\n", BP_GetFolderSum(), BP_GetFileSum()));
	DBG1(("%d %d\n", gFsInfo.ValidFolderSum, gFsInfo.FileSum));
	if((gFsInfo.ValidFolderSum != BP_GetFolderSum())
	|| (gFsInfo.FileSum != BP_GetFileSum()))
	{
		s_BreakPointFlag = FALSE;
		gPlayCtrl.FolderNum = 1;
		gPlayCtrl.FileNum = 1;
		gPlayCtrl.Eq = DECD_EQ_NORMAL;
		gPlayCtrl.RepeatMode = PLAY_MODE_REPEAT_ALL;

		DBG1((" new store device  \n"));
		//�´洢�豸
		BP_SaveFolderInfo();
	}
	else
	{
		s_BreakPointFlag = TRUE;
#ifdef FUNC_FOLDER_EN
		gPlayCtrl.FolderNum = BP_GetCurFolderNum();
#endif
		DBG1((" bk filenum = %d  \n" , gPlayCtrl.FileNum ));
		gPlayCtrl.FileNum = BP_GetCurFileNum();
		DBG1((" after bk filenum = %d  \n" , gPlayCtrl.FileNum ));
		gPlayCtrl.Eq = gBreakPointInfo.Eq;
		//gPlayCtrl.RepeatMode = gBreakPointInfo.RepeatMode;
		gPlayCtrl.RepeatMode = PLAY_MODE_REPEAT_ALL;
		//gFsInfo.F
	}
#else
	s_BreakPointFlag = FALSE;
	gPlayCtrl.FolderNum = 1;
	gPlayCtrl.FileNum = 1;
	gPlayCtrl.Eq = DECD_EQ_NORMAL;
	gPlayCtrl.RepeatMode = PLAY_MODE_REPEAT_ALL;
#endif

	gPlayCtrl.Eq = DECD_EQ_NORMAL;//DECD_EQ_NORMAL;//DECD_EQ_BASS;//
	gPlayCtrl.Direction = PLAY_DIRECT_NEXT;
	
	gPlayCtrl.FolderEnable = TRUE;		//Ĭ��ʹ���ļ��й���
	
	if(!FolderOpenByValidNum(&gPlayCtrl.Folder, NULL, gPlayCtrl.FolderNum))
	{
		DBG(("FolderOpenByValidNum() error!\n"));
		return FALSE;
	}
	DBG1((" after FolderOpenByValidNum filenum = %d  \n" , gPlayCtrl.FileNum ));
	if(gFsInfo.FileSum == 0)
	{
		DBG(("No Song in Disk!!\n"));
		if(SYS_MODE_USB ==  gSys.SystemMode )
		{
			ShowLrc("U����û�������ļ�" , 0 );
		}
		else
		{
			ShowLrc("TF����û�������ļ�" , 0 );
		}
		gPlayCtrl.State = PLAY_STATE_STOP;
		return TRUE;
	}

#ifdef FUNC_AUTO_PLAY_EN
	if(!SongPlayInit())
	{
		MessageSend(MSG_FIFO_KEY, MSG_NEXT);	
		gPlayCtrl.State = PLAY_STATE_STOP;
	}
#else
	gPlayCtrl.State = PLAY_STATE_STOP;
#endif 

	return TRUE;
}


// Call this function before leaving play state.
BOOL PlayCtrlEnd()
{
	DBG(("PlayCtrlEnd()\n"));
	
	//�ر�DAC	
	SongPlayStop();	

	return TRUE;
}
