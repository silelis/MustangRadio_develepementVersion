#include "syscfg.h"
#include "sysctrl.h"
#include "ipod_usb.h"
#include "ipod_auth.h"
#include "audio_stream.h"
#include "usb_ipod_browser.h"
#include "usb_ipod_cmd.h"


#ifdef FUNC_USB_IPOD_EN

//IPOD��֤ʱ����IPOD�İ汾����Ϣ
BYTE* IpodFirmwareVersion = "\1\0\0";						//3 bytes
BYTE* IpodHardwareVersion = "\1\0\0";						//3 bytes
BYTE* IpodString_Name = "Car audio system";					//max length: 32bytes
BYTE* IpodString_Manu = "Arts Electronics Co., Ltd";		//max length: 32bytes
BYTE* IpodString_Model = "CE152/CE138";						//max length: 32bytes

//BYTE* IpodFirmwareVersion = "\1\0\0";
//BYTE* IpodHardwareVersion = "\1\0\0";
//BYTE* IpodString_Name = "MV iPhone Demo";	//max length: 32bytes
//BYTE* IpodString_Manu = "MV";				//max length: 32bytes
//BYTE* IpodString_Model = "Demo";			//max length: 32bytes

extern VOID InitIsoEndpoint(); 
extern VOID PlayVol2Decd();

extern BYTE IpodRespBuf[];


#define 	IPOD_MAX_TAG_LEN		32 		//TITLE��ARTIST��ALBUM����Ϣ����󳤶�
BYTE IpodTrackTitle[IPOD_MAX_TAG_LEN + 2];	//���浱ǰ���ڲ��ŵ���Ŀ��TITLE��Ϣ
BYTE IpodTrackArtist[IPOD_MAX_TAG_LEN + 2];	//���浱ǰ���ڲ��ŵ���Ŀ��ARTIST��Ϣ
BYTE IpodTrackAlbum[IPOD_MAX_TAG_LEN + 2];	//���浱ǰ���ڲ��ŵ���Ŀ��ALBUM��Ϣ

BOOL IpodAutoPlay = TRUE;					//����IPOD���Ƿ��Զ���������
BOOL IpodAuthFlag; 							//��֤�Ƿ�ɹ���ʶ
BYTE IpodFlag_FF_FB; 						//��������˱�־��0x01--FF��0x02--FB

WORD IpodCurPlayTime;						//��ǰ����ʱ�䣬��λΪ��
BYTE IpodCurPlayStatus;						//��ǰ�Ĳ���״̬


extern BOOL SlaveIpodAuthFlag;
extern BOOL SlaveIpodCtrlFlag;


/////////////////////////////////////////////////////////////////////////////////////////
//��������
BOOL IpodStartPlay()
{
	IpodFlag_FF_FB = 0x00;
		
	IPOD_WaitResp(0x0A, 0x02, 100);	//�ȴ�IPODѯ��֧����Щ������
	IpodRetSampleRate();			//����֧�ֵĲ�������Ϣ

	IpodSetEventNotification();	
	IpodEnterExtendedUIMode();	

	IpodCurPlayStatus = IpodGetPlayStatus(&IpodCurPlayTime);
	DBG(("%-.2BX, %d\n", IpodCurPlayStatus, IpodCurPlayTime));

	IpodSetRemoteNotification();
	IpodSetPlayStatusNotification();

	IpodSetShuffle(0x00);	//default: shuffle off
	IpodSetRepeat(0x02);	//default: repeat all

	IpodResetDBSelection();
	IpodTotalDBTrackNum = IpodGetDBRecordsNum(IPOD_DB_SONG);
	IpodTotalTrackNum = IpodGetNumPlayingTracks();
	IpodCurrentTrackIndex = IpodGetCurPlayingTrackIndex();

	if(IpodAutoPlay)
	{
		if(IpodCurPlayStatus == IPOD_STATUS_STOPPED)
		{
			IpodPlayCtrl_Play();
		}
		else
		{
			IpodPlayCtrl_PlayPauseToggle();
		}
	}
	IpodGetSongTitle(IpodCurrentTrackIndex, IpodTrackTitle, IPOD_MAX_TAG_LEN);
	IpodGetSongArtist(IpodCurrentTrackIndex, IpodTrackArtist, IPOD_MAX_TAG_LEN);
	IpodGetSongAlbum(IpodCurrentTrackIndex, IpodTrackAlbum, IPOD_MAX_TAG_LEN);

	return TRUE;	
}


//initial usb ipod device. 
BOOL UsbIpodCtrlInit()
{	
	//��ʼ��OTG
	AudioStreamInit();	
	InDacMuteEn();

	if(!SlaveIpodAuthFlag)
	{
		return TRUE;	//IPOD��֤���������
	}

	DBG(("IPOD_Auth() start...\n"));
	if(!IPOD_Auth())
	{
		DBG(("IPOD_Auth() FAIL!\n"));
		IpodAuthFlag = FALSE;
		return FALSE;
	}
	DBG(("IPOD_Auth() OK!\n"));
	IpodAuthFlag = TRUE;

	if(!SlaveIpodCtrlFlag)
	{
		return TRUE;	//IPOD���ų�ʼ�����������
	}

	IpodStartPlay();
	DBG(("IpodStartPlay() OK!\n"));

	IpodBrowserInit();	//��ʼ��IPOD�������

	//��ʼ��decoder
	SetDecoderMode(SONG_TYPE_PCM_2CH);	
	DecoderStartPlay();	
	
	//��ʼ��DAC
	PlayVol2Decd();	
	InDacMuteDis();

	InitIsoEndpoint();
	SetIntEnBit(MASK_INT_OTG_MC);

	return TRUE;
}


//end usb ipod device.
VOID UsbIpodCtrlEnd()
{	
	if(IpodAuthFlag)
	{
		//ϵͳ�л�������ģʽʱ�������Ҫ��IPOD���ֳ��״̬����ϵͳ�����Է�Ƶ������IPOD�����
		//�˳�IPODģʽʱ���л���SIMPLE REMOTEģʽ��IPOD���ڳ�磬�û�Ҳ����ֱ�Ӳ���IPOD����
		if(IpodIsExtendedUIMode)	
		{	
			IpodEnterRemoteUIMode();	//�л���IPOD���Զ�������ͣ״̬	
			IpodCurPlayStatus = IpodGetPlayStatus(&IpodCurPlayTime);
			
		}
		else
		{
			//����Ѿ�����SIMPLE REMOTEģʽ������IPOD��ͣ����
			if(IpodCurPlayStatus == IPOD_STATUS_PLAYING)
			{
				IpodPlayCtrl_PlayPauseToggle();
			}
		}
	}
	IpodAuthFlag = FALSE;

	ClrIntEnBit(MASK_INT_OTG_MC);
}


//usb ipod device state control.
VOID UsbIpodStateCtrl()
{	
	BYTE Event = MessageGet(MSG_FIFO_KEY);
	BYTE Temp;
	
	if(!SlaveIpodCtrlFlag)
	{
		AudioStreamProcess();
	}

	//��һ������LingoIDΪ0xFFʱ��ʾ��������LingID������һ������
	if(IPOD_WaitResp(0xFF, 0x00, 1))
	{
		if((IpodRespBuf[1] == 0x03) && (IpodRespBuf[2] == 0x09))
		{
	 		//����Notification��Ϣ	
			if(IpodRespBuf[3] == 0x01)			//track play back index	
			{
				if(IpodCurrentTrackIndex != *((WORD*)&IpodRespBuf[6]))
				{
	 				IpodCurrentTrackIndex = *((WORD*)&IpodRespBuf[6]);
					if(IpodCurrentTrackIndex != -1)
					{
						if(!IpodIsExtendedUIMode)
						{
							if(IpodFlag_FF_FB)	//������ڿ�������ˣ���������������
							{
								IpodPlayCtrl_EndFF_FB();
								IpodFlag_FF_FB = 0x00;	
							}
						}
						IpodGetSongTitle(IpodCurrentTrackIndex, IpodTrackTitle, IPOD_MAX_TAG_LEN);
						IpodGetSongArtist(IpodCurrentTrackIndex, IpodTrackArtist, IPOD_MAX_TAG_LEN);
						IpodGetSongAlbum(IpodCurrentTrackIndex, IpodTrackAlbum, IPOD_MAX_TAG_LEN);
						DBG(("Title: %s\n", IpodTrackTitle));
						DBG(("Artist: %s\n", IpodTrackArtist));
						DBG(("Album: %s\n", IpodTrackAlbum));
					} 
				}
				DBG(("CurrentTrackIndex: %d\n", IpodCurrentTrackIndex));
			}
			else if(IpodRespBuf[3] == 0x03)		//track capabilities changed
			{
				IpodCurPlayStatus = IpodRespBuf[4];
				DBG(("CurPlayStatus: %-.2BX\n", IpodCurPlayStatus));
				if((!IpodIsExtendedUIMode) && (IpodCurPlayStatus == IPOD_STATUS_PLAYING))
				{
					if(IpodFlag_FF_FB)	//������ڿ�������ˣ���������������
					{
						IpodPlayCtrl_EndFF_FB();
						IpodFlag_FF_FB = 0x00;		
					}
				}
			}
			else if(IpodRespBuf[3] == 0x0F)		//track position in seconds
			{
			 	IpodCurPlayTime = *((WORD*)&IpodRespBuf[4]);
				DBG(("track time: %d\n", IpodCurPlayTime));
			}
		}	
	}					

	switch(Event)
	{
		case MSG_PLAY_PAUSE:			
			if(IpodCurPlayStatus == IPOD_STATUS_STOPPED)			//stopped
			{
				IpodPlayCtrl_Play();				
			}
			else if(IpodCurPlayStatus == IPOD_STATUS_PLAYING)		//playing
			{
				IpodPlayCtrl_PlayPauseToggle();
			}
			else if(IpodCurPlayStatus == IPOD_STATUS_PAUSED)		//paused
			{
				IpodPlayCtrl_PlayPauseToggle();	
			}	
			break;

		case MSG_STOP:
			IpodPlayCtrl_Stop();
			IpodCurPlayStatus = IPOD_STATUS_STOPPED;	
			break;

		case MSG_FF_START:
			IpodPlayCtrl_StartFF();
			IpodFlag_FF_FB = 0x01;	
			break;
		
		case MSG_FB_START:
			IpodPlayCtrl_StartFB();	
			IpodFlag_FF_FB = 0x02;	
			break;

		case MSG_FF_FB_END:
			IpodPlayCtrl_EndFF_FB();
			IpodFlag_FF_FB = 0x00;	
			break;

		case MSG_VOL_ADD:
			DBG(("VOL+\n"));
			//XBYTE[0x9801] |= 0x04;
			HostInit();
			//DBG(("4444\n"));
			//WaitMs(1000);
			//HostInit();
			DBG(("5555\n"));
			if(gSys.Volume < VOLUME_MAX)
			{ 
				gSys.Volume++;
			}
			PlayVol2Decd(); 
			break;
				
		case MSG_VOL_SUB:
			DBG(("VOL-\n"));
//			Set6sReset(RST_6S_E2_LOW);
//			GoToSleepMode();

			if(gSys.Volume > VOLUME_MIN)
			{ 
				gSys.Volume--;
			} 
			PlayVol2Decd();
			break;

		case MSG_EQ_SW:		//SHUFFLE
			//0: shuffle off, 1: shuffle tracks, 2: shuffle albums
			Temp = (IpodGetShuffle() + 1) % 3;
			IpodSetShuffle(Temp);
			DBG(("shuffle: %d\n", (WORD)Temp));
			break;

		case MSG_REPEAT:	//REPEAT
			//0: repeat off, 1: repeat one, 2: repeat all
			Temp = (IpodGetRepeat() + 1) % 3;
			IpodSetRepeat(Temp);
			DBG(("repeat: %d\n", (WORD)Temp));
			break;

	 	case MSG_NEXT:
			if(IpodCurPlayStatus == IPOD_STATUS_STOPPED)			//stopped
			{
				IpodPlayCtrl_Play();			
			}
			else
			{
				IpodPlayCtrl_NextTrack();
			}
			break;

		case MSG_PRE:
			if(IpodCurPlayStatus == IPOD_STATUS_STOPPED)			//stopped
			{
				IpodPlayCtrl_Play();			
			}
			else
			{
				IpodPlayCtrl_PreTrack();
			}
			break;

		case MSG_NEXT_FOLDER:	//�л���REMOTE UIģʽ
			Temp = IpodCurPlayStatus;
			if(IpodIsExtendedUIMode)	
			{							
				IpodEnterRemoteUIMode();
				DBG(("Extended UI Mode\n"));
			}
			else 				//�л���EXTENDED UIģʽ	
			{
				IpodEnterExtendedUIMode();
				IpodCurPlayStatus = IpodGetPlayStatus(&IpodCurPlayTime);	
				DBG(("Remote UI Mode\n"));
			}

			if(Temp == IPOD_STATUS_PLAYING)
			{
				IpodPlayCtrl_PlayPauseToggle();
				Temp = IPOD_STATUS_PLAYING;
			}
			break;

		case MSG_PRE_FOLDER:	
			break;

		case MSG_REC_DELETE:
			break;

		case MSG_BROWSE_START:	//��ʼ���
			if(IpodIsExtendedUIMode)
			{
				IpodBrowserOnStart();
			}
			break;

		case MSG_RTC_DOWN:		//���ǰһ��
			if(IpodIsExtendedUIMode)
			{
				IpodBrowserOnUp();
			}
			break;

		case MSG_RTC_SW:		//�����һ��
			if(IpodIsExtendedUIMode)
			{
				IpodBrowserOnDown();
			}
			break;

		case MSG_RTC_UP:		//ȷ��
			if(IpodIsExtendedUIMode)
			{
				IpodBrowserOnOK();
			}
			break;

		case MSG_ALARM_MODE:	//������һ��
			if(IpodIsExtendedUIMode)
			{
				IpodBrowserOnCacel();
			}
			break; 				

		default:
			break;
	}

	IpodSimpleRemoteButtonOp(IpodFlag_FF_FB);
	AudioStreamProcess();
}

#endif