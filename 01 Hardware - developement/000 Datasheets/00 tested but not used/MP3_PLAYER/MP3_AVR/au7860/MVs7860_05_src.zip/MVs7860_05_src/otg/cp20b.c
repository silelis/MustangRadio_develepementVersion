#include "syscfg.h"
#include "i2c.h"


#ifdef FUNC_USB_IPOD_EN

//IPOD��֤оƬ�Ķ�д��������
#define  CP2_DEV_ADDR  0x20


//CP2.0B ��ʼ��
VOID CP20B_Init()
{
	SetGpioRegBit(CP20B_RST_PORT_OE, CP20B_RST_BIT);
	SetGpioRegBit(CP20B_RST_PORT_OUT, CP20B_RST_BIT);
	ClrGpioRegBit(CP20B_RST_PORT_OUT, CP20B_RST_BIT);
	WaitMs(50);
	SetGpioRegBit(CP20B_RST_PORT_OUT, CP20B_RST_BIT);
	WaitMs(50);
}


VOID CP20B_ReadBytes(BYTE Addr, BYTE* Buf, BYTE Len)
{
	I2C_Start(); 	
	I2C_WriteByte(CP2_DEV_ADDR);
	WaitMs(3);	//����ɾ��

	I2C_WriteByte(Addr);
	WaitMs(3);	//����ɾ��

	I2C_Stop();
	WaitMs(3);	//����ɾ��

	I2C_Start();
	I2C_WriteByte(CP2_DEV_ADDR | 0x01);
	WaitMs(3);	//����ɾ��

	while(Len--)
	{
		*(Buf++) = I2C_ReadByte();
		if(Len)
		{
			I2C_SendAck();
		}
		else
		{
			I2C_SendNoAck();
		}	
	}	

	I2C_Stop(); 
}

VOID CP20B_WriteBytes(BYTE Addr, BYTE* Buf, BYTE Len)
{	
	I2C_Start();
	I2C_WriteByte(CP2_DEV_ADDR);

	I2C_WriteByte(Addr);

	while(Len--)
	{
		I2C_WriteByte(*(Buf++));
	}		

	I2C_Stop();	

	WaitMs(3);
}

#endif