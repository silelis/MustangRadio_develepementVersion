 /*
********************************************************************************
*                   Copyright (c) 2010,ZhangXiaoYong
*                         All rights reserved.
*
* File Name��   show.c
* 
* Description:  ��ʾһЩͼƬ���ַ���ICON��
*
* History:      <author>          <time>        <version>       
*             ZhangXiaoYong      2010-03-12          1.0
*    desc:    ORG.
********************************************************************************
*/
#include "syscfg.h"
#include "sysctrl.h"
#include "resource.h"
#include "playctrl.h"
#include "rtc_ctrl.h"
#include "display.h"
#include "show.h"
#include "Lcd.h"
#include "gui.h"

//#if (LCD_TYPE  !=  LCD_NULL) // lxl comment 7-19
#if 1
BOOL 	DisplayVolAdj = FALSE ; //LXL ADD7-19
BOOL	PlayIconEn;
BOOL	SpeakEn;
BYTE  Length2312 = 16;
static BYTE CurrP,CurrSize;
BOOL NeedScroll;
BOOL LrcScroll;
TIMER DispScroTime;

#ifdef FUNC_RTC_EN
extern BYTE RtcState;
extern BYTE RtcSubState;
extern RTC_DATE_TIME gRtcTime;
#endif

/*
**********************************************************
*					LOCAL VARIABLE
**********************************************************
*/

//extern WORD  gRadioArg.CurFrequency;
WORD		DisplayRefreshFlag;
static BYTE 			DispBuf[12];
POSITION point;
static BYTE CurrVol;

extern BYTE	Language;
extern BOOL YesFlag;
//static TIMER			DisplayTimer;



/*
#define	DECD_EQ_NORMAL			0
#define	DECD_EQ_ROCK			1
#define	DECD_EQ_POP				2
#define	DECD_EQ_CLASSIC			3
#define	DECD_EQ_COUNTRY		4
*/

char DEV_ID_ICON[][5]=
{
"   ",
"FM ",
"SD ",
"USB",
"AUD",
"AUX",
"SD",
};

#if 0
//=================================
//main menu
char MenuInterfaceText[][11] = 
{
	" Sys Menu",
	"Dev Select ",
	" Sys Set",
	"BlackLight",
	"Language",
	"  Reader",
	" Versions",
	" Recover",
	"Area selec",
	"Dir selec",
	"  Repeat",
	"   EQ",
};
char MenuInterfaceText_CH[][9] = 
{
	"ϵͳ�˵�",
	"����ѡ��",
	"ϵͳ����",
	"����ʱ��",
	"��������",
	"  ������",
	"�̼��汾",
	"  ����",
	"����ѡ��",
	"Ŀ¼ѡ��",
	"ѭ��ģʽ",
	"  ������",
};
#endif
//================================
// MP3 menu
#if 0
char MenuMp3Text[][11] =
{
	"Sou Select",
	"FOL selec",
	"Repeat",
	"EQ",
	"Sys Set",
	"Return",
};
char MenuMp3Text_CH[][9] =
{
	"����ѡ��",
	"Ŀ¼ѡ��",
	"ѭ��ģʽ",
	"������",
	"����",
	"����",
};
#else
char MenuMp3Text[2][6][11] =
{

{
	{"SOURCE"},
	{"FOLDER"},
	{"REPEAT"},
	{"EQ"},
	{"SYSTEM SET"},
	{"RETURN"},
},
{
	{"����ѡ��"},
	{"Ŀ¼ѡ��"},
	{"ѭ��ģʽ"},
	{"������"},
	{"����"},
	{"����"},
},
};
#endif
//================================
// FM menu
#if 0
char MenuFmText[][11] =
{
	"Sou Select",
	"Auto scan",
	"Step scan",
	"Area selec",
	"Sys Set",
	"Return",
};
char MenuFmText_CH[][9] =
{
	"����ѡ��",
	"�Զ���̨",
	"������̨",
	"����ѡ��",
	"����",
	"����",
};
#else
char MenuFmText[2][6][11] =
{
{
	{"SOURCE"},
	{"AUTO SCAN"},
	{"STEP SCAN"},
	{"AREA SET"},
	{"SYSTEM SET"},
	{"RETURN"},
},

{
	{"����ѡ��"},
	{"�Զ���̨"},
	{"������̨"},
	{"����ѡ��"},
	{"����"},
	{"����"},
},
};
#endif
//================================
// AUDIO menu
#if 0
char MenuAudioText[][11] =
{
	"Sou Select",
	"Reader",	
	"Sys Set",
	"Return",
};
char MenuAudioText_CH[][9] =
{
	"����ѡ��",
	"������",
	"����",
	"����",
};
#else
char MenuAudioText[2][4][11] =
{
{
	{"SOURCE"},
	{"SD READER"},	
	{"SYSTEM SET"},
	{"RETURN"},
},
{
	{"����ѡ��"},
	{"������"},
	{"����"},
	{"����"},
},
};
#endif
//================================
// AUX menu
#if 0
char MenuAuxText[][11] =
{
	"Sou Select",
	"Sys Set",
	"Return",
};
char MenuAuxText_CH[][9] =
{
	"����ѡ��",
	"����",
	"����",
};
#else
char MenuAuxText[2][3][11] =
{
{
	{"SOURCE"},
	{"SYSTEM SET"},
	{"RETURN"},
},
{
	{"����ѡ��"},
	{"����"},
	{"����"},
},
};
#endif
//================================
// ALL menu
BYTE MenuAddr[] = {0,6,6,3,5,7,6,3,1,1,2};
#if 1
char MenuAllText[][11] =
{
	"FM",			//select dev 6
	"SD",
	"USB DISK",
	"USB AUDIO",
	"AUX",
	"RETURN",

	"BACK LIGHT",			// Sys Set 6
	"LANGUAGE",
	"SD READER",
	"VERSION",
	"DEFAULT",
	"RETURN",

	"NORMAL", 			//Area selec 3	
	"ALL BAND",
	"RETURN",

	"REPEAT ONE",				//repeat 5	
	"REPEAT FLD",
	"REPEAT ALL",
	"RANDOM",
	"RETURN",

	"NORMAL",				//eq 7
	"ROCK",
	 "POP ", 
	 "CLASSIC",
	 "BASS",
	 "SOFT",
	 "RETURN",
	 
	"5 S",				//BlackLight 6
	"15 S",
	"30 S",
	"60 S",
	"LIGHT",
	"RETURN",

	"����",			//Language  3
	"ENGLISH",
	"RETURN",

	"NO LINK",				// Reader 1

	"V1.02",					//Versions 1

	"YES?",				// Recover 2
	"NO?",
	
};

char MenuAllText_CH[][11] =
{
	"������",			//select dev 6
	"SD��",
	"U��",
	"USB ����",
	"��·����",
	"����",

	"����",			// Sys Set 6
	"����",
	"������",
	"�����汾",
	"��������",
	"����",

	"ͨ��", 			//Area selec	
	"ȫ��",
	"����",

	"����ѭ��",				//repeat	
	"Ŀ¼ѭ��",
	"ȫ��ѭ��",
	"�������",
	"����",

	"��׼",				//eq
	"ҡ��",
	 "����", 
	 "�ŵ�",
	 "����",
	 "���",
	 "����",
	 
	"5 ��",				//BlackLight 6
	"15 ��",
	"30 ��",
	"60 ��",
	"����",
	"����",
					
	"����",	//Language  3
	"ENGLISH",
	"����",

	"û������",				// Reader 1

	"V1.02",					//Versions

	"��?",				// Recover
	"��?",	
};
#else
char MenuAllText[10][7][11] =
{
 {	{"FM"},			//select dev 6
	{"SD"},
	{"USB disk"},
	{"USB Audio"},
	{"AUX"},
	{"Return"},
 },

 {
	{"BlackLight"},			// Sys Set 6
	{"Language"},
	{"Reader"},
	{"Versions"},
	{"Recover"},
	{"Return"},
 },
{
	{"Norm band"}, 			//Area selec 3	
	{"All band"},
	{"Return"},
},
{
	{"ONE"},				//repeat 5
	{"RANDOM"},
	{"FOLD"},
	{"ALL"},
	{"Return"},
},
{
	{"NORM"},				//eq 7
	{"ROCK"},
	{ "POP "}, 
	{ "CLAS"},
	 {"BASS"},
	 {"SOFT"},
	 {"Return"},
},
{
	{"5 S"},				//BlackLight 6
	{"15 S"},
	{"30 S"},
	{"60 S"},
	{"Light"},
	{"Return"},
},
{
	{"English"},				//Language  3
	{"����"},
	{"Return"},
},
{
	{"No Link"},				// Reader 1
},
{
	{"F0012"},					//Versions 1
},
{
	{"Yes?"},				// Recover 2
	{"No?"},
},	
	
};

char MenuAllText_CH[10][7][11] =
{
{
	{"������"},			//select dev 6
	{"SD��"},
	{"U��"},
	{"USB ����"},
	{"��·����"},
	{"����"},
},
{
	{"����"},			// Sys Set 6
	{"����"},
	{"������"},
	{"�����汾"},
	{"�ָ�"},
	{"����"},
		},
		{
	{"ͨ��"}, 			//Area selec	
	{"ȫ��"},
	{"����"},
		},
		{
	{"����ѭ��"},				//repeat
	{"�������"},
	{"Ŀ¼ѭ��"},
	{"ȫ��ѭ��"},
	{"����"},
		},
		{
	{"��׼"},				//eq
	{"ҡ��"},
	 {"����"}, 
	 {"�ŵ�"},
	 {"����"},
	 {"���"},
	 {"����"},
		},
		{
	{"5 ��"},				//BlackLight 6
	{"15 ��"},
	{"30 ��"},
	{"60 ��"},
	{"����"},
	{"����"},
		},
		{
	{"English"},				//Language  3
	{"����"},
	{"����"},
		},
		{
	{"û������"},				// Reader 1
		},
		{
	{"F0012"},					//Versions
		},
		{
	{"��?"},				// Recover
	{"��?"},
		},
	
};


#endif
//================================
#if 0
BYTE CODE MenuSub[][11] = {"BlackLight", "Language", "Versions", "Recover"};
BYTE CODE MenuSub_CH[][9] = {"����", "����", "�����汾", "�ָ�"};

BYTE CODE RepeatName[][5] = {"ALL",  "ONE", "FOLD"};
BYTE CODE RepeatName_CH[][7] = {"ȫ��",  "����", "�ļ���"};

BYTE CODE Menu_Repeat[7] = {"REPEAT"};
BYTE CODE Menu_Repeat_CH[5] = {"�ظ�"};

BYTE CODE EqName_CH[][6] = {"��׼", "ҡ��", "����", "�ŵ�", "��ʿ", "����", "���", "���", "���", "����", "BLUE"};
BYTE CODE EqName[][5] = {"NORM", "ROCK", "POP ", "CLAS", "JAZZ", "BASS", "SOFT", "COUN", "OPER", "HALL", "BLUE"};

BYTE CODE FmMuneName[][12] = {"Full scan", "Auto scan", "Step scan", "Manual save","Area selec"};
BYTE CODE FmMuneName_CH[][9] = {"ȫƵ��̨", "�Զ���̨", "������̨","�ֶ���̨", "����ѡ��"};

BYTE CODE FmMuneArea[][10] = {"Norm band", "Japan", "All band"};
BYTE CODE FmMuneArea_CH[][9] = {"ͨ��Ƶ��", "�ձ�", "ȫ��"};
#endif

WINDOWS win = {0,0,128,64};
BOOL RtcSetFlash;
FILENAMEDOT filename[40];

#if 0
#ifdef FUNC_LONG_NAME_EN
char *UncodeToGbk(unsigned char *str,char *p)
{
	char i;
	for(i = 0; i< 33; i++)
		{
		if(*str == 0)
			break;
		if(*str  > 0x7f)
			*p = 0x24;
		else
			*p = *str;
		p++;
		str ++;
		str ++;
		}
	*p = 0;
	return p;
}
#endif
#endif
void Show2312String(BYTE *String,POSITION point,BOOL Mode)
{	
	//char Length = 16;
	BYTE *p;
	WORD temp;
	p = String;
	while(/*(*p != 0x20)&&*/(*p)&&(Length2312))
		{
		
		if((*p) < 0x7f)
			{
			GetAsciiChar(*p);	

			#if 0
			if(gSys.SystemMode == SYS_MODE_READER )
				{
				for(i = 0; i <16;i++)
					{
					YcDBG(("*GlypBuff:%X\n", (WORD)font.DotBuffer[i]));
					}
				}
			#endif
			}
		else
			{
			((BYTE *)&temp)[1] = *p;
			//YcDBG(("temp[1]:%X\n", (WORD)*p));
			p++;			
			((BYTE *)&temp)[0] = *p;
			//YcDBG(("temp[0]:%X\n", (WORD)temp));
			
			GetGB2312Char(temp);
			Length2312--;
			
			}	
		 win.x = point.x;
                 win.y = point.y;
                 win.w = font.x;
                 win.h = font.y;
                  
		Lcd_Update_Win(&font.DotBuffer[0],win,Mode);
		point.x+= font.x;		
		if(point.x >128)
			break;

		p++;
		Length2312--;
		
		}
	//YcDBG(("*Length:%X\n", (WORD)Length));
	Length2312 = 16;
		  
}


#if 0
void ShowCloseLogo(void)
{
#if 0
                 win.x = 0;
                 win.y = 16;
                 win.w = 128;
                 win.h = 32;
	Lcd_Update_Win(Close_Logo_Byebye,win,0);
#endif
                 win.x = 0;
                 win.y = 16;
                 win.w = 128;
                 win.h = 64;
	Lcd_ClearScreen(win);
	DispBuf[0] = 'b';
	DispBuf[1] = 'y';
	DispBuf[2] = 'e';
	DispBuf[3] = ' ';
	DispBuf[4] = 'b';
	DispBuf[5] = 'y';
	DispBuf[6] = 'e';
	DispBuf[7] = 0x00;	//
		point.x = 36;
		point.y = 16;
		ShowString(DispBuf,point);
}
#endif

void ShowUnicodeChar(WORD c,POSITION point)
{
	char *p;
	
	if(c < 0x0100)
	GetAsciiChar((BYTE)c);	
	else	
	GetUnicodeChar(c);
	#if 0
	offset = c;
	if(offset > 0x7f)	//��֧������
		offset = 0x24;	//������$ 
	else if(offset < 0x20)
		offset = 0x21;	//������$ 
		win.x = point.x;
                 win.y = point.y;
                 win.w = 8;
                 win.h = 16;
                 p+=  ((offset-0x20)*charw*charh/8);
	#endif
		   win.x = point.x;
                 win.y = point.y;
                 win.w = font.x;
                 win.h = font.y;
                 p=  font.DotBuffer;
	Lcd_Update_Win(p,win,0);
}


#if 0
void ShowChar(char c,POSITION point)
{
	char *p = ASCII168;
	WORD offset;
	offset = c;
	if(offset > 0x7f)	//��֧������
		offset = 0x24;	//������$ 
	else if(offset < 0x20)
		offset = 0x21;	//������$ 
	win.x = point.x;
                 win.y = point.y;
                 win.w = 8;
                 win.h = 16;
                 p+=  ((offset-0x20)*charw*charh/8);
	Lcd_Update_Win(p,win,1);
}


void ShowString(char *string,POSITION point)
{
	//while(!(( *string == '\n')||( *string)))
	char Length = 16;
	while((*string)&&(Length))
	{
		ShowChar(*string,point);
		string++;
		Length --;
		point.x+=8;
	}
}
#endif

void ShowUnicodeString(char *string,POSITION point)
{
	WORD dcode;
	char Length = 16;
	((BYTE *)&dcode)[0] = string[1];
	((BYTE *)&dcode)[1] = string[0];
	while((dcode)&&(Length))
	{
		//DBG(("*dcode:%X\n", (WORD)dcode));
		ShowUnicodeChar(dcode,point);
		string++;
		string++;
		Length --;
		point.x+= font.x;
		((BYTE *)&dcode)[0] = string[1];
		((BYTE *)&dcode)[1] = string[0];
		
		if(point.x >112)
			break;
	}
}



 #if 1
void ShowIcon(char icon_id,POSITION point)
{
	char *p = ICON168;
	WORD offset = icon_id;
		   win.x = point.x;
                 win.y = point.y;
                 win.w = 8;
                 win.h = 16;
                 p += (offset*16);
		Lcd_Update_Win(p,win,0);
}

 void ShowIcon1616(char icon_id,POSITION point)
{
	char *p = ICON1616;
	WORD offset = icon_id;
		   win.x = point.x;
                 win.y = point.y;
                 win.w = 16;
                 win.h = 16;
                 p += (offset*32);
		Lcd_Update_Win(p,win,0);
}

void ShowIcon3248(void)
{
		char *p = ICON3248;	
		   win.x = 0;
                 win.y = 8;
                 win.w = 32;
                 win.h = 48;                           
		Lcd_Update_Win(p,win,0);
}


void ShowIcon12832(char icon_id,POSITION point)
{
		char *p = ICON12832;
	WORD offset = icon_id;
		   win.x = point.x;
                 win.y = point.y;
                 win.w = 128;
                 win.h = 32;
                 p += (offset*512);             
		Lcd_Update_Win(p,win,0);
}

void ShowIcon3232(char icon_id,POSITION point)
{
		char *p = ICON3232;
	WORD offset = icon_id;
		   win.x = point.x;
                 win.y = point.y;
                 win.w = 32;
                 win.h = 32;
                 p += (offset*128);             
		Lcd_Update_Win(p,win,0);
}

void ShowOpenLogo(void)
{
#if 0
  		point.x = 34;
		point.y = 24;
		//ShowString(DispBuf,point);

			
		if(Language)
			Show2312String("������", point);
			//Show2312String("ڦ ڧ ڨ", point);
		else
			Show2312String("EDIFIER", point);
#else
		ClearScreen();
		point.x = 0;
		point.y = 16;
		ShowIcon12832(BID_12832_EDIFIER,point);
#endif
}

void ShowBatteryIcon()
{

	char *p ;	
	WORD level;
	static BOOL BattFlash = FALSE;
	static BYTE AnLevel = 1;
	static BYTE CheckNum = 10;
	static BYTE offset = 5;
	//	  level = GetVinVoltage();

	level = GetVinVoltage();		//AdcReadOneChannel(ADC_CHANNEL_C0, ADC_VREF_AVDD33);

	p= ICON1616;

	if(Isrecharging)
		{
			
			{
				if(AnLevel++ >= 5)
				AnLevel = 0;
				offset = AnLevel;				
			}
			BattFlash = TRUE;
		}
	else
		{
		CheckNum ++;
		if(CheckNum > 10)
			CheckNum = 0;
		if(level > 4000)			// >4.2V
			{
			
			if(offset != 5)
				{
				BattFlash ^= 1;
				if(CheckNum == 0)
					offset = 5;
				}
			else
				CheckNum = 0;
			}
		else if(level > 3800)		// >4.0V
			{
			if(offset != 4)
				{
				BattFlash ^= 1;
				if(CheckNum == 0)
					offset = 4;
				}
			else
				CheckNum = 0;
			}
		else if(level > 3600)		// >3.7V
			{
			if(offset != 3)
				{
				BattFlash ^= 1;
				if(CheckNum == 0)
					offset = 3;
				}
			else
				CheckNum = 0;
			}
		else if(level > 3400)		// >3.5V
			{
			if(offset != 2)
				{
				BattFlash ^= 1;
				if(CheckNum == 0)
					offset = 2;
				}
			else
				CheckNum = 0;
			}
		else if(level > 3200)		// >3.4V
			{
			if(offset != 1)
				{
				BattFlash ^= 1;
				if(CheckNum == 0)
					offset = 1;
				}
			else
				CheckNum = 0;
			}
		else
			{
			{
			if(offset != 0)
				{
				if(CheckNum == 0)
					offset = 0;
				}
			else
				{
				BattFlash ^= 1;
				CheckNum = 0;
				}
			}
			//offset = 0;		// <3.4V
			
			}
		
		//SetGpioRegBit(POWER_LED_PORT_OUT, POWER_LED_BIT);
		}
		if((offset) || BattFlash)
			{
		   win.x = 108;
                 win.y = 0;
                 win.w = 16;
                 win.h = 16;
                 p += (offset*32);
		Lcd_Update_Win(p,win,0);
			}
		#if 1
		else if((offset == 0) && (!BattFlash))
			{
			win.x = 108;
			win.y = 0;
			win.w = 16;
			win.h = 16;
			Lcd_ClearScreen(win);
			}
		#endif
		

}
 
 #endif


#ifdef	FUNC_RTC_EN
extern SYSRTCDATETIME gRtcTime;
void ShowRtc(void)
 {
	BYTE rtcbuffer[8];
	
 		point.x = 85-8;				//��ʾ�ļ���
		point.y = 48;
		ShowIcon(BID_CLOCK_ICON,point);
	
		rtcbuffer[0] = gRtcTime.Hour/10 + 0X30; 
		rtcbuffer[1] = gRtcTime.Hour%10 + 0X30; 
		rtcbuffer[2] = ':'; 
		rtcbuffer[3] = gRtcTime.Min/10 + 0X30 ; 
		rtcbuffer[4] = gRtcTime.Min%10 + 0X30; 
		rtcbuffer[5] = 0;
		
 		point.x = 85;				//��ʾ�ļ���
		point.y = 48;
    		Show2312String(rtcbuffer, point,0);
 }
#else
void ShowRtc(void)
{}
#endif
#if 0
void ShowErrorMessage(void)
 	{
                 win.x = 0;
                 win.y = 0;
                 win.w = 128;
                 win.h = 64;
	Lcd_ClearScreen(win);
	//if(gSys.FsCtrl.Error == FS_ERROR_NO_FILE)
		{
		DispBuf[0] = 'N';
		DispBuf[1] = '0';
		DispBuf[2] = ' ';
		DispBuf[3] = 'F';
		DispBuf[4] = 'i';
		DispBuf[5] = 'l';
		DispBuf[6] = 'e';
		DispBuf[7] = '!';
		DispBuf[8] = 0x00;	//
		point.x = 36;
		point.y = 16;
		ShowString(DispBuf,point);
		}
 	}
#endif
//#ifdef FUNC_LRC_EN
#if 0
VOID ShowLryicString(BYTE * LrcBuffer,char Length)
{
	BYTE *p,i;
	WINDOWS Lrywin;
	WORD temp;
	//char UnicodeBuffer[64];
		   win.x =0;
                 win.y = 16;
                 win.w = 128;
                 win.h = 48;
		   Lcd_ClearScreen(win);
		p = LrcBuffer;
		point.x = 0;
		point.y = 32;
		Lrywin.x = 0;
		Lrywin.y = 16;
		Lrywin.w = 16;
		Lrywin.h = 16;
		i = 0;
	while((*p)&&(Length))
		{
		if((*p) < 0x7f)
			{
			GetAsciiChar(*p);
			Lrywin.w = 8;
			if(Lrywin.x+Lrywin.w > 128)
			{
			Lrywin.x = 0;
			Lrywin.y +=16;
			}
			Lcd_Update_Win(&font.DotBuffer[0],Lrywin,0);
			Lrywin.x += 8;
			temp = *p;
			DBG(("*p:%X\n", temp));
			}
		else
			{
			((BYTE *)&temp)[1] = *p;
			p++;
			Length--;
			((BYTE *)&temp)[0] = *p;
			Lrywin.w = 16;
			if(Lrywin.x+Lrywin.w > 128)
			{
			Lrywin.x = 0;
			Lrywin.y +=16;
			}
			GetGB2312Char(temp);
			Lcd_Update_Win(&font.DotBuffer[0],Lrywin,0);
			//DBG(("*temp:%X\n", temp));
			Lrywin.x += 16;
			}
		if(Lrywin.x > 128)
		{
		Lrywin.x = 0;
		Lrywin.y +=16;
		}
		p++;
		i++;
		Length--;

		if(gPlayCtrl.State == PLAY_STATE_PLAY)
			{
				SongPlayDo();
			}
		}
		
}
#endif

VOID ShowDotToLcm(POSITION point)
{
		char i;
		   win.x = point.x;
                 win.y = point.y;
                 win.w = filename[CurrP].x;
                 win.h = 16;
			i = CurrP;	 
	while(((win.x + win.w)<= 128)&&(filename[i].ucode))
		{
		Lcd_Update_Win(&filename[i].dot[0],win,0);
		win.x +=filename[i].x;
		i++;
		win.w = filename[i].x;
		}
		if(win.x <= 120)
			{
			point.x = 119; // win.x;
			Show2312String(" ",point,0);
			}
		if(filename[i].ucode)
			CurrP++;
		else
			{
			if(!LrcScroll)
				CurrP = 0;		// ���ļ���ʱ����ѭ����ʾ
			}
}

#ifdef FUNC_LRC_EN
VOID ShowLryicScroInit(BYTE * LrcBuffer,char Length)
{
	extern BYTE PlayDispSta;
	BYTE *p,i,j;	
	WORD temp;
	WORD LengthLrc = 0;
	
		p = LrcBuffer;
		point.x = 0;
		point.y = 32;		
		i = 0;
	while((*p)&&(Length))
		{
		if((*p) < 0x7f)
			{
			GetAsciiChar(*p);
			filename[i].ucode = *p;
			filename[i].x =  font.x ;
			filename[i].y =  font.y ;
			for(j = 0; j < 16; j++)
				filename[i].dot[j] = font.DotBuffer[j];
			temp = *p;
			DBG(("*p:%X\n", temp));
			}
		else
			{
			((BYTE *)&temp)[1] = *p;
			p++;
			Length--;
			((BYTE *)&temp)[0] = *p;
			
			GetGB2312Char(temp);
			filename[i].ucode = temp;
			filename[i].x =  font.x ;
			filename[i].y =  font.y ;
			for(j = 0; j < 32; j++)
				filename[i].dot[j] = font.DotBuffer[j];
			}
		
		p++;
		i++;
		Length--;

		LengthLrc += font.x;
		
		}
#if 0 //lxl comment 7-19
	if (!DispSysMenu)
		{
		filename[i].ucode = 0;
		win.x = 0;
		win.y = 32;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);		
		
		//TotalSize = Length;
		CurrSize = 0;
		CurrP = 0;
		point.x = 0;				//��ʾ�ļ���
		point.y = 32;

		ShowDotToLcm(point);
		}
#endif
		NeedScroll =FALSE;
		if(LengthLrc > 128)
			NeedScroll =TRUE;
		LrcScroll = TRUE;
	TimeOutSet(&DispScroTime,700);
		
}
#endif


VOID ShowShortNameFile(VOID)
{
		char *p,i,j = 0;
		char shortnamebuffer[13];
		char tempbuff[13] ="zhangxy98com";
		p = gPlayCtrl.File.ShortName;
		for(i = 0 ; i< 12 ; i++)
			{
			if(*p != 0x20)
				{
				shortnamebuffer[j] = *p;
				j++;
				}
			if(i == 7)
				{
				shortnamebuffer[j] = 0x2e;
				j++;
				}
			p++;
			}	
		shortnamebuffer[j] = 0;
		win.x = 0;
		win.y = 32;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);
		
		point.x = 0;				//��ʾ�ļ���
		point.y = 32;
    		Show2312String(shortnamebuffer, point,0);
		NeedScroll =FALSE;	
		//YcDBG(("Show Long FileName\n"));
}

void ScrollScreenInit(void)
{
		char *p,i,j;
		WORD dcode;
		WORD Length = 0;
		//{
			BYTE LongFileName[66];	 
			BOOL Ret;	
			Ret = FileGetLongName(&gPlayCtrl.File, LongFileName);		
		//}
		//
		
		p = LongFileName;
		i = 0;
		
		do 
		{
		((BYTE *)&dcode)[1] = *p;
		p++;
		((BYTE *)&dcode)[0] = *p;
		p++;
		
		DBG(("*dcode:%X\n", (WORD)dcode));
		
		if(dcode < 0x0100)
		GetAsciiChar((BYTE)dcode);	
		else	
		GetUnicodeChar(dcode);
		
		filename[i].ucode = dcode;
		filename[i].x =  font.x ;
		filename[i].y =  font.y ;
		for(j = 0; j < 32; j++)
			filename[i].dot[j] = font.DotBuffer[j];

		Length += font.x;
		i++;
	      }
		while((dcode)&&(i <39));


			
		//win.x = 0;
		//win.y = 32;
		//win.w = 128;
		//win.h = 16;
		//Lcd_ClearScreen(win);
		
		NeedScroll =FALSE;
		//TotalSize = Length;
		CurrSize = 0;
		CurrP = 0;
		//point.x = 0;				//��ʾ�ļ���
		//point.y = 32;

		//ShowDotToLcm(point);
		

		if(Length > 128)
			NeedScroll =TRUE;
		LrcScroll = FALSE;
		TimeOutSet(&DispScroTime,700);
}

void ShowLongFileName(void)
{
		win.x = 0;
		win.y = 32;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);
		point.x = 0;				//��ʾ�ļ���
		point.y = 32;

		ShowDotToLcm(point);
		DBG(("Show Long FileName\n"));
}
void Mp3ScrollScreen(void)
{
	if((NeedScroll)&&(gPlayCtrl.State == PLAY_STATE_PLAY))
		{
		//win.x = 0;
		//win.y = 32;
		//win.w = 128;
		//win.h = 16;
		//Lcd_ClearScreen(win);
		point.x = 0;				//��ʾ�ļ���
		point.y = 32;
		ShowDotToLcm(point);
		DBG(("LRC MOVE\n"));
		}
}
#if 1
void LcdMp3SelSong(void)
{
	unsigned int temp;
#ifdef FUNC_NUMBER_SEL_EN
		temp = gNumber.Result;
#endif

	//if(gNumber.Result > 1000)
	//	temp = gNumber.Result%1000;
	DispBuf[0] = 'N';
	DispBuf[1] = 'U';
	DispBuf[2] = 'M';
	DispBuf[3] = ':';
	
	DispBuf[4] = temp/100+0x30;
	temp = temp%100;
	DispBuf[5] = temp/10+0x30;
	DispBuf[6] = temp%10+0x30;

	DispBuf[7] = 0x00;	//
		point.x = 24;
		point.y = 48;
		ShowString(DispBuf,point);
}


void LcdMp3SelFolder(void)
{
	unsigned int temp;
		temp =  gSys.FsCtrl.Folder.CurrNum;
	if(gSys.FsCtrl.Folder.CurrNum > 1000)
		temp = gSys.FsCtrl.Folder.CurrNum%1000;

	DispBuf[0] = 'F';
	DispBuf[1] = 'O';
	DispBuf[2] = 'L';
	DispBuf[3] = ':';
	DispBuf[4] = temp/100+0x30;
	temp = temp%100;
	DispBuf[5] = temp/10+0x30;
	DispBuf[6] = temp%10+0x30;

	DispBuf[7] = 0x00;	//
		point.x = 24;
		point.y = 48;
		ShowString(DispBuf,point);	
}
#endif
void LcdMp3FileNumber(void)
{
		unsigned int temp;
		DispBuf[0] = 'P';
		DispBuf[1] = 'L';
		DispBuf[2] = 'A';
		DispBuf[3] = 'Y';	
		DispBuf[4] = ':';
		DispBuf[5] = 0x00;	//
		point.x = 0;
		point.y = 32;
		Show2312String(DispBuf,point,0);
		//YcDBG(("Show gPlayCtrl.FileNum: %d\n", (WORD)gPlayCtrl.FileNum));
		temp = gPlayCtrl.FileNum %10000; 
		DispBuf[0] = temp/1000+0x30;
		temp = temp%1000;
		
		DispBuf[1] = temp/100+0x30;
		temp = temp%100;
		DispBuf[2] = temp/10+0x30;
		DispBuf[3] = temp%10+0x30;
		DispBuf[4] = '/';

#ifdef	FUNC_FOLDER_EN	
//		temp = gPlayCtrl.Folder.IncFileCnt % 10000;
#else
//		temp = gFsInfo.FileSum %10000;
#endif	
#if 0	//lxl comment 7-19
		if(gPlayCtrl.RepeatMode==PLAY_MODE_REPEAT_FOLDER)
			temp = gPlayCtrl.Folder.IncFileCnt % 10000;
		else
	 #endif
			temp = gFsInfo.FileSum %10000;
			
		DispBuf[5] = temp/1000+0x30;
		temp = temp%1000;
		DispBuf[6] = temp/100+0x30;
		temp = temp%100;
		DispBuf[7] = temp/10+0x30;
		DispBuf[8] = temp%10+0x30;
		DispBuf[9] = 0;

		
		point.x = 40;
		point.y = 32;
		Show2312String(DispBuf,point,0);

		win.x = 112;
		win.y = 32;
		win.w = 15;
		win.h = 16;
		Lcd_ClearScreen(win);
}
#if 0
LcdMp3Loading()
{
	DispBuf[0] = 'L';
	DispBuf[1] = 'o';
	DispBuf[2] = 'a';
	DispBuf[3] = 'd';
	DispBuf[4] = 'i';
	DispBuf[5] = 'n';
	DispBuf[6] = 'g';
	DispBuf[7] = 0x00;	//
		point.x = 36;
		point.y = 16;
		ShowString(DispBuf,point);	
}
#endif

void ClearScreen(void)
{
		win.x = 0;
		win.y = 0;
		win.w = 128;
		win.h = 64;
		Lcd_ClearScreen(win);
}

#if 1
void ShowSysMenu(BYTE MENU_ID)
{
		
		point.x = 0;
		point.y = 16;
		ShowIcon3232(MENU_ID,point);
		
		//ShowIcon3232(MENU_EQ_ICON,point);
		//YcDBG(("ShowMenu MENU_ID: %d\n", (WORD)MENU_ID));

		win.x = 24;
		win.y = 0;
		win.w = 80;
		win.h = 16;
		Lcd_ClearScreen(win);
		if(Language)
			{
		if(MENU_ID == 3)			
			point.x = 32;		
		else 
			point.x = 48;
			}
		else
			{
		if(MENU_ID == 1)			
			point.x = 24;
		else if(MENU_ID == 4)	
			point.x = 44;
		else 
			point.x = 32;
			}
		point.y = 0;	
		if(Language)
			Show2312String(&MenuSub_CH[MENU_ID-1][0],point,1);
		else
			Show2312String(&MenuSub[MENU_ID-1][0],point,1);
		ShowSysMenuSub(MENU_ID);
}

void ShowSysMenuSub(BYTE MENU_ID)
{
	extern DWORD SetBlackTime;	
	
	BYTE temp;
	
	BYTE CODE MENU_VERSIONS[10] = {"VER: F011"};
		
		win.x = 50;
		win.y = 32;
		win.w = 80;
		win.h = 16;
		Lcd_ClearScreen(win);

		point.x = 50;
		point.y = 32;	
		switch(MENU_ID)
			{
			case 1:
				if(SetBlackTime == 100)
					{
					if(Language)
						Show2312String("����",point,0);
					else
						Show2312String("Light",point,0);
					}
				else
					{
				temp = (BYTE)(SetBlackTime / 1000);
				if(temp < 10)
					DispBuf[0] = ' ';
				else
					DispBuf[0] = temp/10+0x30;
				DispBuf[1] = temp%10+0x30;
				DispBuf[2] = ' ';
				DispBuf[3] = 'S';
				DispBuf[4] = 0;

				//point.x = 50;
				//point.y = 32;				
				Show2312String(DispBuf,point,0);
				//YcDBG(("Show SetBlackTime: %d\n", (WORD)SetBlackTime));	
					}
				break;
			case 2:
				//point.x = 50;
				//point.y = 32;	
				if(Language)
					Show2312String("����",point,0);
				else
					Show2312String("English",point,0);
				//point.x = 32;				
				break;
			case 3:
				//point.x = 50;
				//point.y = 32;				
				Show2312String(MENU_VERSIONS,point,0);
				//point.x = 32;				
				break;
			case 4:
				//point.x = 50;
				//point.y = 32;				
				if(YesFlag)
					Show2312String("Yes?",point,0);
				else
					Show2312String("No?",point,0);
					
				//point.x = 44;				
				break;

			}
		
}

void ShowMenuRepeatVal(void)
{
		
		win.x = 40;
		win.y = 32;
		win.w = 48;
		win.h = 16;
		Lcd_ClearScreen(win);
		point.x = 40;
		point.y = 32;	
		if(Language)
			{
			Show2312String(&RepeatName_CH[gPlayCtrl.RepeatMode][0],point,0);
			//DispBuf[0] = 0xc1;
			//DispBuf[1] = 0xf5;
			//DispBuf[2] = 0xc0;			
			//DispBuf[3] =0xc0;
			//DispBuf[4] = 0;
			//Show2312String(DispBuf,point);
			}
		else
			Show2312String(&RepeatName[gPlayCtrl.RepeatMode][0],point,0);
		
}
void ShowMenuRepeat(void)
{
		ClearScreen();	
		
		
		point.y = 0;
		if(Language)
			{
			point.x = 48;
			Show2312String(Menu_Repeat_CH,point,0);
			}
		else
			{
			point.x = 40;
			Show2312String(Menu_Repeat,point,0);
			}
		
		point.x = 0;
		point.y = 16;
		ShowIcon3232(MENU_REP_ICON,point);
		ShowMenuRepeatVal();
}

void ShowMenuEQVal(void)
{
	
		win.x = 40;
		win.y = 32;
		win.w = 40;
		win.h = 16;
		Lcd_ClearScreen(win);
		point.x = 40;
		point.y = 32;	
		if(Language)
			Show2312String(&EqName_CH[gPlayCtrl.Eq][0],point,0);			
		else
			Show2312String(&EqName[gPlayCtrl.Eq][0],point,0);	
			
}

void ShowMenuEQ(void)
{
		ClearScreen();		
		point.x = 61;
		point.y = 0;
		Show2312String("EQ",point,0);
		
		point.x = 0;
		point.y = 16;
		ShowIcon3232(MENU_EQ_ICON,point);
		ShowMenuEQVal();
}
#endif
/********************************************************
Function:�˵���ʾ
Input:	MenuLeve,��ʾ�Ĳ˵��Line��ѡ�����(������ʾ)
		StartLine,��ʾ���ݵĿ�ʼ��
Output:
Description:

*********************************************************/

void ShowMenu(icon_3232_t MenuLeve,BYTE Line,BYTE StartLine)
{
	BOOL Line1 = FALSE;
	BOOL Line2 = FALSE;
	BOOL Line3 = FALSE;
	BYTE *p1,*p2,*p3;
	BYTE i,Num = 0;
	BYTE StartNum = StartLine;
	if(Line == 1)
		Line1 = TRUE;
	else if(Line == 2)
		Line2 = TRUE;
	else
		Line3 = TRUE;
	
	ClearScreen();

	ShowIcon3248();
	point.x = 0;
	point.y = 16;
	ShowIcon3232((MenuLeve ),point);
	if(MenuLeve == MENU_DIR_ICON)
		return;
#if 0
	point.x = 32;
	point.y = 0;
	if(Language)
		Show2312String(&MenuInterfaceText_CH[MenuLeve][0],point,0);
	else
		Show2312String(&MenuInterfaceText[MenuLeve][0],point,0);
#endif	
	switch(MenuLeve)
		{
		case MENU_SYSTEM_ICON:
			
			switch(gSys.SystemMode)
			{
				case SYS_MODE_USB:
				case SYS_MODE_SD:
					#if 0
					if(Language)
						{
						p1 = &MenuMp3Text_CH[StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuMp3Text_CH[StartNum][0];
						if(StartNum==5)
							p3 = &MenuMp3Text_CH[0][0];
						else
							p3 = &MenuMp3Text_CH[StartNum + 1][0];
						}
					else
						{
						p1 = &MenuMp3Text[StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuMp3Text[StartNum][0];
						if(StartNum==5)
							p3 = &MenuMp3Text[0][0];
						else
						p3 = &MenuMp3Text[StartNum + 1][0];
						}
					#else
					{
						p1 = &MenuMp3Text[Language][StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuMp3Text[Language][StartNum][0];
						if(StartNum==5)
							p3 = &MenuMp3Text[Language][0][0];
						else
						p3 = &MenuMp3Text[Language][StartNum + 1][0];
						}
					#endif
					break;
				case SYS_MODE_RADIO:
					#if 0
					if(Language)
						{
						p1 = &MenuFmText_CH[StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuFmText_CH[StartNum][0];
						if(StartNum==5)
							p3 = &MenuFmText_CH[0][0];
						else
						p3 = &MenuFmText_CH[StartNum + 1][0];
						}
					else
						{
						p1 = &MenuFmText[StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuFmText[StartNum][0];
						if(StartNum==5)
							p3 = &MenuFmText[0][0];
						else
						p3 = &MenuFmText[StartNum + 1][0];
						}
					#else
					{
						p1 = &MenuFmText[Language][StartNum-1][0];
						if(StartNum==6)
							StartNum = 0;
						p2 = &MenuFmText[Language][StartNum][0];
						if(StartNum==5)
							p3 = &MenuFmText[Language][0][0];
						else
						p3 = &MenuFmText[Language][StartNum + 1][0];
						}
					#endif
					break;
				case SYS_MODE_LINEIN:
					#if 0
					if(Language)
						{
						p1 = &MenuAuxText_CH[StartNum-1][0];
						if(StartNum==3)
							StartNum = 0;
						p2 = &MenuAuxText_CH[StartNum][0];
						if(StartNum==2)
							p3 = &MenuAuxText_CH[0][0];
						else
						p3 = &MenuAuxText_CH[StartNum + 1][0];
						}
					else
						{
						p1 = &MenuAuxText[StartNum-1][0];
						if(StartNum==3)
							StartNum = 0;
						p2 = &MenuAuxText[StartNum][0];
						if(StartNum==2)
							p3 = &MenuAuxText[0][0];
						else
						p3 = &MenuAuxText[StartNum + 1][0];
						}
					#else
					{
						p1 = &MenuAuxText[Language][StartNum-1][0];
						if(StartNum==3)
							StartNum = 0;
						p2 = &MenuAuxText[Language][StartNum][0];
						if(StartNum==2)
							p3 = &MenuAuxText[Language][0][0];
						else
						p3 = &MenuAuxText[Language][StartNum + 1][0];
						}
					#endif
					break;
				case SYS_MODE_AUDIO:
					#if 0
					if(Language)
						{
						p1 = &MenuAudioText_CH[StartNum-1][0];
						if(StartNum==4)
							StartNum = 0;
						p2 = &MenuAudioText_CH[StartNum][0];
						if(StartNum==3)
							p3 = &MenuAudioText_CH[0][0];
						else
						p3 = &MenuAudioText_CH[StartNum + 1][0];
						}
					else
						{
						p1 = &MenuAudioText[StartNum-1][0];
						if(StartNum==4)
							StartNum = 0;
						p2 = &MenuAudioText[StartNum][0];
						if(StartNum==3)
							p3 = &MenuAudioText[0][0];
						else
						p3 = &MenuAudioText[StartNum + 1][0];
						}
					#else
					{
						p1 = &MenuAudioText[Language][StartNum-1][0];
						if(StartNum==4)
							StartNum = 0;
						p2 = &MenuAudioText[Language][StartNum][0];
						if(StartNum==3)
							p3 = &MenuAudioText[Language][0][0];
						else
						p3 = &MenuAudioText[Language][StartNum + 1][0];
						}
					#endif
					break;

				default:
					break;

			}
			break;
			
		//case MENU_SELECT_ICON:
		//	break;

		default:
			#if 1
			{
				
			for(i = 0;i < MenuLeve;i++)
				{
				Num +=MenuAddr[i];
				}
			}
			Num += StartLine ; 
			if(Language)
				{
					p1 = &MenuAllText_CH[Num-1][0];
					if(StartNum==MenuAddr[MenuLeve])
						Num -= MenuAddr[MenuLeve];
					p2 = &MenuAllText_CH[Num][0];
					if(StartNum==(MenuAddr[MenuLeve]-1))
						{
						Num -= StartNum;
						p3 = &MenuAllText_CH[Num][0];
						}
					else
						p3 = &MenuAllText_CH[Num + 1][0];
				}
			else
				{
					p1 = &MenuAllText[Num-1][0];
					if(StartNum==MenuAddr[MenuLeve])
						Num -= MenuAddr[MenuLeve];
					p2 = &MenuAllText[Num][0];
					if(StartNum==(MenuAddr[MenuLeve]-1))
						{
						Num -= StartNum;
						p3 = &MenuAllText[Num][0];
						}
					else
						p3 = &MenuAllText[Num + 1][0];
				}
			#else
			Num = StartLine ; 			
			if(Language)
				{
					p1 = &MenuAllText_CH[MenuLeve-1][Num-1][0];
					p2 = &MenuAllText_CH[MenuLeve-1][Num][0];
					p3 = &MenuAllText_CH[MenuLeve-1][Num + 1][0];
				}
			else
				{
					p1 = &MenuAllText[MenuLeve-1][Num-1][0];
					p2 = &MenuAllText[MenuLeve-1][Num][0];
					p3 = &MenuAllText[MenuLeve-1][Num + 1][0];
				}
			#endif
			break;
		}
#if 1	

	if((MenuLeve == MENU_READER_ICON) || (MenuLeve == MENU_VERSIONS_ICON))
		{
		point.x = 40;
		point.y = 8;
		Show2312String(p1,point,1);	//Line 1
		}
	else if(MenuLeve == MENU_RESET_ICON)
		{
		point.x = 40;
		point.y = 16;
		if(Language)
			{
			p1 = &MenuAllText_CH[38][0];
			p2 = &MenuAllText_CH[39][0];
			}
		else
			{
			p1 = &MenuAllText[38][0];
			p2 = &MenuAllText[39][0];
			}
		Show2312String(p1,point,Line1);	//Line 1
		//point.x = 40;
		point.y = 32;
		Show2312String(p2,point,Line2);
		}
	else
	{
		point.x = 40;
		point.y = 8;
		Show2312String(p1,point,Line1);	//Line 1
		//point.x = 40;
		point.y = 24;
		Show2312String(p2,point,Line2);
		//point.x = 40;
		point.y = 40;
		Show2312String(p3,point,Line3);
	}
#endif
}

void ShowNoReadSd(BYTE Type)
{
	ShowDev();	
	ShowBatteryIcon();
	switch(Type)
		{
		case 1:
			point.x = 20;
			point.y = 24;
			if(Language)
				Show2312String("�����SD��",point,0);
			else
				Show2312String("No SD Card!",point,0);
			break;
		case 2:
			point.x = 24;
			point.y = 24;
			if(Language)
				{
				WORD temp;
				Show2312String("������",point,0);
				//Show2312String("������",point,0);
				((BYTE *)&temp)[1] = 0xca;
				((BYTE *)&temp)[0] = 0xfd;
				GetGB2312Char(temp);			
				 win.x = 72;
              			 win.y = 24;
              			 win.w = font.x;
                		 win.h = font.y;                  
				Lcd_Update_Win(&font.DotBuffer[0],win,0);
				((BYTE *)&temp)[1] = 0xbe;
				((BYTE *)&temp)[0] = 0xdd;
				GetGB2312Char(temp);			
				 win.x = 88;
              			 win.y = 24;
              			 win.w = font.x;
                		 win.h = font.y;                  
				Lcd_Update_Win(&font.DotBuffer[0],win,0);
				
				((BYTE *)&temp)[1] = 0xcf;
				((BYTE *)&temp)[0] = 0xdf;
				GetGB2312Char(temp);			
				 win.x = 104;
              			 win.y = 24;
              			 win.w = font.x;
                		 win.h = font.y;                  
				Lcd_Update_Win(&font.DotBuffer[0],win,0);
				}
			else
				Show2312String("No PC Link!",point,0);
			break;
		case 3:
			break;
		}
	
}

void ShowNoDev(void)
{
	
	ClearScreen();
	ShowBatteryIcon();
		switch(gSys.SystemMode)
			{
			case SYS_MODE_USB:
				
				point.x = 16;
				point.y = 24;
				if(Language)
					Show2312String("�����U��",point,0);
				else
					Show2312String("No USB Disk!",point,0);
				break;
			case SYS_MODE_SD:
				
				point.x = 20;
				point.y = 24;
				if(Language)
					Show2312String("�����SD��",point,0);
				else
					Show2312String("No SD Card!",point,0);
				break;
			case SYS_MODE_READER:				
				
				//point.x = 24;
				//point.y = 16;
				//Show2312String("Read Err!",point);
				break;
			case SYS_MODE_AUDIO:				
				ShowAudio();
				break;
				
			}
	
}

void ShowDev(void)
{
		ClearScreen();
		point.x = 0;				//
		point.y = 0;
		//YcDBG(("ShowDev SystemMode: %d\n", (WORD)gSys.SystemMode));
		Show2312String(&DEV_ID_ICON[gSys.SystemMode][0], point,0);
		
}


void ShowVol(void)
{
		BYTE  temp;
		#if 0	//lxl 7-19
		if(PlayDispSta == MP3_DISP_NO_DEV)
			return;
	   #endif
		point.x = 96;
		point.y = 48;
		ShowIcon1616(BID_VOL_ICON,point);
		temp = gSys.Volume;
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x00;	//
		point.x = 112;
		point.y = 48;
		Show2312String(DispBuf,point,0);
		
}

#if 1
void ShowVolBarVal(void)
{
	BYTE  temp;
	BYTE  FillBar[] = {0xf8,0x54,0x04,0xac,0xf8,0x1f,0x35,0x20,0x2a,0x1f};
	BYTE  FillVol_A[] = {0xa0,0x05,};
	BYTE  FillVol_B[] = {0xe0,0x07};
	char *p;
	
	
	if(gSys.Volume)
			{
			for(temp = 0; temp < (gSys.Volume * 86 / 30); temp ++)
				{
				win.x = 21 + temp;
                		win.y = 48;
                		win.w = 1;
               		win.h = 16;    
				if(temp % 2)
					p = FillVol_A;
				else
					p = FillVol_B;
				Lcd_Update_Win(p,win,0);
				}
			}

		 win.x = 20 + (gSys.Volume * 83 / 30);
		 win.y = 48;
               win.w = 5;
               win.h = 16;                          
		Lcd_Update_Win(FillBar,win,0);
		

		temp = gSys.Volume;
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x00;	//
		point.x = 112;
		point.y = 48;
		ShowString(DispBuf,point);
}
#endif
void ShowVolBarCurrVal(void)
{
		BYTE temp,tempa;
		BYTE  FillVol[] = {0x40,0x02};
		BYTE  FillVol_FULL[] = {0xc0,0x03};
		BYTE  FillVol_NED[] = {0x80,0x01};
		BYTE  FillVol_CURR[] = {0xc0,0x60,0x60,0x60,0xe0,0xc0,0x03,0x06,0x06,0x07,0x07,0x03};
		char *p;
		if(CurrVol != gSys.Volume)
			{

			temp = (gSys.Volume * 83 / 30);
			tempa = (CurrVol * 83 / 30);
		if(CurrVol > gSys.Volume)
			{
			
			for(;temp <= (tempa +7);temp++)
				{
			win.x = 20 + temp;
			if(win.x > 108)
				break;
			if((win.x == 20) || (win.x == 108))
				p = FillVol_NED;
			else
				p = FillVol;
			win.y = 48;
              		win.w = 1;
               	win.h = 16;                          
			Lcd_Update_Win(p,win,0);
				}
			}
		else
			{
			for(;tempa < (temp);tempa++)
				{
			win.x = 20 + tempa;
			if((win.x == 20) || (win.x == 108))
				p = FillVol_NED;
			else
				p = FillVol_FULL;
			win.y = 48;
              		win.w = 1;
               	win.h = 16;                          
			Lcd_Update_Win(p,win,0);
				}			
			}
		
			}

		win.x = 20 + (gSys.Volume * 83 / 30);
		 win.y = 48;
               win.w = 6;
               win.h = 16;                          
		Lcd_Update_Win(FillVol_CURR,win,0);

		temp = gSys.Volume;
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x00;	//
		point.x = 112;
		point.y = 48;
		Show2312String(DispBuf,point,0);

}
void ShowSBAR(BOOL MuteFlag)
{
#if 0
	 	win.x = 20;
                 win.y = 48;
                 win.w = 88;
                 win.h = 16;                          
		Lcd_Update_Win(ICONSBAR,win,0);
#endif
		BYTE temp,tempa;
		BYTE  FillVol[] = {0x40,0x02};
		BYTE  FillVol_FULL[] = {0xc0,0x03};
		BYTE  FillVol_NED[] = {0x80,0x01};
		char *p;
		
		tempa = (gSys.Volume * 86 / 30);
		
		for(temp = 0; temp < 87; temp ++)
				{
				win.x = 21 + temp;
                		win.y = 48;
                		win.w = 1;
               		win.h = 16;
				if((temp <= tempa) && (!MuteFlag))
					p = FillVol_FULL;
				else
					p = FillVol;
				Lcd_Update_Win(p,win,0);
				}
		win.x = 20;
             	win.y = 48;               			
		Lcd_Update_Win(FillVol_NED,win,0);
		win.x = 108;
             	win.y = 48;               				
		Lcd_Update_Win(FillVol_NED,win,0);
		
}
void ShowVolBar(void)
{
#if 0
	BYTE  temp;
	
	
	//char *p = ICONSBAR;

	if(!DisplayVolAdj)
		{
		point.x = 0;
		point.y = 48;
		ShowIcon1616(BID_VOL_ICON,point);		  

		win.x = 16;
		win.y = 48;
		win.w = 4;
		win.h = 16;
		Lcd_ClearScreen(win);
		win.x = 108;
		win.y = 48;
		win.w = 4;
		win.h = 16;
		Lcd_ClearScreen(win);
		}

		// win.x = 20;
              //   win.y = 48;
              //   win.w = 88;
              //   win.h = 16;                          
		//Lcd_Update_Win(p,win,0);
		ShowSBAR();
		if(gSys.SystemMode == SYS_MODE_AUDIO)
			{
			//USB ISO���ݰ�����
			AudioStreamProcess();
			}
		
		ShowVolBarVal();
		if(gSys.MuteFg)
			{			       
				gSys.MuteFg = FALSE;						
			}
//		SetDispVolAdj();//lxl 7-19
#else
#if 1	//lxl 7-19
		if(!DisplayVolAdj)
		{
		point.x = 0;
		point.y = 48;
		ShowIcon1616(BID_VOL_ICON,point);		  

		win.x = 16;
		win.y = 48;
		win.w = 4;
		win.h = 16;
		Lcd_ClearScreen(win);
		win.x = 108;
		win.y = 48;
		win.w = 4;
		win.h = 16;
		Lcd_ClearScreen(win);
		CurrVol = gSys.Volume;
		ShowSBAR(FALSE);
		}
		#endif
		ShowVolBarCurrVal();
		
		SetDispVolAdj();
		CurrVol = gSys.Volume;

#endif
}

void ClearAudioLeve(void)
{
		win.x = 0;
		win.y = 48;
		win.w = 96;
		win.h = 16;
		Lcd_ClearScreen(win);
		#if 0
		win.x = 0;
		win.y = 16;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);
		#endif
}
void ShowMute(void)
{		
		//char *p = ICONSBAR;	
		point.x = 0;
		point.y = 48;
		ShowIcon1616(BID_MUTE_ICON,point);		
		
		ShowSBAR(TRUE);
		
		point.x = 112;
		point.y = 48;
		Show2312String("  ",point,0);
}
void ClearVOLline(void)
{
	win.x = 0;
	win.y = 48;
	win.w = 128;
	win.h = 16;
	Lcd_ClearScreen(win);
}
void ShowPlayState(void)
{
		
		point.x = 28;
		point.y = 0;
		Show2312String(" ",point,0);
		
		point.x = 28;
		point.y = 0;
		if(gPlayCtrl.State == PLAY_STATE_PLAY)
			ShowIcon(BID_PLAY_ICON,point);
		else
			ShowIcon(BID_PAUSE_ICON,point);
}

void ShowPlayTotaltime(void)
{
#if 0
	unsigned int temp_second,temp;
		temp_second = gSongInfo.TotalPlayTime;
		if(temp_second>3600)	
		temp_second=temp_second%3600;	//ת����Сʱ����
		
		temp = temp_second/60;		/*���㲥��ʱ��*/  
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x3a;	//:
		temp = temp_second%60;
		DispBuf[3] =temp/10+0x30;
		DispBuf[4] =temp%10+0x30;
		DispBuf[5] = 0x20;		//space
		DispBuf[6] = 0x20;		//space
		DispBuf[7] = 0;
		point.x = 72;
		point.y = 32;
		ShowString(DispBuf,point);
#endif
}

void ShowPlayCurrtime(void)
{
	unsigned int temp_second,temp;
		temp_second = gSongInfo.CurPlayTime;
		if(temp_second>3600)	
		temp_second=temp_second%3600;	//ת����Сʱ����
		
		temp = temp_second/60;		/*���㲥��ʱ��*/  
		
		
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x3a;	//:
		temp = temp_second%60;
		DispBuf[3] =temp/10+0x30;
		DispBuf[4] =temp%10+0x30;		
		DispBuf[5] = 0;
		
		point.x = 40;
		point.y = 0;
		
		Show2312String(DispBuf,point,0);
		
		//if((NeedScroll)&&(gPlayCtrl.State == PLAY_STATE_PLAY))
		//Mp3ScrollScreen();
}

void ShowFolderName(void)
{

		char *p,i,j = 0;
		char shortnamebuffer[10];
		//char tempbuff[10] =" ";		
		p = gPlayCtrl.Folder.ShortName;
		for(i = 0 ; i< 9 ; i++)
			{
			
				shortnamebuffer[j] = *p;
				j++;				
				p++;
			}	
		shortnamebuffer[9] = 0;
		shortnamebuffer[8] = 0;
		win.x = 0;
		win.y = 16;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);

		point.x = 0;
		point.y = 16;
		ShowIcon1616(BID_FOLDER_ICON,point);
		
		point.x = 18;				//��ʾ�ļ���
		point.y = 16;
    		Show2312String(&shortnamebuffer[0], point,0);
		//NeedScroll =FALSE;	
}

void ShowFolderNameBrowser(BYTE *ShortName,BYTE Line,BOOL Mode)
{
	extern BYTE Length2312;
		if(Line == 1)
			{
			win.x = 40;
			win.y = 0;
			win.w = 88;
			win.h = 64;
			Lcd_ClearScreen(win);
			}
		point.x = 40;
		point.y = 8+ (Line - 1) *16;
		Length2312 = 8;
    		Show2312String(ShortName, point,Mode);	
		//Length = 16;
}


void ShowRepeatmode(void)
{
		char RepeatID;		
		
		RepeatID = gPlayCtrl.RepeatMode + BID_REPONE_ICON;
		point.x = 88;
		point.y = 0;
		ShowIcon1616(RepeatID,point);

}

void ShowAudioLeve(char *Buff,POSITION pointy)
{
		 win.x = pointy.x;
                 win.y = pointy.y;
                 win.w = 45;
                 win.h = 16;                 
		Lcd_Update_Win(Buff,win,0);
}

void ShowLoading(void)
{
		ClearScreen();
		
		point.x = 24;
		point.y = 24;
		Show2312String("Loading...",point,0);
}

void ShowMp3Loading(BOOL DevFlag)
{
		ClearScreen();
		
		point.x = 24;
		point.y = 24;
		if(Language)
			{
			if(DevFlag)
				Show2312String("U�̶�ȡ��...",point,0);
			else
				Show2312String("SD��ȡ��...",point,0);
			}
		else
			Show2312String("Loading...",point,0);
}

void ShowMp3NoFile(void)
{	
	
	ShowDev();	
	point.x = 24;
	point.y = 24;
	if(Language)
		{		
			Show2312String("û�������ļ�",point,0);
		}
	else
		Show2312String("No Song",point,0);

}
void ShowMp3(void)
{
#if 0
	//if((!IsTimeOut(&DisplayTimer)) && gSys.PlayCtrl.LrcFlag)
	//{
	//	return;
	//}
	unsigned int temp_second,temp;
	//DisplayRefreshFlag = 0xff;
	//if (gSys.PlayCtrl.IsTimeUpdate)
	{
	//if(DisplayRefreshFlag&MP3_FILENAME)
	//ScrollScreenInit();
	if(DisplayRefreshFlag&MP3_ICON)
		{
		point.x = 6;
		point.y = 0;
		//AppMode = Mp3_Mode_Udisk;
		ShowString(&DEV_ID_ICON[gSys.SystemMode][0],point);
		}
#if 0
	if(DisplayRefreshFlag&MP3_REP)
		{
		point.x = 100;
		point.y = 0;
		ShowString(&REP_MDOE[gSys.PlayArg.Mode][0],point);
		}
#endif
	if(DisplayRefreshFlag&Refresh_BATTERY)
		{
		ShowBatteryIcon();
		}

	if(DisplayRefreshFlag&MP3_VOL)
		{
		temp = gSys.Volume;
		DispBuf[0] = 'V';
		DispBuf[1] = 'O';
		DispBuf[2] = 'L';
		DispBuf[3] = ':';
		DispBuf[4] = temp/10+0x30;
		DispBuf[5] = temp%10+0x30;
		DispBuf[6] = 0x00;	//
		point.x = 40;
		point.y = 0;
		ShowString(DispBuf,point);
		}
	
	
	if(gPlayCtrl.LrcFlag)
		return;
#if 0
	if(DisplayRefreshFlag&MP3_EQ)
		{
		point.x = 88;
		point.y = 48;
		ShowString(&EQ_MDOE[gSys.PlayArg.Eq][0],point);
		}
#endif
	if(DisplayRefreshFlag&Refresh_TIME)
		ShowRtc();
	
	if(DisplayRefreshFlag&MP3_CURTIME)
		{
		temp_second = gSongInfo.CurPlayTime;
		if(temp_second>3600)	
		temp_second=temp_second%3600;	//ת����Сʱ����
		
		temp = temp_second/60;		/*���㲥��ʱ��*/  
		#if 0
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x3a;	//:
		temp = temp_second%60;
		DispBuf[3] =temp/10+0x30;
		DispBuf[4] =temp%10+0x30;
		DispBuf[5] = 0;
		point.x = 8;
		point.y = 32;
		#else
		DispBuf[0] = 0x20;		//space
		DispBuf[1] = temp/10+0x30;
		DispBuf[2] = temp%10+0x30;
		DispBuf[3] = 0x3a;	//:
		temp = temp_second%60;
		DispBuf[4] =temp/10+0x30;
		DispBuf[5] =temp%10+0x30;
		DispBuf[6] = 0x20;		//space
		DispBuf[7] = 0x20;
		DispBuf[8] = 0x20;
		DispBuf[9] = 0;
		
		point.x = 0;
		point.y = 32;
		#endif
		ShowString(DispBuf,point);
		
		if((NeedScroll)&&(gPlayCtrl.State == PLAY_STATE_PLAY))
		Mp3ScrollScreen();
		}

#if 1
	if(DisplayRefreshFlag&MP3_TOTALTIME)
		{
		temp_second = gSongInfo.TotalPlayTime;
		if(temp_second>3600)	
		temp_second=temp_second%3600;	//ת����Сʱ����
		
		temp = temp_second/60;		/*���㲥��ʱ��*/  
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = 0x3a;	//:
		temp = temp_second%60;
		DispBuf[3] =temp/10+0x30;
		DispBuf[4] =temp%10+0x30;
		DispBuf[5] = 0x20;		//space
		DispBuf[6] = 0x20;		//space
		DispBuf[7] = 0;
		point.x = 72;
		point.y = 32;
		ShowString(DispBuf,point);
		}
#endif



	if(DisplayRefreshFlag&MP3_PLAYSTATE)
		{
		DispBuf[0] = 0x20;		//space
		DispBuf[1] = 0x20;		//space
		DispBuf[2] = 0;
		point.x = 0;
		point.y = 48;
		ShowString(DispBuf,point);
		
		point.x = 2;
		point.y = 48;
		if(PlayIconEn)  //(gSys.PlayCtrl.State == PLAY_STATE_PLAY)
			ShowIcon(BID_PLAY_ICON,point);
		else
			ShowIcon(BID_PAUSE_ICON,point);
		}
	LcdMp3FileNumber();

#ifdef FUNC_UARTDBG_EN
	//DBG(("LCD UPDATE!\n"));
#endif

	}	
#endif
}




#if 1
void ShowAux(void)
{	
	ShowDev();	
	ShowBatteryIcon();
	point.x = 0;
	point.y = 16;
	ShowIcon12832(BID_12832_LINEINT,point);
	//ShowVol();
	DisplayVolAdj = FALSE;
	if(gSys.MuteFg)
		ShowMute();
	else
		ShowVolBar();
	
}
void ShowAudio(void)
{
	//ShowDev();	
	ClearScreen();
	ShowBatteryIcon();
	point.x = 0;
	point.y = 0;
	Show2312String("USB AUDIO",point,0);
	point.x = 0;
	point.y = 16;
	ShowIcon12832(BID_12832_AUDIO,point);
	//ShowVol();
	DisplayVolAdj = FALSE;
	if(gSys.MuteFg)
		ShowMute();
	else
		ShowVolBar();
	
}

void ShowUsbRead(void)
{
	ShowDev();	
	ShowBatteryIcon();
	point.x = 0;
	point.y = 16;
	ShowIcon12832(BID_12832_USBREAD,point);
	//ShowVol();
	
}
#endif
#if 0
VOID LcdFmSelSations(VOID)
{
	unsigned int temp;
#ifdef FUNC_NUMBER_SEL_EN
		temp = gNumber.Result;


	if(gNumber.Result > 100)
		temp = gNumber.Result%100;
#endif
	DispBuf[0] = 'N';
	DispBuf[1] = 'U';
	DispBuf[2] = 'M';
	DispBuf[3] = ':';
	
	DispBuf[4] = temp/10+0x30;
	DispBuf[5] = temp%10+0x30;

	DispBuf[6] = 0x00;	//
		point.x = 24;
		point.y = 48;
		ShowString(DispBuf,point);
}
VOID LcdFmSaving(VOID)
{
	unsigned int temp;
#if (FM_TYPE  !=  FM_NULL)
	temp = gRadioArg.CurStation;
#endif
	DispBuf[0] = 'S';
	DispBuf[1] = 'A';
	DispBuf[2] = 'V';
	DispBuf[3] = 'E';
	DispBuf[4] = ':';
	
	DispBuf[5] = temp/10+0x30;
	DispBuf[6] = temp%10+0x30;

	DispBuf[7] = 0x00;	//
		point.x = 24;
		point.y = 48;
		ShowString(DispBuf,point);
}
VOID LcdFmNormal(VOID)
{
	DispBuf[0] = ' ';
	DispBuf[1] = ' ';
	DispBuf[2] = ' ';
	DispBuf[3] = ' ';
	DispBuf[4] = ' ';
	DispBuf[5] = ' ';
	DispBuf[6] = ' ';
	DispBuf[6] = ' ';
	DispBuf[7] = 0x00;	//
	point.x = 24;
	point.y = 48;
	ShowString(DispBuf,point);
}
#endif

void ClearRadioFre(void)
{
	win.x = 0;
	win.y = 0;
	win.w = 128;
	win.h = 64;
	Lcd_ClearScreen(win);
}

#if 0
void ShowFmMenuIcon(void)
{
		ClearRadioFre();
		point.x = 0;
		point.y = 16;
		ShowIcon3232(MENU_AREA_ICON,point);
}

void ShowFmMenuVAL(BYTE MenuMain)
{
		win.x = 40;
		win.y = 32;
		win.w = 88;
		win.h = 16;
		Lcd_ClearScreen(win);
		win.x = 0;
		win.y = 48;
		win.w = 128;
		win.h = 16;
		Lcd_ClearScreen(win);		

		if(MenuMain == 5)
			{			
			point.x = 40;
			point.y = 32;	
			if(Language)
				Show2312String(&FmMuneArea_CH[Radio.Band][0],point,0);
			else
				{			
				Show2312String(&FmMuneArea[Radio.Band][0],point,0);
				}
			point.x = 0;
			point.y = 48;	
			switch(Radio.Band)
				{
				case 0:
					Show2312String("87.0MHz~108.0MHz",point,0);
					break;
				case 1:
					Show2312String("76.0MHz~ 91.0MHz",point,0);
					break;
				default:
					Show2312String("76.0MHz~108.0MHz",point,0);
					break;

				}
			}
		else
			{
			point.x = 50;
			point.y = 32;
			if(YesFlag)
				Show2312String("Yes?",point,0);
			else
				Show2312String("No?",point,0);
			}		
		

}

void ShowFmMenuMain(BYTE MenuMain)
{
		win.x = 20;
		win.y = 0;
		win.w = 88;
		win.h = 16;
		Lcd_ClearScreen(win);
		point.x = 32;
		point.y = 0;	
		if(Language)
			Show2312String(&FmMuneName_CH[(MenuMain - 1)][0],point,0);
			//ShowUnicodeString(&FmMuneName_CH[(MenuMain - 1)][0],point);
		else
			{
			point.x = 28;			
			if(MenuMain == 4)
				point.x = 20;
			Show2312String(&FmMuneName[(MenuMain - 1)][0],point,0);
			//ShowUnicodeString(&FmMuneName[(MenuMain - 1)][0],point);
			}
		ShowFmMenuVAL(MenuMain);

}

#endif
void ShowRadioFre(WORD Fre)
{
		unsigned int temp;
		char *p = FQBAR;	
		WORD FreTemp;
		   win.x = 11;
                 win.y = 24;
                 win.w = 106;
                 win.h = 8;                
		Lcd_Update_Win(p,win,0);
		  DispBuf[0] = 0xff;
		  DispBuf[1] = 0xff;
		//  FreTemp = Fre-Radio.FreqMin; //LXL 7-19
		FreTemp = 875 ; //added by lxl 7-19
		  if(FreTemp)
		  	{
		  	//win.x = (((105 * FreTemp)/(Radio.FreqMax -Radio.FreqMin)) + 11);//lxl 7-19
		  	win.x = (((105 * FreTemp)/(1080 -875)) + 11);//lxl 7-19
		  	}
		  else
		  	win.x = 11;
                 win.y = 24;
                 win.w = 1;
                 win.h = 8; 
		Lcd_Update_Win(DispBuf,win,0);

		//YcDBG	(("FreTemp:%d\n", (WORD)FreTemp));
		//YcDBG	(("win:%d\n", (WORD)win.x));
		temp = Fre ;
		if(Fre >=1000)
		DispBuf[0] = temp/1000+0x30;
		else
		DispBuf[0] = ' ';
		temp =temp%1000;
		DispBuf[1] = temp/100+0x30;
		temp =temp%100;
		DispBuf[2] = temp/10+0x30;
		DispBuf[3] = '.';
		temp =temp%10;
		DispBuf[4] = temp+0x30;
		DispBuf[5] = 'M';
		DispBuf[6] = 'H';
		DispBuf[7] = 'z';
		DispBuf[8] = 0x00;	//
		point.x = 32;
		point.y = 32;
		Show2312String(DispBuf,point,0);
}

void ShowRadioStation(BYTE CurStation,BYTE StationSum)
{
#if 0
		BYTE temp = CurStation;
		DispBuf[0] = temp/10+0x30;
		DispBuf[1] = temp%10+0x30;
		DispBuf[2] = '/';
		temp = StationSum;
		DispBuf[3] = temp/10+0x30;
		DispBuf[4] = temp%10+0x30;
		DispBuf[5] = 0x00;			//
		point.x = 5;
		point.y = 48;
		ShowString(DispBuf,point);
#else
		BYTE temp = CurStation;
		DispBuf[0] = 'C';
		DispBuf[1] = 'H';
		DispBuf[2] = ':';
		temp = CurStation;
		DispBuf[3] = temp/10+0x30;
		DispBuf[4] = temp%10+0x30;
		DispBuf[5] = 0x00;			//
		point.x = 44;
		point.y = 0;
		Show2312String(DispBuf,point,0);

#endif
}

void ShowStationClear(void)
{
		point.x = 44;
		point.y = 0;
		Show2312String("      ",point,0);
}

void ShowFM_MHZ(void)
{
		char *p = FM_BAR_HEAD;	
		BYTE FreTemp;

		if(Radio.Band == 0)	//7-19
			FreTemp = 1;
		else
			FreTemp = 0;		
		   win.x = 1;
                 win.y = 24;
                 win.w = 9;
                 win.h = 8; 
		p += (FreTemp * 9);
		Lcd_Update_Win(p,win,0);

		p = FM_BAR_HEAD;	
		//YcDBG(("FM_BAR_HEAD:%d\n", (WORD)p));
		
		FreTemp = 2;
			
		   win.x = 118;
                 win.y = 24;
                 win.w = 9;
                 win.h = 8; 
		p += (FreTemp * 9);
		Lcd_Update_Win(p,win,0);
		//YcDBG(("FreTemp:%d\n", (WORD)p));
}

void ShowRadio(void)
{
		ShowDev();	
		ShowBatteryIcon();
		
		DisplayVolAdj = FALSE;
		if(gSys.MuteFg)
			ShowMute();
		else
			ShowVolBar();
	
		//ShowRadioFre(Radio.Freq); //lxl 7-19
		ShowRadioFre( 875 );//lxl 7-19
		ShowFM_MHZ();
		//Radio_SeekSet();
}

void ShowClock(void)
{
#ifdef FUNC_RTC_EN
	BYTE Clockbuffer[8];
	WORD temp;
	static	BYTE	WdayB;
	//TIMER SetFlash;
	
	if(DisplayRefreshFlag&Refresh_BATTERY)
		{
		ShowBatteryIcon();
		}
	
	if(DisplayRefreshFlag&RTC_ICON)
		{
 		point.x = 8;				//��ʾ�ļ���
		point.y = 0;
		ShowIcon(BID_CLOCK_ICON,point);
		}
	
	if(DisplayRefreshFlag&RTC_YEAR)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Year;
			Clockbuffer[0] = temp/1000 + 0X30; 
			temp = temp%1000;
			Clockbuffer[1] = temp/100 + 0X30; 
			temp = temp%100;
			Clockbuffer[2] = temp/10 + 0X30 ; 
			Clockbuffer[3] = temp%10 + 0X30;
			Clockbuffer[4] = '/';
			Clockbuffer[5] = 0;
			point.x = 24;				
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_YEAR)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20; 
			Clockbuffer[2] = 0X20; 
			Clockbuffer[3] = 0X20; 
			Clockbuffer[4] = 0; 
			point.x = 24;				
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}

		}
	
	if(DisplayRefreshFlag&RTC_MONTH)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Mon;
			Clockbuffer[0] = temp/10 + 0X30; 
			Clockbuffer[1] = temp%10 + 0X30;
			Clockbuffer[2] = '/';
			Clockbuffer[3] = 0;
 			point.x = 24+40;				//��ʾ�ļ���
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_MON)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20;
			Clockbuffer[2] = 0;
 			point.x = 24+40;				//��ʾ�ļ���
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}

		}
	
	if(DisplayRefreshFlag&RTC_DAY)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Date;
			Clockbuffer[0] = temp/10 + 0X30; 
			Clockbuffer[1] = temp%10 + 0X30;
			Clockbuffer[2] = 0;
 			point.x = 24+40+24;				//��ʾ�ļ���
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_DATE)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20;
			Clockbuffer[2] = 0;
 			point.x = 24+40+24;				//��ʾ�ļ���
			point.y = 48;
    			Show2312String(Clockbuffer, point,0);
			}
		}
#if 1
	if(((DisplayRefreshFlag&RTC_DAY)||(DisplayRefreshFlag&RTC_WDAY))
		&& (WdayB != gRtcTime.WDay))
		{
		WdayB = gRtcTime.WDay;
		
		temp = gRtcTime.WDay;
		win.x = 40;
		win.y = 32;
		win.w = 16;
		win.h = 16;
		temp = 0Xc7d0;	//��
		GetGB2312Char(temp);
		Lcd_Update_Win(&font.DotBuffer[0],win,0);
		temp = 0Xdac6;	//��
		win.x += 16;
		GetGB2312Char(temp);
		Lcd_Update_Win(&font.DotBuffer[0],win,0);
		switch(gRtcTime.WDay)
			{
			case 1:			//һ
				temp = 0xbbd2;
				break;
			case 2:			//��
				temp = 0xfeb6;
				break;
			case 3:			//��
				temp = 0xfdc8;
				break;
			case 4:			//��
				temp = 0xc4cb;
				break;
			case 5:			//��
				temp = 0xe5ce;
				break;
			case 6:			//��
				temp = 0xf9c1;
				break;
			case 0:			//��
				temp =0xd5c8 ;
				break;
			default:
				temp = 0xd5c8;
			}
		win.x += 16;
		GetGB2312Char(temp);
		Lcd_Update_Win(&font.DotBuffer[0],win,0);
		}
#endif
	
	if(DisplayRefreshFlag&RTC_HOUR)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Hour;
			Clockbuffer[0] = temp/10 + 0X30; 
			Clockbuffer[1] = temp%10 + 0X30;
			Clockbuffer[2] = ':';
			Clockbuffer[3] = 0;
 			point.x = 32;					//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_HR)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20;
			Clockbuffer[2] = 0;
 			point.x = 32;					//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}

		}
	
	if(DisplayRefreshFlag&RTC_MIN)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Min;
			Clockbuffer[0] = temp/10 + 0X30; 
			Clockbuffer[1] = temp%10 + 0X30;
			Clockbuffer[2] = ':';
			Clockbuffer[3] = 0;
	 		point.x = 32+24;				//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_MIN)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20;
			Clockbuffer[2] = 0;
 			point.x = 32+24;				//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}

		}
	
	if(DisplayRefreshFlag&RTC_SEC)
		{
		if((RtcState == RTC_STATE_IDLE)||(RtcSetFlash))
			{
			temp = gRtcTime.Sec;
			Clockbuffer[0] = temp/10 + 0X30; 
			Clockbuffer[1] = temp%10 + 0X30;
			Clockbuffer[2] = 0;
 			point.x = 32+24+24;				//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}
		else if(RtcSubState == RTC_SET_SCE)
			{
			Clockbuffer[0] = 0X20; 
			Clockbuffer[1] = 0X20;
			Clockbuffer[2] = 0;
 			point.x = 32+24+24;				//��ʾ�ļ���
			point.y = 16;
    			Show2312String(Clockbuffer, point,0);
			}

		}
	
#endif
}

#endif  //(LCD_TYPE  !=  LCD_NULL)
