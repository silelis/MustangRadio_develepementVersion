#ifndef _GT20L16P1Y_H_
#define _GT20L16P1Y_H_

#define FLASH_CS_PORT	GPIO_B_IN
#define FLASH_DI_PORT	GPIO_B_IN
#define FLASH_DO_PORT	GPIO_B_IN
#define FLASH_CLK_PORT	GPIO_B_IN

#define FLASH_CS_PIN		0x80
#define FLASH_DI_PIN		0x40
#define FLASH_DO_PIN		0x10
#define FLASH_CLK_PIN		0x20

BOOL GT20LInit(VOID);
BYTE ReadGT20L(DWORD address,BYTE * Buffter,BYTE Count);
#endif