
/*
*****************************************************************************
*					Mountain View Silicon Tech. Inc.
*	Copyright 2007, Mountain View Silicon Tech. Inc., ShangHai, China
*					All rights reserved.
*
* Filename:			
* Description:		
*
* Change History:
*			tom.tong	- 03/01/2012
*						- created

******************************************************************************
*/
#include<string.h>
#include "type.h"
#include "utility.h"
#include "debug.h"
#include "timer.h"
#include "Rda5807.h"
#include "eeprom/I2C.h"
//#include "radioctrl.h"
#include "Syscfg.h"
#include "radio_ctrl.h"

#ifdef FUNC_RADIO_EN

//RDA5807P��RDA5807SP��RDA5807SS��RDA5807Hϵ�С�RDA5807Nϵ�У�
#define VER_PH	  0//ID  5801
#define VER_P	  1//ID (5802  5803) 
#define VER_PE	  2//ID  5804
#define VER_N	  3//ID  5808

#define RDA5807_CHIP_ADDR	0x22

#define RDA5807PH_REG_LEN	66

#define RDA5807PE_REG_LEN	32

#define RDA5807N_REG_LEN	34
#define RDA5807M_REG_LEN	35


BYTE ChipVer ;	
	  
WORD CODE RDA5807PH_REG[66]=
{
//#ifdef(_SHARE_CRYSTAL_12MHz_)	  //5801
//    0xC4, 0x11, //02H:
//#else
//    0xC0, 0x01,
//#endif
	0x03,0x0000,
	0x04,0x0400,
	0x05,0x86BF,  //83 84 85 86 87 88 89 8A 8B;	
	0x06,0x4000,
	0x07,0x56C6,
	0x09,0x0000,
	0x12,0x2A11,
	0x13,0x002E,
	0x16,0x9000,
	0x17,0x2A91,
	0x18,0x8412,
	0x1B,0xE000,
	0x1C,0x301D,
	0x1D,0x816A,
	0x1E,0x4608,
	0x1F,0x0086,
	0x20,0x0661, //
	0x23,0x24c9, //
	0x24,0x0408,
	0x25,0x0608,
	0x2A,0x3414,
	0x2C,0x096D,
	0x2D,0x2D96,
	0x2e,0x01DA,
	0x31,0x13D5,
	0x32,0x4891,
	0x38,0x0000,
	0x39,0x3C58,
	0x3a,0x2A50,
	0x3b,0x262C,
	0x3c,0x0608,
	0x3d,0x0200,
	0x3e,0x0000,
};

WORD CODE RDA5807PE_REG[32]=   //sp	 5804
{	
	0x03,0x0000, //freq 0//band 875--1080//space 100k//turn off//turn on 0x0010
	0x04,0x0400,
	0x05,0x8AAD, //0x8AAF//SEEK threshold //VOL
	0x06,0x8000,
	0x07,0x5F1A,
	0x12,0xF000,
	0x13,0x7F0B,
	0x14,0x0071,
	0x15,0x42C0,
	0x1A,0x10C0,
	0x1C,0x6015,
	0x21,0x4580,
	0x24,0x0601,
	0x26,0x0D04,
	0x2C,0x3C3B,
	0x35,0x3877
};
#if 0
WORD CODE RDA5807N_REG[34]=	  //5808
{
    0x03,0x0000,
    0x04,0x0400,
    0x05,0xC6ad, //05h snr //83 84 85 86 87 88 89 8A 8B;
    0x06,0x6000,
    0x07,0x4216, //rssi 0x42, 0xC6,
	0x09,0x0000,
	0x12,0x2a11,
	0x13,0xB042,  
	0x14,0x2A11,  
	0x15,0xb831, 
	0x16,0xc000,
	0x17,0x2a91,
	0x18,0x9400,
	0x1B,0xF7cF,   
	0x1c,0x2ADC,
	0x1d,0x806F, 
	0x25,0x0E1C,
};
#else
//5807M
WORD CODE RDA5807N_REG[35*2]=	  //5808
{
    0x03,0x0000,
    0x04,0x0400,	//0400 
    0x05,0xc3a8, //05h snr //83 84 85 86 87 88 89 8A 8B;
    0x06,0x6000,
    0x07,0x7e12, //rssi , 0x4212  0x7e12
    0x08,0x0000,
	0x09,0x0000,
	0x0a,0x0000,
	0x0b,0x0000,
	0x0c,0x0000,
	0x0d,0x0000,
	0x0e,0x0000,
	0x0f,0x0000,
	0x10,0x0000,
	0x11,0x0019,
	0x12,0x2a11,
	0x13,0xB042,  
	0x14,0x2A11,  
	0x15,0xb831, 
	0x16,0xc000,
	0x17,0x2a91,
	0x18,0x9400,
	0x19,0x00a8,
	0x1a,0xc400,
	0x1B,0xF7cF,   
	0x1c,0x2ADC,
	0x1d,0x806F, 
	0x1e,0x4608,
	0x1f,0x0086,
	0x20,0x0661,
	0x21,0x0000,
	0x22,0x109e,
	0x23,0x23c8,
	0x24,0x0406,
	0x25,0x0E1C,
};
#endif
/*
*****************************************************
*      
******************************************************
*/
BOOL Rda5870hp_Write(
					WORD addr,//unsigned char addr, 					//address
					WORD dat)
{
	return I2C_WriteNByte(RDA5807_CHIP_ADDR,addr,(BYTE*)&dat,2);
}

WORD Rda5870hp_Read(BYTE Register_Address)
{
	WORD	TempData;
	I2C_ReadNByte(RDA5807_CHIP_ADDR, Register_Address,(BYTE*)(&TempData),2);
	return TempData;
}

/*******************************************************/
VOID RDA5807P_Init(VOID)
{	
	BYTE	i;
	DBG(("INIT 5807 \n"));
	//if(Radio.ExtOsc12m)

#if 0	
	#ifdef FUNC_UARTDBG_EN
		Rda5870hp_Write(0x02,0xC001);	//32k
	#else
		Rda5870hp_Write(0x02,0xC411);//12m		
	#endif
#else
	Rda5870hp_Write(0x02,0xC001);	//32k
	//Rda5870hp_Write(0x02,0xC411);//12m		
#endif
	
	WaitMs(600);

	if(ChipVer == VER_PE)//5804
	{
		for(i = 0;i < RDA5807PE_REG_LEN;)
		{
			Rda5870hp_Write(*(RDA5807PE_REG + i),*(RDA5807PE_REG+1 + i));
			i += 2;
		}
	}

	if(ChipVer == VER_PH)//5801
	{
		for(i = 0;i < RDA5807PH_REG_LEN;)
		{
			Rda5870hp_Write(*(RDA5807PH_REG + i),*(RDA5807PH_REG+1 + i));
			i += 2;
		}	
	}

	if(ChipVer == VER_N)//5808
	{
		for(i = 0;i < RDA5807M_REG_LEN;)
		{
			Rda5870hp_Write(*(RDA5807N_REG + i),*(RDA5807N_REG+1 + i));
			i += 2;
		}	
	}

}

BOOL RDA5807P_ReadID(void)
{
	WORD	id;
	ChipVer = 0xff;
	Rda5870hp_Write(0x02,0x0002);//reset
	WaitMs(60);
	id = Rda5870hp_Read(0x0E);
	DBG(("RD5807 ID : %X",id));
	if(id == 0x5801)
	{
		DBG(("PH\n"));
		ChipVer = VER_PH ;
		return TRUE;	
	}
	else if(id == 0x5804)
	{
		DBG(("PE\n"));
		ChipVer = VER_PE;
		return TRUE;
	}
	else if(id == 0x5808)
	{
		DBG(("N\n"));
		ChipVer = VER_N;
		return TRUE;
	}
	DBG(("ERR\n"));
	return FALSE;
}

void RDA5807P_Mute(BOOL mute)
{
	WORD temp;

	temp = Rda5870hp_Read(0x02);

	if(mute) 
		temp &= 0xBFFF;			//mute on
	else 
		temp |= 0x4000;			// mute oFF
	Rda5870hp_Write(0x02,temp);
}

#if 0	//for reduce target size 8-8
void Rda5870hp_PowerOn(void)
{
//	Rda5870hp_Write(0x02, (Rda5870hp_Read(0x02) | 0xC000));
}

void Rda5870hp_PowerDown(void)
{
//	Rda5870hp_Write(0x02, (Rda5870hp_Read(0x02) & 0x3FFF));
//	Rad5807hp_Mute(TRUE);
}

VOID RDA5807P_PowerDownDis(VOID)
{
	Rda5870hp_Write(0x02, (Rda5870hp_Read(0x02) | 0xC000));
}
#endif

VOID RDA5807P_PowerDownEn(VOID)
{
	Rda5870hp_Write(0x02, (Rda5870hp_Read(0x02) & 0x3FFE));
}

void RDA5807P_FreqSet(WORD freq)
{	
	freq = ((freq -870) << 6) | 0x0010;
	Rda5870hp_Write(0x03,freq); //FREQ //tune//band//space
	
}

#if 0	//for reduce target size 8-8
void Rda5870hp_SearchSet(WORD freq)
{
//	Rda5870hp_SetFreq(freq);
}
#endif
BYTE RDA5807P_SeekResultGet(void)
{
	WORD u16reg;

	u16reg = Rda5870hp_Read(0x0B); 
		  
	if(u16reg & 0x0100)
	{
		#if 0
		// ���ж�������
		if((gRadioCtrl.Freq == 1080)||(gRadioCtrl.Freq == 1020)||(gRadioCtrl.Freq == 960)
			||(gRadioCtrl.Freq == 885)||(gRadioCtrl.Freq == 1000))
		{
			u16reg = Rda5870hp_Read(0x0A);
			if(u16reg & 0x0400)	  
				return TRUE;			//mono ? lxl 7-31
			else
				return FALSE;
		}
		#endif
		if((gRadioCtrl.Freq == 1080)||(gRadioCtrl.Freq == 960))
		{
			//��Ƶ12M�����±�Ƶ�����1080��960����Ƶ�㣬������̨
			return FALSE;
		}
		return TRUE ;
	}
	return FALSE;
}
#if 0
FUNC_RADIO  CODE module_5807 = 
{
	Rad5807hp_Probe,
	Rad5807hp_Init,
	Rda5870hp_PowerOn,
 	Rda5870hp_PowerDown,
	Rda5870hp_SearchSet,
	NULL,		   //wakeup
	Rad5807hp_Mute,
	NULL,	  		//volum
	Rda5870hp_SetFreq,
	NULL,
	Rda5870hp_SearchRead,
};
#endif

#endif

