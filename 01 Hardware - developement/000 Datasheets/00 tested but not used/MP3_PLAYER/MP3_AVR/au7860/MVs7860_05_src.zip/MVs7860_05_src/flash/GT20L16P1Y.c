/*
********************************************************************************
*                   Copyright (c) 2010,ZhangXiaoYong
*                         All rights reserved.
*
* File Name��   GT20L16P1Y.c
* 
* Description:   �ֿ����� GT20L16P1Y
*
* History:      <author>          <time>        <version>       
*             ZhangXiaoYong      2011-03-03          1.0
*    desc:    ORG.
********************************************************************************
*/
#include "syscfg.h"
#include "sysctrl.h"
#include "playctrl.h"
#include "GT20L16P1Y.h"

extern VOID AudioStreamProcess();

#define GT_CS_SET			(baGPIOCtrl[FLASH_DI_PORT+1] |= FLASH_CS_PIN);
#define GT_CLK_SET			(baGPIOCtrl[FLASH_DI_PORT+1] |= FLASH_CLK_PIN);
#define GT_DI_SET			(baGPIOCtrl[FLASH_DI_PORT+1] |= FLASH_DI_PIN);


#define GT_CS_CLR			(baGPIOCtrl[FLASH_DI_PORT+1] &= (~FLASH_CS_PIN)); 
#define GT_CLK_CLR			(baGPIOCtrl[FLASH_DI_PORT+1] &= (~FLASH_CLK_PIN));
#define GT_DI_CLR			(baGPIOCtrl[FLASH_DI_PORT+1] &= (~FLASH_DI_PIN));

VOID SpiFlashIdRd1();

BOOL GT20LInit(VOID)
{
	SetGpioRegBit(FLASH_CS_PORT +1 , FLASH_CS_PIN);
	SetGpioRegBit(FLASH_CLK_PORT +1, FLASH_CLK_PIN);
	SetGpioRegBit(FLASH_DI_PORT + 1, FLASH_DI_PIN);

	
#if 0	
	SetGpioRegBit(FLASH_CS_PORT + 2, FLASH_CS_PIN);
	SetGpioRegBit(FLASH_CLK_PORT + 2, FLASH_CLK_PIN);
	ClrGpioRegBit(FLASH_DO_PORT + 2, FLASH_DO_PIN);
	SetGpioRegBit(FLASH_DI_PORT + 2, FLASH_DI_PIN);
#else
	SetGpioRegBit(FLASH_CS_PORT + 3, FLASH_CS_PIN);
	SetGpioRegBit(FLASH_CLK_PORT + 3, FLASH_CLK_PIN);
	ClrGpioRegBit(FLASH_DO_PORT + 3, FLASH_DO_PIN);
	SetGpioRegBit(FLASH_DI_PORT + 3, FLASH_DI_PIN);
#endif

	//SpiFlashIdRd1();
	
	return 1;
}

BOOL SendByteToGT20L(BYTE Dat)
{
	BYTE i;
	for(i = 0; i < 8; i++)
	{
		ClrGpioRegBit(FLASH_CLK_PORT+1, FLASH_CLK_PIN);	
		
		if(Dat&0x080)
		  SetGpioRegBit(FLASH_DI_PORT+1, FLASH_DI_PIN);
		else
		  ClrGpioRegBit(FLASH_DI_PORT+1, FLASH_DI_PIN);
		 Dat <<=1;
		
		SetGpioRegBit(FLASH_CLK_PORT+1, FLASH_CLK_PIN);
	}
	return 1;
}

BYTE ReadByteFromGT20L(VOID)
{
	BYTE i,Dat;
	Dat = 0;
	for(i = 0; i < 8; i++)
	{
		ClrGpioRegBit(FLASH_CLK_PORT+1, FLASH_CLK_PIN);	

		
		if(GetGpioReg(FLASH_DO_PORT)&FLASH_DO_PIN)
		{
		   Dat = Dat|0x01;
		}
		else
		{
		   Dat = Dat&0xfe;
		}
		
		SetGpioRegBit(FLASH_CLK_PORT+1, FLASH_CLK_PIN);
		if(i != 7)
		 Dat <<=1;

		
	}
	//DBG(("*flashDat:%X\n", (WORD)Dat));
	return Dat;
}


BYTE ReadGT20L(DWORD address,BYTE *Buffter,BYTE Count) 	//���ֿ��ж�ȡ�����ֽ�
{
	BYTE tempL,tempM,tempH;
	BYTE *p;
	p = Buffter;
	tempL = (address&0x0000ff);
	tempM = (address&0x00ff00)>>8;
	tempH = (address&0xff0000)>>16;
	
	ClrGpioRegBit(FLASH_CS_PORT+1, FLASH_CS_PIN);

	SendByteToGT20L(0x03);
	
	SendByteToGT20L(tempH);
	SendByteToGT20L(tempM);
	SendByteToGT20L(tempL);
	for(; Count > 0; Count--)
	{
	*p = ReadByteFromGT20L();
	p++;
	if(gSys.SystemMode == SYS_MODE_AUDIO)
		AudioStreamProcess();
	if(gPlayCtrl.State == PLAY_STATE_PLAY)
		{
			SongPlayDo();
		}
	}
	SetGpioRegBit(FLASH_CS_PORT+1, FLASH_CS_PIN);
	return 1;	
}


#if 0
VOID SpiFlashIdRd1()
{
	BYTE Mid;		//Manufacturer's ID
	WORD Did;		//Device ID

	
	SendByteToGT20L(0x9f);		
	Mid = ReadByteFromGT20L();	
	BYTE0(Did) = ReadByteFromGT20L();   //just need the manfacture's ID
	BYTE1(Did) = ReadByteFromGT20L();
	
	
	DBG(("FlashID:%x Did = %x \n", (short)Mid , Did));
}
#endif
