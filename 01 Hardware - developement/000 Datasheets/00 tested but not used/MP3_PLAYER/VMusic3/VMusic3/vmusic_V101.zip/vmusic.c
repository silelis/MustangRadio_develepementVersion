#include <system.h>

#ifdef _PIC18F4520
#pragma DATA _CONFIG2L, _BOREN_OFF_2L & _PWRT_ON_2L
#pragma DATA _CONFIG4L, _STVREN_OFF_4L & _LVP_OFF_4L & _DEBUG_OFF_4L & _XINST_OFF_4L
#pragma DATA _CONFIG5L, _CP0_OFF_5L & _CP1_OFF_5L & _CP2_OFF_5L & _CP3_OFF_5L
#pragma DATA _CONFIG6L, _WRT0_OFF_6L & _WRT1_OFF_6L & _WRT2_OFF_6L & _WRT3_OFF_6L
#pragma DATA _CONFIG7L, _EBTR0_OFF_7L & _EBTR1_OFF_7L & _EBTR2_OFF_7L & _EBTR3_OFF_7L
#else
#ifdef _PIC18F452
#pragma DATA _CONFIG2L, _BOR_OFF_2L & _PWRT_ON_2L
#pragma DATA _CONFIG4L, _STVR_OFF_4L & _LVP_OFF_4L & _DEBUG_OFF_4L
#pragma DATA _CONFIG5L, _CP0_OFF_5L & _CP1_OFF_5L & _CP2_OFF_5L & _CP3_OFF_5L
#pragma DATA _CONFIG6L, _WRT0_OFF_6L & _WRT1_OFF_6L & _WRT2_OFF_6L & _WRT3_OFF_6L
#pragma DATA _CONFIG7L, _EBTR0_OFF_7L & _EBTR1_OFF_7L & _EBTR2_OFF_7L & _EBTR3_OFF_7L
#else
#error "Only _PIC18F4520 and _PIC18F452 devices supported"
#endif // _PIC18F452
#endif // _PIC18F4520

#pragma	CLOCK_FREQ 4000000;

#include "LCD.h"
#include "ADC.h"
#include "monitor.h"

rom char *msgBanner = "VMUSIC Demo V1.0";
rom char *msgLink  = "www.vinculum.com";
rom char *msgError6 = "ERROR ";
rom char *msgNoDisk = "N O  D I S K !  ";
rom char *msgPlay8 = "Playing ";
rom char *msgStop8 = "Stopped ";
rom char *msgPause8 = "Paused  ";

// boundary for button presses between a press and a hold
#define BUTTON_TIMER 1000
// RB0 button pressed
#define BUTTON_FWD 0
// RA4 button pressed
#define BUTTON_REW 1

// timer to ensure file information scrolls at good speed
#define STATUS_TIMER 1000
// wait for a prompt to be received before scanning buttons
#define STATUS_WAITPROMPT 0
// wait for both RB0 and RA4 buttons to be released before scanning buttons
#define STATUS_WAITBUTTON 1
// device is playing
#define STATUS_PLAY       2
// end of file information in bufInfo reached
#define STATUS_SCROLLEND  3
// reset file information display
#define STATUS_RESET      4

char bufInfo[64];
unsigned char opStatus;

//***************************************************************************
// Name: rspPlaying
//
// Description: Load file information from Playing message.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: bufInfo filled with available file information.
//           If ID3 tags: Song Name and Artist Name.
//           No ID3 tags: Filename
//
//***************************************************************************
void rspPlaying()
{
	unsigned char i, j;
	char data;

	// load filename from Playing... message
	// include carriage return at position 12
	for (j = 0; j < 13; j++)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
		bufInfo[j] = data;
	}

    // load info from ID3 tags
	i = 0;
	
    // track number - ignore
	while (1)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
	}

    // song name
	while (1)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
		if (i < 64) bufInfo[i++] = data;
	}

	if (i)
	{
		if (i < 64) bufInfo[i++] = ' ';
		if (i < 64) bufInfo[i++] = '-';
		if (i < 64) bufInfo[i++] = ' ';
	}

    // artist name
	while (1)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
		if (i < 64) bufInfo[i++] = data;
	}

    // album name - ignore
	while (1)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
	}

    // composer - ignore
	while (1)
	{
		data = spiReadWait();
		if (data == 0x0d)
			break;
	}

	// no ID3 tags so use filename instead
	if (!i)
		i = j;

	// zero out remaining space in buffer
	while (i < 64)
	{
		bufInfo[i++] = '\0';
	};
}

//***************************************************************************
// Name: rspTime
//
// Description: Load time information from Time message and update LCD.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: "Playing hh:mm:ss" status information written to LCD.
//
//***************************************************************************
void rspTime()
{
	unsigned char digit;
	unsigned short playTime;
	char i;

	playTime = spiReadWait();
	playTime |= (spiReadWait() << 8);
	// carriage return
	spiReadWait();

	// playing response message - 6 lines of data
	lcdInsWrite(LCD_LINE1);
	for (i = 0; i < 8; i++)
	{
		lcdDataWrite(msgPlay8[i]);
	}

	digit = '0';
	while (playTime >= 36000)
	{
		playTime -= 36000;
		++digit;
	}
	lcdDataWrite(digit);

	digit = '0';
	while (playTime >= 3600)
	{
		playTime -= 3600;
		++digit;
	}
	lcdDataWrite(digit);

	lcdDataWrite(':');

	digit = '0';
	while (playTime >= 600)
	{
		playTime -= 600;
		++digit;
	}
	lcdDataWrite(digit);

	digit = '0';
	while (playTime >= 60)
	{
		playTime -= 60;
		++digit;
	}
	lcdDataWrite(digit);

	lcdDataWrite(':');

	digit = '0';
	while (playTime >= 10)
	{
		playTime -= 10;
		++digit;
	}
	lcdDataWrite(digit);

	digit = '0' + playTime;
	lcdDataWrite(digit);
}

//***************************************************************************
// Name: rspStopped
//
// Description: Update LCD with Stopped message.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: LCD cleared and "Stopped" message written.
//
//***************************************************************************
void rspStopped()
{
	char i;

	lcdInsWrite(LCD_CLR);
	delay_ms(2);

	lcdInsWrite(LCD_LINE1);
	for (i = 0; i < 8; i++)
	{
		lcdDataWrite(msgStop8[i]);
	}

	// zero out remaining space in buffer
	for (i = 0; i < 64; i++)
	{
		bufInfo[i] = '\0';
	};
}

//***************************************************************************
// Name: rspPaused
//
// Description: Update LCD with Paused message.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: "Paused" message written to LCD.
//
//***************************************************************************
void rspPaused()
{
	char i;

	lcdInsWrite(LCD_LINE1);
	for (i = 0; i < 8; i++)
	{
		lcdDataWrite(msgPause8[i]);
	}
}

//***************************************************************************
// Name: rspNoDisk
//
// Description: No Disk message scrolled across LCD.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: "No Disk" message written to LCD.
//           static variable statusPos used to effect scroll left when
//           called repeatedly from main routine.
//
//***************************************************************************
void rspNoDisk()
{
	static char statusPos = 0;
	char i;
	char data;

	lcdInsWrite(LCD_LINE1);
	for (i = 0; i < 16; i++)
	{
		data = ((statusPos + i) & 0x0f);
		lcdDataWrite(msgNoDisk[data]);
	}
	delay_ms(200);
	statusPos++;
}

//***************************************************************************
// Name: opError
//
// Description: Display an error message on the LCD.
//
// Parameters: errNo - error code to display.
//
// Returns: None.
//
// Comments: Displays error as a 2 digit hex code. "ERROR xx"
//
//***************************************************************************
void opError(char errNo)
{
	char i;

	lcdInsWrite(LCD_CLR);
	delay_ms(2); 

	lcdInsWrite(LCD_LINE1);

	for (i = 0; i < 6; i++)
	{
		lcdDataWrite(msgError6[i]);
	}

	if ((errNo>>4) > 9)
		lcdDataWrite((errNo>>4)-10+'A');
	else
		lcdDataWrite((errNo>>4)+'0');

	if ((errNo&0xf) > 9)
		lcdDataWrite((errNo&0xf)-10+'A');
	else
		lcdDataWrite((errNo&0xf)+'0');

	delay_s(1);
}

//***************************************************************************
// Name: opControl
//
// Description: Handle button presses and volume control changes.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: static buttonDelay used to time duration of button presses.
//           static button for stored button state to detect changes.
//           static vol used to store previous volume setting.
//           While stopped: RB0 button to play all, RA4 to play random.
//           While playing: Press RB0 skip next, RA4 skip previous.
//                          Hold RB0 fast forward, RA4 rewind.
//                          Press RB0 and RA4 to pause.
//                          Hold RB0 and RA4 to stop.
//
//***************************************************************************
void opControl()
{
	static unsigned short buttonDelay = 0x0000;
	static unsigned char button = 0xff;
	static unsigned char vol = 0xff;
	char data;

	// no reponse check volume control and buttons
	if (!opStatus.STATUS_WAITPROMPT)
	{
		// poll for volume changes
		data = 0xff - adcRead();
		if (vol != data)
		{
			monCmdSendByteParam(CMD_VSV, data);
			vol = data;
			opStatus.STATUS_WAITPROMPT = 1;
		}
		else
		{
			// poll for button presses
			data = 0;
			data.BUTTON_FWD = portb.0;
			data.BUTTON_REW = porta.4;
			
			if (opStatus.STATUS_WAITBUTTON == 0)
			{
				if (buttonDelay)
				{
					buttonDelay--;
				}

				if ((button) && (data == 0) && (buttonDelay == 0))
				{
					// stop/pause button just pressed
					buttonDelay = BUTTON_TIMER;
				}
				else if ((button == 0) && (data) && (buttonDelay))
				{
					// stop/pause button released - pause
					monCmdSend(CMD_VP);
					rspPaused();
					opStatus.STATUS_WAITPROMPT = 1;
					opStatus.STATUS_WAITBUTTON = 1;
				}
				else if ((button == 0) && (data == 0) && (buttonDelay == 0))
				{
					// stop/pause buttons held - stop
					monCmdSend(CMD_VST);
					opStatus.STATUS_WAITPROMPT = 1;
					opStatus.STATUS_WAITBUTTON = 1;
				}
				else 
				{
					if ((button.BUTTON_FWD == 1) && (data.BUTTON_FWD == 0) && (buttonDelay == 0))
					{
						// play/forward button just pressed
						buttonDelay = BUTTON_TIMER;
					}
					else if ((button.BUTTON_FWD == 0) && (data.BUTTON_FWD == 1) && (buttonDelay))
					{
						// play/forward button released
						if (opStatus.STATUS_PLAY)
						{
							// send skip forward to play next track
							monCmdSend(CMD_VSF);
							opStatus.STATUS_WAITPROMPT = 1;
							opStatus.STATUS_WAITBUTTON = 1;
							opStatus.STATUS_RESET = 1;
						}
						else
						{
							// send VRA command to play music tracks on disk
							monCmdSend(CMD_VRA);
							opStatus.STATUS_WAITBUTTON = 1;
						}
					}
					else if ((button.BUTTON_FWD == 0) && (data.BUTTON_FWD == 0) && (buttonDelay == 0))
					{
						// play/forward button held
						monCmdSend(CMD_VF);
						opStatus.STATUS_WAITPROMPT = 1;
					}
					else if ((button.BUTTON_REW == 1) && (data.BUTTON_REW == 0) && (buttonDelay == 0))
					{
						// play/forward button just pressed
						buttonDelay = BUTTON_TIMER;
					}
					else if ((button.BUTTON_REW == 0) && (data.BUTTON_REW == 1) && (buttonDelay))
					{
						// play/forward button released
						if (opStatus.STATUS_PLAY)
						{
							// send skip forward to play next track
							monCmdSend(CMD_VSB);
							opStatus.STATUS_WAITPROMPT = 1;
							opStatus.STATUS_WAITBUTTON = 1;
							opStatus.STATUS_RESET = 1;
						}
						else
						{
							// send VRR command to play random music tracks on disk
							monCmdSend(CMD_VRR);
							opStatus.STATUS_WAITBUTTON = 1;
						}
					}
					else if ((button.BUTTON_REW == 0) && (data.BUTTON_REW == 0) && (buttonDelay == 0))
					{
						// play/forward button held
						monCmdSend(CMD_VB);
						opStatus.STATUS_WAITPROMPT = 1;
					}
				}
			}

			button = data;

			// check if we have been told to wait for both buttons
			// to be released before processing more requests
			if ((data.BUTTON_FWD) && (data.BUTTON_REW))
			{
				opStatus.STATUS_WAITBUTTON = 0;
			}
		}
	}
}

//***************************************************************************
// Name: opStatus
//
// Description: Display file information on LCD.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: static statusDelay used to time speed of text scrolliong.
//           static statusPos stores position in file information buffer.
//           Scroll holds for 8 counts before shifting data from bufInfo
//           onto LCD.
//
//***************************************************************************
void opStatus()
{
	static unsigned short statusDelay = 0;
	static char statusPos = 0;
	char data;
	char i;

	if (opStatus.STATUS_RESET)
	{
		statusPos = 0;
		statusDelay = 0;
		opStatus.STATUS_RESET = 0;
	}

	// scroll through information buffer
	if (statusDelay)
	{
		statusDelay--;
	}
	else
	{
		statusDelay = STATUS_TIMER;
		if (bufInfo[0])
		{
			lcdInsWrite(LCD_LINE2);
			opStatus.STATUS_SCROLLEND = 1;

			for (i = 0; i < 16; i++)
			{
				// delay start of scroll by 8 counts to allow
				// time to read information
				if (statusPos < 8)
				{
					data = bufInfo[i];
				}
				else if (i + statusPos < 64 + 8)
				{
					data = bufInfo[i + statusPos - 8];
				}
				else
				{
					data = 0;
				}

				// detect run-on past end of buffer and pad with spaces
				if (!data)
				{
					data = ' ';
					if (i == 0)
					{
						opStatus.STATUS_SCROLLEND = 0;
					}
				}

				lcdDataWrite(data);
			}

			// continue or restart scrolling
			if (opStatus.STATUS_SCROLLEND)
			{
				statusPos++;
			}
			else
			{
				statusPos = 0;
			}
		}
	}
}

//***************************************************************************
// Name: main
//
// Description: Main control loop for VMusic PIC Demo.
//
// Parameters: None.
//
// Returns: None.
//
// Comments: Initialises PICDEM 2 PLUS board.
//           Synchronises with the Vinculum Firmware.
//           Puts the firmware into SCS mode.
//           Detects the presence of a disk.
//           Waits for button presses to play, skip, pause and stop.
//           Displays information on LCD.
//
//***************************************************************************
void main()
{
    char data;
	char i;
	enum vResponse resp;

	adcInit();
    lcdInit();
    spiInit();

	lcdInsWrite(LCD_LINE1);
	for (i = 0; i < 16; i++)
	{
		lcdDataWrite(msgBanner[i]);
	}
	lcdInsWrite(LCD_LINE2);
	for (i = 0; i < 16; i++)
	{
		lcdDataWrite(msgLink[i]);
	}

	// wait 2 seconds for banner
	delay_s(2);

	// ensure Vinculum is synchronised
	// ignore all messages and prompts until sync operation completes
	while (1)
	{
		clear_wdt();
		monCmdSend('E');
		while (monPrompt() != Resp_Prompt_UE);
		
		monCmdSend('e');
		if (monPrompt() == Resp_Prompt_LE)
			break;
	};

	// change to Short Command Set Mode
	monCmdSend(CMD_SCS);
	resp = monPrompt();
	if (resp != Resp_Prompt_OK)
	{
		opError(resp);
	}

	// loop to recognise if a disk is connected
	while (1)
	{
		lcdInsWrite(LCD_CLR);
		// wait for clear operation to complete
		delay_ms(2);
		do
		{
			clear_wdt();
			// send carriage return
			monCmdSend(CMD_CR);
			resp = monPrompt();
			
			if (resp == Resp_Prompt_ND)
			{
				rspNoDisk();
			}
		} while (resp != Resp_Prompt_OK);

		rspStopped();

		opStatus = 0;
		bufInfo[0] = '\0';

		do
		{
			clear_wdt();
			resp = monResponse();

			if (resp == Resp_Message_P)
			{
				rspPlaying();
				opStatus.STATUS_PLAY = 1;
				opStatus.STATUS_WAITPROMPT = 0;
				opStatus.STATUS_RESET = 1;
			}
			else if (resp == Resp_Message_T)
			{
				rspTime();
				opStatus.STATUS_PLAY = 1;
			}
			else if (resp == Resp_Message_S)
			{
				rspStopped();
				opStatus.STATUS_PLAY = 0;
			}
			else if (resp == Resp_Prompt_ND)
			{
				// device removed - no action
			}
			else if (resp == Resp_Prompt_OK)
			{
				// no idle processing until prompt received
				opStatus.STATUS_WAITPROMPT = 0;
			}
			else if (resp == Resp_None)
			{
				opControl();
			}

			opStatus();

			// if disk is removed detect this and loop back
			// to No Disk message
		} while (resp != Resp_Prompt_ND);
	}
}    

