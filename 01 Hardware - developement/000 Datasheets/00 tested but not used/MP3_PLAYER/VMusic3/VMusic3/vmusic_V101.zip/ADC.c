#include <system.h>

#include "ADC.h"

//***************************************************************************
//  
//  Constants and variables for LCD
//  
//***************************************************************************

// bit definition for ADC Go
#ifdef _PIC18F4520
#define	ADCON0_GO       1
#endif
#ifdef _PIC18F452
#define	ADCON0_GO       2
#endif

// Initial value of ADCON0 register 
// ADCS Osc/8
// CHS 0
// ADC Enabled
#ifdef _PIC18F4520
#define	ADCON0_SETUP    0x01
#endif
#ifdef _PIC18F452
#define	ADCON0_SETUP    0x41
#endif

// Initial value of ADCON1 register 
// ADCS Osc/8
// RA7:RA1 digital, RA0 analogue
// Result Left justified
#define	ADCON1_SETUP    0x0E

//***************************************************************************
//
// External Routines
//
//***************************************************************************

//***************************************************************************
// Name: adcInit
//
// Description: Initialise the ADC. 
//
// Parameters: None.
//
// Returns: None.
//
// Comments: Sets up pins connecting the ACD to the outside world. 
//
//***************************************************************************
void adcInit()
{
	// Turn A/D conversion on
	adcon0 = ADCON0_SETUP;
	// RA0 is analogue input
	adcon1 = ADCON1_SETUP;
}	

//***************************************************************************
// Name: adcRead
//
// Description: Runs a conversion of the ADC
//
// Parameters: None.
//
// Returns: 8-bit ADC reading.
//
// Comments: 
//
//***************************************************************************
unsigned char adcRead()
{
	adcon0.ADCON0_GO = 1;

	// wait for conversion to finish
	while (adcon0.ADCON0_GO);

	return adresh;
}

