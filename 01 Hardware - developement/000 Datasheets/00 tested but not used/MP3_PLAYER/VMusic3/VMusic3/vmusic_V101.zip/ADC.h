#ifndef ADC_H
#define ADC_H

void adcInit();
unsigned char adcRead();

#endif