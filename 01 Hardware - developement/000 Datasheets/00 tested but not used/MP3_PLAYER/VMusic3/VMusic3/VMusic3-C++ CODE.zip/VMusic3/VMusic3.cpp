#include "VMusic3.h"

// +-------------------+
// | Class Constructor |
// +-------------------+
VMusic3::VMusic3(int pinMISO, int pinMOSI, int pinSCK, int pinSS) {

	/*
	This library uses SPI to communicate with the VMusic3.
	When declaring the class, you need to provide the pin numbers.
	MISO	= brown wire
	MOSI	= orange wire
	SCK		= yellow wire
	SS		= green wire
	*/
	
	// Remember the pins
	// These are used in the transfer() function.
	MISO					= pinMISO;
	MOSI					= pinMOSI;
	SCK						= pinSCK;
	SS						= pinSS;

	// Set their modes
	pinMode(MISO,	INPUT);
	pinMode(MOSI,	OUTPUT);
	pinMode(SCK,	OUTPUT);
	pinMode(SS,		OUTPUT);	
	
	
	// Initialise the attributes.
	volume					= 0;
	keepPlaying				= false;
	repeatFolder			= false;
	randomMode				= false;
	tracks					= 0;
	trackNumber				= 0;
	
	clearTrackInfo();

	mode					= STOPPED;
	diskPresent				= false;
	fileIsOpen				= false;
	lastResponse[0]			= '\0';
	bJustSeeked				= false;
	path		[0]			= '\0';
	filename	[0]			= '\0';

	lookForTrack			= false;
}



void VMusic3::begin() {

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::begin()");
	#endif

	// This function assumes the VMusic3 has just been powered up.
	// See VMusic3.h for info on using an NPN Transistor to switch using a digital IO pin.

	waitForResponse();	// Ignore the blank line
	waitForResponse();	// Ignore the firmware version line.
						// If you want, you can look at lastResponse and extract the firmware version from it.
						// You can always send an FWV command later on though.

	// Put the monitor into "Shortened Command Set" (SCS) mode.
	write('S');
	write('C');
	write('S');
	write(CARRIAGE_RETURN);
	waitForPrompt();
}



unsigned char VMusic3::loop() {

	/*
	Call this function in your sketch's loop().

	Reads from the VMusic3.
	If the data is new, it handles the response.

	returns either SPI_DATA_IS_NEW or SPI_DATA_IS_OLD
	*/
	boolean bFound = false;
	int intTrackTimeDataOffset = 0;

	// if the DD2 event was detected, "lookForTrack" would have been set on the previous pass of loop().
	if (lookForTrack) {

		#ifdef DEBUG_VERBOSE
			Serial.print("Looking for the first track... ");
		#endif

		lookForTrack = false;
		
		// Look in the root directory for tracks.
		getItem(filename, NULL, FIND_TRACK, FIND_FIRST);

		// If no track was found, look in the next directory.
		if (strlen(filename) > 0) {
			bFound = true;
			trackNumber = 1;
		}
		else {
			bFound = findFolderWithTracks(DIR_NEXT, FIND_FIRST);
		}

		#ifdef DEBUG_VERBOSE
			if (bFound) Serial.println("Found.");
			else Serial.println("Not found.");
		#endif

		if (bFound) return VMUSIC_TRACK_CHANGED;
		else return VMUSIC_TRACK_STOPPED;
	}


	// Read from the VMusic3
	// If the response is new...
	int status = getResponse();
	if (status == SPI_DATA_IS_NEW) {

		// Track seconds
		if ((mode == PLAYING) && (lastResponse[0] == 'T') && (lastResponse[1] == SPACE)) {

			// This is a hack to try and fix the bug where a prompt is sometimes muddled with the "T xx" response
			// after a fastForward() or rewind() command while playing.
			if ((bJustSeeked) && (lastResponse[2] == PROMPT)) {
				intTrackTimeDataOffset = 2;
				bJustSeeked = false;
			}

			// Note: numerical data is received LSB first.
			trackSeconds = ((unsigned char)(lastResponse[3 + intTrackTimeDataOffset]) * 256) + (unsigned char)(lastResponse[2 + intTrackTimeDataOffset]);

			#ifdef DEBUG_VERBOSE
				char buffer[21];
				Serial.print("Track Progressed (");
				sprintf(buffer, "0x%02x 0x%02x)+%d: %u", (unsigned char)(lastResponse[2 + intTrackTimeDataOffset]), (unsigned char)(lastResponse[3 + intTrackTimeDataOffset]), intTrackTimeDataOffset, trackSeconds);
				Serial.println(buffer);
			#endif

			return VMUSIC_TRACK_PROGRESSED;
		}

		// Track finished (or device removed while playing).
		// If the device is removed, the "Stopped" event comes in before the "DR2" event.
		if (strcmp(lastResponse, "Stopped") == 0) {
			
			fileIsOpen		= false;
			trackSeconds	= 0;
			bFound			= false;
			
			waitForPrompt(); // <- This also determines if there's still a disk present

			if (!diskPresent) {
				#ifdef DEBUG_VERBOSE
					Serial.println("USB Removed while playing.");
				#endif
				return VMUSIC_USB_REMOVED;
			}

			else if (mode == PLAYING) {

				if (keepPlaying) {
						
					#ifdef DEBUG_VERBOSE
						Serial.println("Keep Playing.");
					#endif
				
					// Next (or Random)
					if (nextTrack()) {
						play();
						#ifdef DEBUG_VERBOSE
							Serial.println("Next Track.");
						#endif
						return VMUSIC_TRACK_CHANGED;
					}
				}
			}

			mode = STOPPED;
			#ifdef DEBUG_VERBOSE
				Serial.println("Track Stopped.");
			#endif
			return VMUSIC_TRACK_STOPPED;
		}

		// Device Detected
		if (strcmp(lastResponse, EVENT_DD2) == 0) {

			diskPresent		= true;
			fileIsOpen		= false;
			mode			= STOPPED;

			clearTrackInfo();

			waitForPrompt();

			// We'll look for tracks on the next pass of the loop.
			// This allows your sketch to display a string like "Searching..." while we walk the directory tree looking for a track to play.
			lookForTrack = true;

			#ifdef DEBUG_VERBOSE
				Serial.println("USB Detected.");
			#endif
			return VMUSIC_USB_DETECTED;
		}

		// Device Removed
		if (strcmp(lastResponse, EVENT_DR2) == 0) {

			diskPresent		= false;
			fileIsOpen		= false;
			mode			= STOPPED;
			path		[0] = '\0';
			filename	[0] = '\0';	
			tracks			= 0;
			trackNumber		= 0;

			clearTrackInfo();

			#ifdef DEBUG_VERBOSE
				Serial.println("USB Removed.");
			#endif
			return VMUSIC_USB_REMOVED;
		}
	}
	return VMUSIC_NONE;
}



void VMusic3::setVolume(byte bytVolume) {

	/*
	Sets the volume.
	"bytVolume" can be a value between 0 and 254.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.print("VMusic3::setVolume(");
		Serial.print(bytVolume);
		Serial.println(")");
	#endif

	bytVolume	= constrain(bytVolume, VOLUME_MIN, VOLUME_MAX);
	volume		= bytVolume; // Remember it

	// Invert the volume so that 0 is minimum and 254 is maximum.
	// It's confusing the other way around.
	bytVolume	= VOLUME_MAX - bytVolume;

	// UM_VinculumFirmware_V205.pdf - page 53.
	write(CMD_VSV);			// Sets playback volume
	write(SPACE);
	write(bytVolume);		// Byte 0x00 max .. 0xFE min
	write(CARRIAGE_RETURN);
	waitForPrompt();
}



boolean VMusic3::loadTrack(char *strPath, char *strFilename, int intTrackNumber, int intMode) {

	/*
	Tries to load a particular track.
	Specify the path and filename of the track, and the trackNumber you want to display.
	intMode can be either STOPPED or PLAYING
	Eg:
	strPath:		"VARIOUS\80S"
	strFilename:	"AIRSUP~1.MP3"
	intTrackNumber:	4
	intMode:		STOPPED

	Why do you need to provide the track number?
	--------------------------------------------
	When looking up tracks, The DIR command doesn't return files in alphabetical order - so
	it's hard to tell which track number the file is.
	There's not enough SRAM to hold an array of tracks for sorting (and determine it's position).	
	Instead, you need to provide it as a parameter.
	Hopefully if you're loading a track, you've remembered it's track number too.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.print("VMusic3::loadTrack(\"");
		Serial.print(strPath);
		Serial.print("\", \"");
		Serial.print(strFilename);
		Serial.print("\", ");
		Serial.print(intTrackNumber);
		Serial.print(", ");
		Serial.print(intMode);
		Serial.println(")");
	#endif

	int		intPos;
	char	strFolder[13];

	lookForTrack = false;

	if (diskPresent) {

		// We can't perform disk operations while a file is open.
		if (fileIsOpen) stop();

		clearTrackInfo();
		trackNumber = 0;

		// If we're not already in the specified folder...
		if (strcmp(path, strPath) != 0) {

			// if we're not in the root directory, we need to go all the way back.
			while (strlen(path) > 0) changeDir("..");

			// Starting at the beginning, we extract each folder name from the path, and try to go into it.
			// Notice the "<=" below? We WANT to see the null terminator, so it can be treated the same as a backslash.
			intPos = 0;
			for (int c = 0; c <= strlen(strPath); c++) {
				
				// Did we find a backslash or null terminator?
				if ((strPath[c] == '\\') || (strPath[c] == '\0')) {
					strlcpy(strFolder, &(strPath[intPos]), c - intPos + 1);
					if (!changeDir(strFolder)) break;
					intPos = c + 1;
				}
			}
		}

		// Did we make it to the specified path?
		if (strcmp(path, strPath) == 0) {
			
			// Try to find the file.
			if (trackExists(strFilename)) {

				// Since we never made a call to findFolderWithTracks(), we need to generate the list here.
				generateShuffledTrackList();

				strlcpy(filename, strFilename, sizeof(filename));
				getTrackInfo(intMode);
				trackNumber = intTrackNumber;
				return true;
			} else nextTrack();
		}
	}

	return false;
}



void VMusic3::play() {

	// Tries to play the current track.
	// Populates the .title, .artist, and .album attributes with the ID3 info if it's available.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::play()");
	#endif

	if (fileIsOpen) stop();

	if (diskPresent && (strlen(filename) > 0)) {
	
		// UM_VinculumFirmware_V205.pdf - page 52.

		write(CMD_VPF);	// Plays a single file 
		write(SPACE);	
		for (byte c = 0; c < strlen(filename) ; c++) write(filename[c]);	
		write(CARRIAGE_RETURN);
		
		waitForResponse();
		
		if (
			(lastResponse[0] == 'P') &&
			(lastResponse[1] == 'l') &&
			(lastResponse[2] == 'a') &&
			(lastResponse[3] == 'y') &&
			(lastResponse[4] == 'i') &&
			(lastResponse[5] == 'n') &&
			(lastResponse[6] == 'g') &&
			(lastResponse[7] == SPACE)
		) {

			fileIsOpen = true;

			// What's the next response?
			// We're expecting either the ID3 Track field, or the 'T' response if there's no ID3 info.
			waitForResponse();

			// If the next response IS NOT 'T' then we assume there's ID3 info coming.
			if (lastResponse[0] != 'T') {

				// Get the ID3 info

				// <Track>
				//strlcpy(track, lastResponse, sizeof(track)); // To save SRAM, we don't store this

				// <Title>
				waitForResponse();
				strlcpy(title, lastResponse, sizeof(title));

				// <Artist>
				waitForResponse();
				strlcpy(artist, lastResponse, sizeof(artist));

				// <Album>
				waitForResponse();
				strlcpy(album, lastResponse, sizeof(album));

				// <Composer>
				waitForResponse();
				//strlcpy(composer, lastResponse, sizeof(composer)); // To save SRAM, we don't store this
			}

			trackSeconds	= 0;
			mode			= PLAYING;

		} else {
			trackNumber		= 0;
			clearTrackInfo();
			mode			= STOPPED;
			fileIsOpen		= false;
		}
	}
}



void VMusic3::pause() {

	// If playing or paused, this toggles between playing/paused.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::pause()");
	#endif

	if (fileIsOpen) {

		if ((mode == PLAYING) || (mode == PAUSED)) {
		
			// UM_VinculumFirmware_V205.pdf - page 53.
			write(CMD_VP);	// Pause playback (unpause if paused)
			write(CARRIAGE_RETURN);
			waitForPrompt();

			// Set the mode
			mode = (mode == PLAYING) ? PAUSED : PLAYING;
		}
	}
}



void VMusic3::stop() {

	// Stops a track.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::stop()");
	#endif

	if (fileIsOpen) {
		write(CMD_VST);	// Stops playback
		write(CARRIAGE_RETURN);
	
		do { waitForResponse(); } while (strcmp(lastResponse, "Stopped") != 0);
		waitForPrompt();

		mode			= STOPPED;
		trackSeconds	= 0;
		fileIsOpen		= false;
	}
}



void VMusic3::fastForward() {

	// Fast forward 5 seconds.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::fastForward()");
	#endif

	if (fileIsOpen) {
		write(CMD_VF);
		write(CARRIAGE_RETURN);
		bJustSeeked = true;
	}
}



void VMusic3::rewind() {
	
	// Rewind 5 seconds.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::rewind()");
	#endif

	if (fileIsOpen) {
		write(CMD_VB);
		write(CARRIAGE_RETURN);
		bJustSeeked = true;
	}
}



boolean VMusic3::prevTrack() {

	/*
	Goes to the previous track, or a random one within the folder.
	If PLAYING, the new track will start playing.
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::prevTrack()");
	#endif

	if (randomMode) return randomTrack(DIR_PREV);
	else return findTrack(DIR_PREV);
}



boolean VMusic3::nextTrack() {

	/*
	Goes to the next track, or a random one within the folder.
	If PLAYING, the new track will start playing.
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::nextTrack()");
	#endif

	if (randomMode) return randomTrack(DIR_NEXT);
	else return findTrack(DIR_NEXT);
}



boolean VMusic3::prevFolder() {

	/*
	Tries to go to the previous folder that has tracks in it.
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::prevFolder()");
	#endif

	return findFolderWithTracks(DIR_PREV, FIND_FIRST);
}



boolean VMusic3::nextFolder() {
	/*
	Tries to go to the next folder that has tracks in it.
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::nextFolder()");
	#endif

	return findFolderWithTracks(DIR_NEXT, FIND_FIRST);
}



// +-------------------+
// | Private Functions |
// +-------------------+
// --------------------------------------------------------------------------------
boolean VMusic3::isFolder(char *strResponse) {

	/*
	Takes a response from the DIR command, and returns true if the item is a folder.
	*/

	int len = strlen(strResponse);
	if (len > 4) {
		return ((strResponse[len - 4] == SPACE) && (strResponse[len - 3] == 'D') && (strResponse[len - 2] == 'I') && (strResponse[len - 1] == 'R'));
	}
	return false;
}



boolean VMusic3::isTrack(char *strResponse) {
	
	/*
	Takes a response from the DIR command, and returns true if the item is an .MP3 or .WMA file.
	*/

	int len = strlen(strResponse);
	if (len > 4) {
		return (
			(strResponse[len - 4] == '.') && 
			(
				((strResponse[len - 3] == 'M') && (strResponse[len - 2] == 'P') && (strResponse[len - 1] == '3')) ||
				((strResponse[len - 3] == 'W') && (strResponse[len - 2] == 'M') && (strResponse[len - 1] == 'A'))
			)
		);
	}
	return false;
}




boolean VMusic3::trackExists(char *strFilename) {

	/*
	Returns true if the file exists within the current folder.
	Also sets the .tracks attribute (number of tracks in the current folder).
	*/

	boolean bFound = false;
	tracks = 0;
	
	if (diskPresent) {
	
		// DIR
		write(CMD_DIR); 
		write(CARRIAGE_RETURN);
		waitForResponse();

		// Go through each file/folder in the current directory.
		while(1) {

			// Done?
			waitForResponse();
			if ((lastResponse[0] == PROMPT) && (lastResponse[1] == '\0')) break;

			// Is the current item an .MP3 or .WMA file?
			if (isTrack(lastResponse)) {
				tracks++;
				
				// Found?
				if (strcmp(strFilename, lastResponse) == 0) bFound = true;

				// We can't break here, because we need to read the rest of the responses to clear them.
			}
		}
	}

	return bFound;
}



boolean VMusic3::changeDir(char *strDir) {

	/*
	Tries to change directory.
	Use ".." to go back one level.
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.print("VMusic3::changeDir(\"");
		Serial.print(strDir);
		Serial.println("\")");
	#endif

	if (diskPresent) {
		
		// Send the CD command
		write(CMD_CD); 
		write(SPACE);	
		for (byte c = 0; c < strlen(strDir) ; c++) write(strDir[c]);	
		write(CARRIAGE_RETURN);

		// Were we successful?
		waitForResponse();
		if (strcmp(lastResponse, RESP_PROMPT) == 0) {

			// We need to maintain a "path" string, since there's no way to ask the VMusic.
			
			// We don't want to append the "." directory to the path.
			if (strcmp(strDir, ".") != 0) {

				if (strcmp(strDir, "..") == 0) {
					// We went up one level. We need to chop that last dir off the path.
					for (int c = strlen(path) - 1; c >= 0; c--) {
						char ch = path[c];
						path[c] = '\0';
						if (ch == '\\') break;
					}
				} else {
					// Append the current directory to the path.
					if (strlen(path) > 0) strcat(path, "\\");
					strcat(path, strDir);
				}

				tracks = 0; // We'll need to call getItem() or fileExists() again at some point to find out how many tracks are in this new folder.
			}

			return true;

		} else return false;
	}
}



void VMusic3::getEndFolder(char *strResult) {

	/*
	Returns the top-level folder in a path.
	Eg: getEndFolder("MUSIC\ARTIST\ALBUM") should return "ALBUM".
	*/

	int pos = 0;
	for (int c = strlen(path) - 1; c >= 0; c--) {
		if (path[c] == '\\') {
			pos = c + 1;
			break;
		}
	}
	strlcpy(strResult, &(path[pos]), 13);
}



void VMusic3::getItem(char *strResult, char *strCurrent, boolean bFolder, int intPosition) {

	/*
	Tries to find a file in the current directory.
	
	strResult will be set to the filename of the item found.
	
	strCurrent specifies an item we want to find either the previous or next item relative to.
	(We can use NULL if looking for the first or last item)

	bFolder specifies if we're looking for a track or folder. Eg: FIND_TRACK, or FIND_FOLDER.

	intPosition determines which item we're looking for. Eg: FIND_FIRST, FIND_PREV, FIND_NEXT, or FIND_LAST.
	*/

	boolean	bIsFolder		= false;
	boolean	bIsTrack		= false;
	boolean bFoundNewBest	= false;

	// Start with nothing.
	strResult[0] = '\0';
	tracks			= 0;

	if (diskPresent) {

		// List files and folders in the the directory
		write(CMD_DIR); 
		write(CARRIAGE_RETURN);
		waitForResponse();

		// Check each item returned by the DIR command.
		while(1) {

			// Prompt = Done.
			waitForResponse();
			if ((lastResponse[0] == PROMPT) && (lastResponse[1] == '\0')) break;

			// What type of item is it?
			bIsFolder	= isFolder(lastResponse);
			bIsTrack	= isTrack(lastResponse);
			if (bIsFolder) {
				lastResponse[strlen(lastResponse) - 4] = '\0'; // Chop off the " DIR" at the end.
				if ((strcmp(lastResponse, ".") == 0) || (strcmp(lastResponse, "..") == 0)) bIsFolder = false;
			}

			if (bIsTrack) tracks++;

			// If we're in folder mode and it's a folder, or we're in track mode and it's a track...
			if ((bFolder && bIsFolder) || (!bFolder && bIsTrack)) {
				
				bFoundNewBest = false;

				// What are we looking for?
				switch (intPosition) {

				case FIND_FIRST:
					if (
						(strlen(strResult) == 0) ||
						(strcmp(lastResponse, strResult) < 0)
					) bFoundNewBest = true;
					break;

				case FIND_PREV:
					// If it's before the "current" dir...
					if (strcmp(lastResponse, strCurrent) < 0) {
						// Set it as the prev one if we haven't found the prev one yet,
						// or this one is after the current prev one.
						if (
							(strlen(strResult) == 0) ||
							(strcmp(lastResponse, strResult) > 0)
						) bFoundNewBest = true;
					}
					break;

				case FIND_NEXT:
					// If it's after the "current" dir...
					if (strcmp(lastResponse, strCurrent) > 0) {
						// Set it as the next one if we haven't found the next one yet,
						// or this one is before the current next one.
						if (
							(strlen(strResult) == 0) ||
							(strcmp(lastResponse, strResult) < 0)
						) bFoundNewBest = true;
					}
					break;

				case FIND_LAST:
					if (
						(strlen(strResult) == 0) ||
						(strcmp(lastResponse, strResult) > 0)
					) bFoundNewBest = true;
					break;
				}
				
				// If a better candidate was found, set it.
				if (bFoundNewBest) strlcpy(strResult, lastResponse, 13);
			}
		}
	}
}



boolean VMusic3::findTrack(int intDir) {

	/*
	tries to find either the previous or next track.
	intDir can be either DIR_PREV or DIR_NEXT

	Returns true if successful.
	*/

	boolean bFileFound	= false;
	int intOldMode		= mode;
	char strResult[13];
		
	strResult[0] = '\0';
	
	// Reset the track info (but NOT the track number).
	// We're assuming the "tracks" attribute has already been set by a previous call to getItem().
	clearTrackInfo();

	if (diskPresent) {
	
		// You must stop a file if it's playing before you can play another one.
		if (fileIsOpen) stop();

		// Are we trying to go to the previous track?
		if (intDir == DIR_PREV) {
			// Can we go back one?
			if (trackNumber > 1) {
				getItem(strResult, filename, FIND_TRACK, FIND_PREV);
				strlcpy(filename, strResult, sizeof(filename));
				trackNumber--;
			} else {
				// No? Then do we loop within the current folder, or go to the previous folder?
				if (repeatFolder) {
					getItem(strResult, filename, FIND_TRACK, FIND_LAST);
					strlcpy(filename, strResult, sizeof(filename));
					trackNumber = tracks;
				} else findFolderWithTracks(DIR_PREV, FIND_LAST);
			}

		} else if (intDir == DIR_NEXT) {

			// Can we go forward one?
			if (trackNumber < tracks) {
				getItem(strResult, filename, FIND_TRACK, FIND_NEXT);
				strlcpy(filename, strResult, sizeof(filename));
				trackNumber++;
			} else {
				// No? Then do we loop within the current folder, or go to the next folder?
				if (repeatFolder) {
					getItem(strResult, filename, FIND_TRACK, FIND_FIRST);
					strlcpy(filename, strResult, sizeof(filename));
					trackNumber = 1;
				} else findFolderWithTracks(DIR_NEXT, FIND_FIRST);
			}
		}

		// Did we find a new track?
		bFileFound = (strlen(filename) > 0);
		if (bFileFound) getTrackInfo(intOldMode); // Get it's info.
	}
	
	return bFileFound;
}



boolean VMusic3::randomTrack(int intDir) {

	// Tries to play a random track within the current folder.

	#ifdef DEBUG_VERBOSE
		Serial.println("VMusic3::randomTrack()");
	#endif

	int intOldMode = mode;
	boolean bFound = false;
	int intTrack = 0;
	int intRandomTrack = 0;

	if (diskPresent) {

		// You must stop a file if it's playing before you can play another one.
		if (fileIsOpen) stop();

		// We have to do an initial call to find out how many tracks are in the current directory.
		getItem(filename, NULL, FIND_TRACK, FIND_FIRST);
		if (tracks == 0) bFound = findFolderWithTracks(DIR_NEXT, FIND_FIRST);
		if (tracks > 0) {

			// Move through the shuffled tracks.
			shuffledIndex += intDir;
			if (shuffledIndex < 0) shuffledIndex = tracks - 1;
			if (shuffledIndex >= tracks) shuffledIndex = 0;

			intRandomTrack = shuffledTracks[shuffledIndex];
	
			// Request the entire track list.
			// This is done because we don't have a list of filenames.
			// We have to just step through to the Nth track.
			write(CMD_DIR); 
			write(CARRIAGE_RETURN);
			waitForResponse(); // blank line

			while(1) {

				// Done?
				waitForResponse();
				if ((lastResponse[0] == PROMPT) && (lastResponse[1] == '\0')) break;

				// Found?
				if (isTrack(lastResponse)) {
					intTrack++;
					
					if (intTrack == intRandomTrack) {
						strlcpy(filename, lastResponse, sizeof(filename));
						bFound = true;
						trackNumber = intRandomTrack;
					}

					// We can't break here, because we need to read the rest of the responses to clear them.
				}
			}

			// File found?
			if (bFound) getTrackInfo(intOldMode);
		}
	}

	return bFound;
}



boolean VMusic3::findFolder(int intDir) {

	/*
	Tries to go to the previous or next folder in the directory tree.
	Use intDir = DIR_PREV or DIR_NEXT
	
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.print("VMusic3::findFolder(");
		Serial.print(intDir);
		Serial.println(")");
	#endif

	char strCameOutOf	[13]; // Which folder were we just in?
	char strResult		[13]; // Used below to find the first, prev, next, or last folder.

	boolean bFound;
	boolean bGoDeep; // ...oh my.
	
	strCameOutOf[0] = '\0';
	strResult	[0] = '\0';
	
	// Reset the track info
	filename[0] = '\0';
	trackNumber	= 0;
	clearTrackInfo();

	if (diskPresent) {
	
		// You must stop a file if it's playing before you can play another one.
		if (fileIsOpen) stop();

		// Which direction are we going?
		if (intDir == DIR_PREV) {

			bGoDeep = false;

			// Can we go back one level?
			if (strlen(path) == 0) {
				bGoDeep = true;
			} else {
			
				// Which folder are we coming out of?
				getEndFolder(strCameOutOf);

				// Come out.
				changeDir("..");

				// Look at the subfolders, and find the prev one (if any).
				getItem(strResult, strCameOutOf, FIND_FOLDER, FIND_PREV);

				// If there is one, go into it.
				if (strlen(strResult) > 0) {
					changeDir(strResult);
					bGoDeep = true;
				}			
			}
			
			if (bGoDeep) {

				// Now go as deep as we can always choosing the last folder within each.
				bFound = false;
				while (!bFound) {
				
					// Look at the subfolders, and find the last one (if any).
					getItem(strResult, NULL, FIND_FOLDER, FIND_LAST);

					// Go deeper?
					if (strlen(strResult) > 0) changeDir(strResult);
					else bFound = true;
				}
			}
		
		} else { // dir == DIR_NEXT

			// Look at the subfolders, and find the first one (if any).
			getItem(strResult, NULL, FIND_FOLDER, FIND_FIRST);

			// Can we go deeper into the tree?
			if (strlen(strResult) > 0) {
				changeDir(strResult);
				bFound = true;
			
			} else {

				// Can't go deeper? Then we have to go back one level, then to the next one (if any).
				// So, are we able to go back?
				bFound = false;
				while ((strlen(path) > 0) && !bFound) {

					// Which folder are we coming out of?
					getEndFolder(strCameOutOf);

					// Come out.
					changeDir("..");

					// Look at the subfolders, and find the next one (if any).
					getItem(strResult, strCameOutOf, FIND_FOLDER, FIND_NEXT);

					// If there is one, go into it.
					if (strlen(strResult) > 0) {
						changeDir(strResult);
						bFound = true;
					}
				}
			}
		}
	}

	return bFound;
}



boolean VMusic3::findFolderWithTracks(int intDir, int intTrackPosition) {

	/*
	Walks the directory tree, looking for a folder with tracks in it.
	Generates the shuffledTracks list for use in .randomMode.

	intDir can be either DIR_PREV or DIR_NEXT

	intTrackPosition can be either FIND_FIRST or FIND_LAST
	
	Returns true if successful.
	*/

	#ifdef DEBUG_VERBOSE
		Serial.print("VMusic3::findFolderWithTracks(");
		Serial.print(intDir);
		Serial.print(", ");
		Serial.print(intTrackPosition);
		Serial.println(")");
	#endif
	
	char strPathStartedIn[VMUSIC_PATH_LENGTH + 1];
	int intOldMode		= mode;
	byte bytOldVolume	= volume;
	boolean bFileFound	= false;

	filename[0] = '\0';
	trackNumber	= 0;
	clearTrackInfo();
	strlcpy(strPathStartedIn, path, sizeof(strPathStartedIn));

	// Keep going to the prev/next folder until we find some track, or we come back to where we started.
	while (1) {

		// go to the Next / Prev folder.
		findFolder(intDir);
		
		// Try to find a track within the folder.
		if (randomMode) {
			// Random?
			randomTrack(DIR_NEXT);
			bFileFound = (strlen(filename) > 0);
		} else {
			// Either the FIRST or LAST track.
			getItem(filename, NULL, FIND_TRACK, intTrackPosition);
			bFileFound = (strlen(filename) > 0);
			if (bFileFound) {
				getTrackInfo(intOldMode);
				trackNumber = (intTrackPosition == FIND_FIRST) ? 1 : intTrackPosition = tracks;
			}
		}

		if (bFileFound) break;

		// Just incase we've made a complete loop of all the folders, and still not found any track,
		// we better exit, otherwise it will be an infinite loop.
		if (strcmp(strPathStartedIn, path) == 0) break;
	}

	// Do we need to generate the shuffledTracks[] list?
	if (bFileFound) generateShuffledTrackList();

	return bFileFound;
}



void VMusic3::generateShuffledTrackList() {

	// Creates a shuffled list to traverse when in .randomMode.
	// Note: "tracks" has already been counted in a previous call to getItem().

	int t, r;
	byte temp;

	// Reset the index.
	shuffledIndex = 0;

	// First, create an ordered list of tracks.
	for (t = 0; t < tracks; t++) shuffledTracks[t] = t + 1; // Track numbers start at 1.

	// Next, we shuffle them (by going through each track position, and swapping it with a random position).
	randomSeed(millis());
	for (t = 0; t < tracks; t++) {
		
		// Pick a random position to swap with.
		r = random(tracks);

		// Swap 'em.
		temp = shuffledTracks[t];
		shuffledTracks[t] = shuffledTracks[r];
		shuffledTracks[r] = temp;
	}
}



void VMusic3::clearTrackInfo() {

	/*
	We have to do this often enough. It might as well be a function.
	*/
	
	trackSeconds	= 0;
	
	// ID3 stuff.
	//track		[0] = '\0';
	title		[0] = '\0';
	artist		[0] = '\0';
	album		[0] = '\0';
	//composer	[0] = '\0';
}


void VMusic3::getTrackInfo(int intMode) {

	/*
	There's no command in the VMusic3 to read the ID3 info from a track.
	Instead, we need to play it.
	
	Once we've got the ID3 info, we can set it to PLAYING, PAUSED, or STOPPED.
	*/

	byte bytOldVolume = volume;
	
	// Turn the volume all the way down if we're not playing.
	if (intMode != PLAYING) setVolume(0);

	play(); // to get the ID3 info.

	// Turn it back up, now that we have the track info.
	if (intMode != PLAYING) {
		stop();
		setVolume(bytOldVolume);
	}
}



void VMusic3::waitForResponse() {
	
	// Waits for a response.
	// Fills the lastResponse string.

	while (getResponse() == SPI_DATA_IS_OLD);
}



void VMusic3::waitForPrompt() {

	/*
	Keeps checking for responses until one of the following is read:
	 - Successful Command Prompt (means a disk is present)
	 - Command Failed
	 - No Disk
	 - Device Removed

	This function also set the diskPresent attribute to false if a DR2 event is encountered.
	*/

	while (1) {
		waitForResponse();

		// Successful Prompt (SCS)
		if ((lastResponse[0] == PROMPT) && (lastResponse[1] == '\0')) return;

		// Successful Prompt (ECS) (just incase we didn't get into SCS mode quickly enough in the ::begin() function).
		if (strcmp(lastResponse, "D:\\>") == 0) {
			write('S');
			write('C');
			write('S');
			write(CARRIAGE_RETURN);
			waitForResponse();
			return;
		}

		// Command Failed?
		// This seems to happen when the device is removed while a song is playing.
		// If we don't add a delay, the "DR2" event that's expected next is broken.
		if (strcmp(lastResponse, "Command Failed") == 0) delay(100);

		// No Disk or Device Removed
		if (
			(strcmp(lastResponse, RESP_ND) == 0) || 
			(strcmp(lastResponse, EVENT_DR2) == 0)
		) {

			diskPresent		= false;
			fileIsOpen		= false;
			mode			= STOPPED;

			path		[0] = '\0';
			filename	[0] = '\0';
			trackNumber		= 0;

			clearTrackInfo();
			
			return;
		}
	}
}



unsigned char VMusic3::getResponse() {
	
	/*
	Fills the lastResponse string if the data is new.
	
	Returns either SPI_DATA_IS_OLD or SPI_DATA_IS_NEW.
	*/

	char	ch;
	int		index				= 0;
	boolean	bReadingTrackTime	= false;

	// Only read a response if it's new.
	while ((read(&ch) == SPI_DATA_IS_NEW)) {

		// "T " is a special case. If we're playing, we read 'T', ' ', then two bytes, then a carriage return.
		// We need to do it this way, because otherwise 13 seconds would be interpretted as a carriage return.
		if ((mode == PLAYING) && (index == 2) && (lastResponse[0] == 'T') && (lastResponse[1] == SPACE)) bReadingTrackTime = true;
		
		// Stop if a carriage return is reached (after two more byte, if reading track seconds).
		if (bReadingTrackTime) {

			if ((index >= 4) && (ch == CARRIAGE_RETURN)) {
				#ifdef DEBUG_GETRESPONSE
					Serial.println(lastResponse);
				#endif
				return SPI_DATA_IS_NEW;
			}
		} else {
			if (ch == CARRIAGE_RETURN) {
				#ifdef DEBUG_GETRESPONSE
					Serial.println(lastResponse);
				#endif
				return SPI_DATA_IS_NEW;
			}
		}

		// Build the lastResponse string.
		lastResponse[index++] = ch;
		lastResponse[index] = '\0';
	}

	return SPI_DATA_IS_OLD;
}



unsigned char VMusic3::transfer(unsigned char RWbit, char *pSpiData) {

	/*
	SPI isn't a strict protocol. The VMusic3 uses it's own variation.
	
	We can't use the built-in Arduino SPI.h library because the VMusic3 rely's on 
	a few extra bits (like the Address bit, and the status bit).

	See DS_VMUSIC3.pdf - "7.1 SPI Interface Timing" - page 7	

		- Bring SS pin high	
		- Write 1 Start bit
		- Write 1 R/W bit								LOW = Write					HIGH = Read
		- Write 1 Address bit							LOW = Status Register		HIGH = Data Register
		- Read or Write 8 data bits
		- Read 1 status bit				When reading:	LOW	= This data is new		HIGH = This data is old
										When writing:	LOW	= Write was successful	HIGH = VMusic's buffer is full :(
		- Bring SS pin low
		- Idle 1 cycle
	*/
	
	char retData;
	unsigned char bitData;
	
	// Bring SS high to select the VMusic3
	digitalWrite(SS, HIGH);

	// Start bit
	digitalWrite(MOSI, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, LOW);

	// R/W bit (LOW = Write. HIGH = Read)
	digitalWrite(MOSI, RWbit);
	SPI_DELAY;
	digitalWrite(SCK, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, LOW);

	// ADD bit (LOW = Status Register. HIGH = Data Register)
	digitalWrite(MOSI, LOW);

	SPI_DELAY;
	digitalWrite(SCK, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, LOW);

	// Next 8 bits - Data Phase
	bitData = 0x80;
	if (RWbit) {
		
		// read operation (MSB transmitted first)
		retData = 0;

		while (bitData) {
			SPI_DELAY;
			retData |= digitalRead(MISO) ? bitData : 0;
			digitalWrite(SCK, HIGH);
			SPI_DELAY;
			digitalWrite(SCK, LOW);
			bitData = bitData >> 1;
		}

		*pSpiData = retData;
	} else {
		
		// write operation 
		retData = *pSpiData;

		while (bitData) {
			digitalWrite(MOSI, (retData & bitData) ? 1 : 0); 
			SPI_DELAY;
			digitalWrite(SCK, HIGH);
			SPI_DELAY;
			digitalWrite(SCK, LOW);
			bitData = bitData >> 1;
		}
	}

	/* Status bit
	For Reading:
		LOW		= This data is new
		HIGH	= This data is old. The read cycle needs to be repeated to get new data

	For Writing:
		LOW		= Write was successful
		HIGH	= VMusic3's buffer is full. Write failed
	*/

	SPI_DELAY;
	bitData = digitalRead(MISO);
	digitalWrite(SCK, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, LOW);

	// SS goes low to disable SPI communications
	digitalWrite(SS, LOW);

	// stay low for one clock cycle
	SPI_DELAY;
	digitalWrite(SCK, HIGH);
	SPI_DELAY;
	digitalWrite(SCK, LOW);

    return bitData;
}



unsigned char VMusic3::read(char *pSpiData) {

	/*
	Reads a character from the SPI bus and returns the status bit (LOW = success. HIGH = failed).
	
	Returns either SPI_DATA_IS_OLD or SPI_DATA_IS_NEW.
	*/

	return transfer(SPI_READ, pSpiData);
}



void VMusic3::write(char spiData) {
	
	// Keeps trying until a character is transmitted on the SPI bus.

	while (transfer(SPI_WRITE, &spiData));
}