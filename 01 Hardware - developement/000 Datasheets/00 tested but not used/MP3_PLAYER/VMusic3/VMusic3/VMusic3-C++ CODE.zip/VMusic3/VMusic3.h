/*
+-----------+
| VMusic3.h |
+-----------+

By Andrew Wyatt
retrojdm.com

Started:		2013-09-22
Updated:		2014-12-06

Last Change:	.randomMode chooses from a shuffled list (generated when opening the folder), instead of a random track.


--------------------------------------------------------------------------------


Powering via a digital IO pin
-----------------------------
If you power the VMusic3 directly with 5V, when you reset the Arduino the
VMusic3 won't reset properly.

You _could_ always disconnect then reconnect the Arduino's power, but that can
be inconvenient.

I wanted the VMusic3 to reset each time I reset the Arduino or clicked "Upload".
So, to ensure the VMusic3 is reset when the Arduino is, I use a digital IO to
power it.

There's a problem though...
The digital IO's don't provide enough current to power the VMusic3 (USB sticks
suck down a lot of power!).

As a solution, I connect the VMusic3's 5V power via an NPN transistor.
In sketches, before calling vmusic.begin(), I first write HIGH to the digital
IO.

			   _________
	         /           \
	        /    BC548    \
	       / NPN Transistor\
	       |_______________|
	         |     |     |
	         |     |     |
	         |     |     |
	(collector) (base) (emitter)
	   Arduino   IO     VMusic3
	        5V   pin    5V



SPI
---
This library uses SPI to communicate with the VMusic3.
You'll need to change the UART/SPI jumper to SPI mode (middle pin to GND pin).



VMusic2 vs VMusic3
------------------
I only have a VMusic3 to test with, so I'm not sure if the VMusic2 works with
this library.
The firmware this library was developed on is "V2MSC1.0.0"
If your VMusic2 doesn't work, you could try upgrading to that firmware.



5V or 3.3V data?
----------------
Some websites say the communication pins are 3.3V only, but they work just fine
for me at 5V. I've tested successfully with an Arduino Uno R3 and Mega 2560
(both are 5V boards).

If you're paranoid (like me), you can use a logic level converter to 3.3V for
the data lines.



Running out of SRAM
-------------------
The VMusic3 class can potentially use a lot of SRAM. The 5x 256 byte ID3 fields
add up to 1285 bytes (including the null terminators).
The Uno only has 2k available :(

To conserve SRAM, I'm ignoring the Track and Composer ID3 fields, and only
storing the first 64 characters of the Title, Artist, and Album fields.
To increase/decrease the 64 character limit, change VMUSIC_ID3_STRING_LENGTH
below.

Also, I'm limiting the path length to 130 characters. This is enough for
nesting at least 10 folders within eachother (since each folder name can be up
to 12 characters long, plus the backslashes).
Again, you can change VMUSIC_PATH_LENGTH below, depending on your needs.

See http://arduino.cc/en/Tutorial/Memory
"If you run out of SRAM, your program may fail in unexpected ways; it will
appear to upload successfully, but not run, or run strangely."

--------------------------------------------------------------------------------
*/

// +-----------+
// | Debugging |
// +-----------+
// These two options are particularly helpful in seeing what's actually going on.
// They both output to the Serial Monitor.

// Uncomment this line if you want to read what responses the VMusic is sending.
//#define DEBUG_GETRESPONSE

// Uncomment this line if you want to follow the flow of the code as it happens.
//#define DEBUG_VERBOSE



#ifndef VMusic3_h
#define VMusic3_h

#include "Arduino.h"


// +----------+
// | #Defines |
// +----------+

// Event codes returned by .loop();
#define VMUSIC_NONE					0
#define VMUSIC_USB_DETECTED			1
#define VMUSIC_USB_REMOVED			2
#define VMUSIC_TRACK_STOPPED		3
#define VMUSIC_TRACK_CHANGED		4
#define VMUSIC_TRACK_PROGRESSED		6

// .mode
#define STOPPED						0
#define PLAYING						1
#define PAUSED						2

// .volume
#define VOLUME_MIN					0
#define VOLUME_MAX					254

// .findTrack() and .findFolder()
#define DIR_PREV					-1
#define DIR_NEXT					1

#define FIND_TRACK					false
#define FIND_FOLDER					true

#define FIND_FIRST					1
#define FIND_PREV					2
#define FIND_NEXT					3
#define FIND_LAST					4

#define VMUSIC_RESPONSE_BUFFER		256	// Don't change this one. The VMusic can return up to 256 chacters in a response.

// Maximum string lengths (Be careful not to run out of SRAM messing with these)
#define VMUSIC_ID3_STRING_LENGTH	64	// ID3 strings can be up to 256 characters. Reduce these if you're running out of SRAM.
#define VMUSIC_PATH_LENGTH			130	// 130 characters should be enough for nesting 10 folders within eachother.

#define MAX_SHUFFLED_TRACKS			255 // 0..255. A shuffled list of track numbers is generated when a new folder is opened (instead of just picking a random track).
										// There's a limitation of doing it this way where, if there's more than this many tracks in a folder, it will only play these ones.

// SPI communication
#define SPI_WRITE					LOW
#define SPI_READ					HIGH

/*
The SPI transfer() function uses a NOP to create a very short delay.														
The Arduino Uno and Mega 2560 both run at 16Mhz.
A NOP is ok to use, since the VMusic's SPI interface can run up to 24Mhz.
I could probably have used the delayMicroseconds() function aswell. */
#define SPI_DELAY					__asm__("nop\n\t")

#define SPI_DATA_IS_NEW				LOW
#define SPI_DATA_IS_OLD				HIGH
#define SPI_WRITE_SUCCEEDED			LOW
#define SPI_WRITE_FAILED			HIGH

// Special characters
#define CARRIAGE_RETURN				0x0D
#define SPACE						0x20 // ' '
#define PROMPT						0x3E // '>'
#define NULL_TERMINATOR				0x00 // '\0'

// Command Responses
// UM_VinculumFirmware_V205.pdf - Page 18
#define RESP_PROMPT	">"		// Successful Command Prompt
#define RESP_ND		"ND"	// No Disk
#define RESP_BC		"BC"	// Bad Command					Command not recognised
#define RESP_CF		"CF"	// Command Failed				Filename or directory name not found
#define RESP_DF		"DF"	// Disk Full					No free space on disk
#define RESP_FI		"FI"	// Invalid						Attempt to open a directory for reading or writing. Attempt to change currently selected directory to a file
#define RESP_RO		"RO"	// Read Only					Attempt to open a read only file for writing
#define RESP_FO		"FO"	// File Open					A file is currently open for writing and must be closed before this command can be executed
#define RESP_NE		"NE"	// Dir Not Empty				Attempt to delete a directory which is not empty
#define RESP_FN		"FN"	// Filename Invalid				Firmware invalid or contains disallowed characters
#define RESP_NU		"NU"	// No Upgrade					Firmware Upgrade file not found on disk

// Monitor Events
// UM_VinculumFirmware_V205.pdf - Page 20
#define EVENT_DD1	"DD1"	// Device Detected P1			Device inserted in USB Port 1
#define EVENT_DR1	"DR1"	// Device Removed P1			Device removed from USB Port 1
#define EVENT_DD2	"DD2"	// Device Detected P2			Device inserted in USB Port 2
#define EVENT_DR2	"DR2"	// Device Removed P2			Device removed from USB Port 2
#define EVENT_SDA	"SDA"	// Slave Enabled				Connected to Host Device
#define EVENT_SDD	"SDD"	// Slave Disabled				Disconnected from Host Device

// Monitor Configuration Commands
// UM_VinculumFirmware_V205.pdf - Page 22
#define CMD_SCS		0x10	// 10 0D						Switches to shortened command set
#define CMD_ECS		0x11	// 11 0D						Switches to extended command set
#define CMD_IPA		0x90	// 90 0D						Monitor commands use ASCII values
#define CMD_IPH		0x91	// 91 0D						Monitor commands use binary values
#define CMD_SBD		0x14	// 14 20 divisor 0D				Change monitor baud rate
#define CMD_FWV		0x13	// 13 0D						Display firmware version

// Disk Commands
// UM_VinculumFirmware_V205.pdf - Page 26
#define CMD_DIR		0x01	// 01 0D						List files in current directory
							// 01 20 file 0D				List specified file and size
#define CMD_CD		0x02	// 02 0D						Change current directory
							// 02 20 2E 2E 0D				Move up one directory level
#define CMD_RD		0x04	// 04 20 file 0D				Reads a whole file
#define CMD_DLD		0x05	// 05 20 file 0D				Delete subdirectory from current directory
#define	CMD_MKD		0x06	// 06 20 file 0D				Make a new subdirectory in the current directory
							// 06 20 file 20 datetime 0D	Also specify a file date and time
#define CMD_DLF		0x07	// 07 20 file 0D				Delete a file
#define	CMD_WRF		0x08	// 08 20 dword 0D data			Write the number of bytes specified in the 1st parameter to the currently open file
#define	CMD_OPW		0x09	// 09 20 file 0D				Open a file for writing or create a new file
							// 09 20 file 20 datetime 0D	Also specify a file date and time
#define CMD_CLF		0x0A	// 0A 20 file 0D				Close the currently open file
#define CMD_RDF		0x0B	// 0B 20 dword 0D				Read the number of bytes specified in the 1st parameter from the currently open file
#define CMD_REN		0x0C	// 0C 20 file 20 file 0D		Rename a file or directory
#define CMD_OPR		0x0E	// 0E 20 file 0D				Open a file for reading
							// 0E 20 file 20 date 0D		Also specify a file access date
#define CMD_SEK		0x28	// 28 20 dword 0D				Seek to the byte position specified by the 1st parameter in the currently open file
#define CMD_FS		0x12	// 12 0D						Returns the free space available on disk if less than 4GB is free
#define CMD_FSE		0x93	// 93 0D						Returns the free space available on disk
#define CMD_IDD		0x0F	// 0F 0D						Display information about the disk if disk is less than 4GB
#define CMD_IDDE	0x0F	// 94 0D						Display information about the disk
#define CMD_DSN		0x2D	// 2D 0D						Display disk serial number
#define CMD_DVL		0x2E	// 2E 0D						Display disk volume label
#define CMD_DIRT	0x2E	// 2F 20 file 0D				List specified file and date and time of create, modify and file access

// VMUSIC Commands
// UM_VinculumFirmware_V205.pdf - Page 52
#define CMD_VPF		0x1D	// 1D 20 file 0D				Plays a single file
#define CMD_VRF		0x89	// 89 20 file 0D				Repeatedly plays a single file
#define CMD_VST		0x20	// 20 0D						Stops playback
#define CMD_V3A		0x21	// 21 0D						Plays all MP3 files
#define CMD_VRA		0x8A	// 8A 0D						Repeatedly plays all MP3 files
#define CMD_VRR		0x8F	// 8F 0D						Repeatedly plays random MP3 files
#define CMD_VSF		0x25	// 25 0D						Skip forward one track
#define CMD_VSB		0x26	// 26 0D						Skip back one track
#define CMD_VSD		0x8E	// 8E 0D						Skip forward one whole directory
#define CMD_VP		0x8B	// 8B 0D						Pause playback
#define CMD_VF		0x8C	// 8C 0D						Fast forward 5 seconds
#define CMD_VB		0x8D	// 8D 0D						Rewind 5 seconds
#define CMD_VRD		0x1F	// 1F 20 byte 0D				Reads command register
#define CMD_VWR		0x1E	// 1E 20 byte word 0D			Writes command register
#define CMD_VSV		0x88	// 88 20 byte 0D				Sets playback volume


class VMusic3 {
	
public:		
	// +-------------------+
	// | Class Constructor |
	// +-------------------+
	// MISO	= brown wire
	// MOSI	= orange wire
	// SCK	= yellow wire
	// SS	= green wire
	VMusic3(int pinMISO, int pinMOSI, int pinSCK, int pinSS);


	// +-------------------+
	// | Public Attributes |
	// +-------------------+

	byte			volume;			// 0..254
	boolean			keepPlaying;	// Try to play another track when the current one finishes?
	boolean			repeatFolder;	// Play only tracks within the current folder?
	boolean			randomMode;		// Play a random track within the current folder?

	// Track info
	unsigned int	tracks;			// Number of tracks in current folder (updated by findItem() )
	unsigned int	trackNumber;	// Position of track in the folder
	unsigned int	trackSeconds;	// When playing, how far into the song are we?
	//char			track			[VMUSIC_ID3_STRING_LENGTH + 1];	// To try and save SRAM, we're not going to store the track.
	char			title			[VMUSIC_ID3_STRING_LENGTH + 1];
	char			artist			[VMUSIC_ID3_STRING_LENGTH + 1];
	char			album			[VMUSIC_ID3_STRING_LENGTH + 1];
	//char			composer		[VMUSIC_ID3_STRING_LENGTH + 1];	// To try and save SRAM, we're not going to store the composer.
	
	byte			mode;			// 0 = Stopped		1 = playing		2 = paused
	boolean			diskPresent;
	boolean			fileIsOpen;

									/*	"path" can potentially be a very long string. Luckily everything's in 8.3 format!
										131 bytes allows us to go a max of 10 levels deep ((12 chars + '/' * 13) + null terminator)
										If your USB is organised into more than 10 levels of sub-directories, you're gonna have problems. */
	char			path			[VMUSIC_PATH_LENGTH + 1];

	char			filename		[13];	// 8.3 format = 12 characters + null terminator.


	// +------------------+
	// | Public Functions |
	// +------------------+
	void			begin			();
	unsigned char	loop			(); // Returns an event code if something changed.
	void			setVolume		(byte bytVolume);	// min 0..254 max
	boolean			loadTrack		(char *strPath, char *strFilename, int intTrackNumber, int intMode);
	
	// Player controls.
	void			play			();
	void			pause			(); // Toggles between playing and paused.
	void			stop			();
	void			fastForward		();
	void			rewind			();
	boolean			prevTrack		();
	boolean			nextTrack		();
	boolean			prevFolder		();
	boolean			nextFolder		();



private:

	// +--------------------+
	// | Private Attributes |
	// +--------------------+
	int				MISO, MOSI, SCK, SS;
	char			lastResponse			[VMUSIC_RESPONSE_BUFFER + 1];
	boolean			bJustSeeked;		// This is a hack to try and fix the bug where a prompt is sometimes muddled with the "T xx" response
										// after a fastForward() or rewind() command while playing.
	
	boolean			lookForTrack;		/*	This is set by vmusic.loop() when it sees a DD2 event.
											In your sketch's loop, watching for .diskPresent changing to true allows you to
											display a "Searching..." string and perhaps try to load a specific track with
											the loadTrack() function.
											Otherwise, the next pass of the loop will try to find the first track. */

	byte			shuffledTracks	[MAX_SHUFFLED_TRACKS]; // The list of tracks, shuffled when the folder a new opened.
	int				shuffledIndex;

	// +-------------------+
	// | Private Functions |
	// +-------------------+
	boolean			isFolder				(char *strResponse);
	boolean			isTrack					(char *strResponse);
	boolean			trackExists				(char *strFilename);
	boolean			changeDir				(char *strDir);
	
	void			getEndFolder			(char *strResult);
	void			getItem					(char *strResult, char *strCurrent, boolean bFolder, int intPosition);
	boolean			findTrack				(int intDir);
	boolean			randomTrack				(int intDir);	
	boolean			findFolder				(int intDir);
	boolean			findFolderWithTracks	(int intDir, int intTrackPosition);

	void			generateShuffledTrackList();
	void			clearTrackInfo			();
	void			getTrackInfo			(int intMode);
	
	void			waitForResponse			();
	void			waitForPrompt			();
	unsigned char	getResponse				();
	void			handleResponse			(char *strResponse);
	unsigned char	transfer				(unsigned char RWbit, char *pSpiData);
	unsigned char	read					(char *pSpiData);
	void			write					(char spiData);
};

#endif