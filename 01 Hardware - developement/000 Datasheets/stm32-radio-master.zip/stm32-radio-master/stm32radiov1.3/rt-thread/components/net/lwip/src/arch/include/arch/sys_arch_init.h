#ifndef __LWIP_SYS_INIT_H__
#define __LWIP_SYS_INIT_H__

void lwip_sys_init();

#endif
