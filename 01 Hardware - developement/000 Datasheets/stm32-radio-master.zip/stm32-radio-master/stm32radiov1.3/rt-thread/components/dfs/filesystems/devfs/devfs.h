#ifndef __DEVICE_FS_H__
#define __DEVICE_FS_H__

#include <rtthread.h>

int devfs_init(void);

#endif
