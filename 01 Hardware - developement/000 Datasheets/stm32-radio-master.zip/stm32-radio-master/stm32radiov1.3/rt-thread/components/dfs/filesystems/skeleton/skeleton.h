#ifndef __SKELETON_H__
#define __SKELETON_H__

#include <rtthread.h>

int dfs_skt_init(void);

#endif
