#ifndef __NFS_H__
#define __NFS_H__

int nfs_init(void);

#endif
