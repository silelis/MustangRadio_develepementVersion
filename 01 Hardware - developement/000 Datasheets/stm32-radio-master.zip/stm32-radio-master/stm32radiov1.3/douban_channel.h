#ifndef __DOUBAN_CHANNEL_H__
#define __DOUBAN_CHANNEL_H__

#include <rtgui/widgets/workbench.h>

void douban_channel_view(rtgui_workbench_t* workbench);

#endif
