# Contributing

* Use Pull Requests.
* Before working on big changes, talk with the devs on Slack.
* We don\'t want half-done PRs, and won\'t complete them for you.
* Read the [PR guidelines](https://github.com/Alexey-Yakovenko/deadbeef/wiki/Organizing-your-changes-for-pull-requests).
