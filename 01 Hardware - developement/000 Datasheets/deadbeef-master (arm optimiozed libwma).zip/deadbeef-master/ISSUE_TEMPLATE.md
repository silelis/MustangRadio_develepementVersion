### Steps to reproduce the problem

### What's going on? Describe the problem in as much detail as possible.

### Information about the software:

Deadbeef version:
OS:

