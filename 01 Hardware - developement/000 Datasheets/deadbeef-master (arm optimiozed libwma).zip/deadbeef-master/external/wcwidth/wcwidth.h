#ifndef WCWIDTH_H
#define WCWIDTH_H

#include <wchar.h>

int mk_wcwidth(wchar_t ucs);

#endif /* WCWIDTH_H */

