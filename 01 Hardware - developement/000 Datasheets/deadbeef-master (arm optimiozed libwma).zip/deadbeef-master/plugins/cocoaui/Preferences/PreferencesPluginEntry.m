//
//  PreferencesPluginEntry.m
//  PreferencesPluginEntry
//
//  Created by Oleksiy Yakovenko on 19/07/2021.
//  Copyright © 2021 Oleksiy Yakovenko. All rights reserved.
//

#import "PreferencesPluginEntry.h"

@implementation PreferencesPluginEntry

@end
