//
//  AlbumArtImageView.m
//  ddbcore
//
//  Created by Oleksiy Yakovenko on 21/03/2021.
//  Copyright © 2021 Oleksiy Yakovenko. All rights reserved.
//

#import "AlbumArtImageView.h"

@implementation AlbumArtImageView

- (NSSize)intrinsicContentSize {
    return NSMakeSize(32,32);
}

@end
