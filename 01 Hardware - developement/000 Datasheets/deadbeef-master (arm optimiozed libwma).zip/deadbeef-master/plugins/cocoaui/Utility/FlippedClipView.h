//
//  FlippedClipView.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 4/22/19.
//  Copyright © 2019 Oleksiy Yakovenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface FlippedClipView : NSClipView

@end

NS_ASSUME_NONNULL_END
