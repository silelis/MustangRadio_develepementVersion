//
//  TableViewWithReturnAction.h
//  deadbeef
//
//  Created by Oleksiy Yakovenko on 21/11/2021.
//  Copyright © 2021 Oleksiy Yakovenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewWithReturnAction : NSTableView

@end

NS_ASSUME_NONNULL_END
