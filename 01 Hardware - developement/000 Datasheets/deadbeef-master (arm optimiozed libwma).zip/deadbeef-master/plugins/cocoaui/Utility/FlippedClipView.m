//
//  FlippedClipView.m
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 4/22/19.
//  Copyright © 2019 Oleksiy Yakovenko. All rights reserved.
//

#import "FlippedClipView.h"

@implementation FlippedClipView

- (BOOL)isFlipped {
    return YES;
}

@end
