//
//  NowPlayable.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 11/4/19.
//  Copyright © 2019 Oleksiy Yakovenko. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NowPlayable : NSObject

@end

NS_ASSUME_NONNULL_END
