//
//  PropertySheetContentView.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 2/10/20.
//  Copyright © 2020 Oleksiy Yakovenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface PropertySheetContentView : NSView

@property (nonatomic) NSSize contentSize;

@end


NS_ASSUME_NONNULL_END
