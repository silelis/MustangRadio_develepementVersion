//
//  HelpWindowController.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 6/12/19.
//  Copyright © 2019 Oleksiy Yakovenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface HelpWindowController : NSWindowController

@property (nullable, nonatomic) NSURL *contentURL;

@end

NS_ASSUME_NONNULL_END
