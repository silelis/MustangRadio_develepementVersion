//
//  ScopeSettings.m
//  deadbeef
//
//  Created by Oleksiy Yakovenko on 30/10/2021.
//  Copyright © 2021 Oleksiy Yakovenko. All rights reserved.
//

#import "ScopeSettings.h"

@implementation ScopeSettings

@end
