/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Customized view for macOS
*/

#import <Metal/Metal.h>
#import <AppKit/AppKit.h>
#import "AAPLView.h"

@interface AAPLNSView : AAPLView

@end
