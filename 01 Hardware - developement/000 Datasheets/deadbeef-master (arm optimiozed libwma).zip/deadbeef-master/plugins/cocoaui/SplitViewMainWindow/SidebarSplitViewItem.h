//
//  SidebarSplitViewItem.h
//  SplitViewApp
//
//  Created by Oleksiy Yakovenko on 7/6/20.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface SidebarSplitViewItem : NSSplitViewItem

@end

NS_ASSUME_NONNULL_END
