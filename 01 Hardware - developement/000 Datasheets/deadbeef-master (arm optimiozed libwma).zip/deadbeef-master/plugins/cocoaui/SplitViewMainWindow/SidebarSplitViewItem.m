//
//  SidebarSplitViewItem.m
//  SplitViewApp
//
//  Created by Oleksiy Yakovenko on 7/6/20.
//

#import "SidebarSplitViewItem.h"

@implementation SidebarSplitViewItem

- (NSSplitViewItemBehavior)behavior {
    return NSSplitViewItemBehaviorSidebar;
}

@end
