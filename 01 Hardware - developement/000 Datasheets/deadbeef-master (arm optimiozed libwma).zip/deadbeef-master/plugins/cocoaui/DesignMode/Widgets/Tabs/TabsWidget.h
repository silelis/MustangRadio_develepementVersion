//
//  TabsWidget.h
//  deadbeef
//
//  Created by Oleksiy Yakovenko on 18/11/2021.
//  Copyright © 2021 Oleksiy Yakovenko. All rights reserved.
//

#import "WidgetBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface TabsWidget : WidgetBase

@end

NS_ASSUME_NONNULL_END
