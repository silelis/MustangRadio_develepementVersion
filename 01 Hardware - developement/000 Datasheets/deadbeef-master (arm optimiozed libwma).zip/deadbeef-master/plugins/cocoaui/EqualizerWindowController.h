//
//  EqualizerWindowController.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 1/29/20.
//  Copyright © 2020 Oleksiy Yakovenko. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface EqualizerWindowController : NSWindowController

@end

NS_ASSUME_NONNULL_END
