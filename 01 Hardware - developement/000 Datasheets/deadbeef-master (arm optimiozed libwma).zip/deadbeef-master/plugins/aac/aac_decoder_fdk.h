//
//  aac_decoder_fdk.h
//  DeaDBeeF
//
//  Created by Oleksiy Yakovenko on 4/4/20.
//  Copyright © 2020 Oleksiy Yakovenko. All rights reserved.
//

#ifndef aac_decoder_fdk_h
#define aac_decoder_fdk_h

#include "aac_decoder_protocol.h"

aacDecoderHandle_t *
aacDecoderOpenFDK (void);

#endif /* aac_decoder_fdk_h */
