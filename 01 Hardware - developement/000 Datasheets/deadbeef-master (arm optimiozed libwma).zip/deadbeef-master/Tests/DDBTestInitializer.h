//
//  DDBTestInitializer.h
//  Tests
//
//  Created by Oleksiy Yakovenko on 19/06/2018.
//  Copyright © 2018 Oleksiy Yakovenko. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DDBTestInitializer : NSObject

@end
