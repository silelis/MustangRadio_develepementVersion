﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button4 = New System.Windows.Forms.Button
        Me.Button6 = New System.Windows.Forms.Button
        Me.Button7 = New System.Windows.Forms.Button
        Me.Button8 = New System.Windows.Forms.Button
        Me.Button11 = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lblRadioClock = New System.Windows.Forms.Label
        Me.lblSLS = New System.Windows.Forms.Label
        Me.lblDataRate = New System.Windows.Forms.Label
        Me.lblEnsemble = New System.Windows.Forms.Label
        Me.lblDABChannels = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblSignal = New System.Windows.Forms.Label
        Me.imgStereo = New System.Windows.Forms.PictureBox
        Me.lblStatus = New System.Windows.Forms.Label
        Me.lblMode = New System.Windows.Forms.Label
        Me.imgVolume = New System.Windows.Forms.PictureBox
        Me.lblProgramName = New System.Windows.Forms.Label
        Me.lblProgramText = New System.Windows.Forms.Label
        Me.lblProgramType = New System.Windows.Forms.Label
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button9 = New System.Windows.Forms.Button
        Me.Button10 = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.btnSetting = New System.Windows.Forms.Button
        Me.btnPreset8 = New System.Windows.Forms.Button
        Me.btnPreset9 = New System.Windows.Forms.Button
        Me.btnPreset5 = New System.Windows.Forms.Button
        Me.btnPreset2 = New System.Windows.Forms.Button
        Me.btnPreset3 = New System.Windows.Forms.Button
        Me.btnPreset4 = New System.Windows.Forms.Button
        Me.btnPreset6 = New System.Windows.Forms.Button
        Me.btnPreset7 = New System.Windows.Forms.Button
        Me.btnPreset1 = New System.Windows.Forms.Button
        Me.btnPreset0 = New System.Windows.Forms.Button
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Button3 = New System.Windows.Forms.Button
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.imgStereo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgVolume, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(16, 150)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 56)
        Me.Button2.TabIndex = 2
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(97, 150)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 56)
        Me.Button4.TabIndex = 4
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(97, 332)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 56)
        Me.Button6.TabIndex = 6
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(16, 332)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 56)
        Me.Button7.TabIndex = 7
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button8.BackColor = System.Drawing.SystemColors.ControlText
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(16, 270)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 56)
        Me.Button8.TabIndex = 8
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.ControlText
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(97, 270)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 56)
        Me.Button11.TabIndex = 14
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 50
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.Font = New System.Drawing.Font("Score Board", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.ForeColor = System.Drawing.Color.OrangeRed
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 30
        Me.ListBox1.Location = New System.Drawing.Point(177, 150)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(320, 240)
        Me.ListBox1.TabIndex = 32
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Black
        Me.Panel1.Controls.Add(Me.lblRadioClock)
        Me.Panel1.Controls.Add(Me.lblSLS)
        Me.Panel1.Controls.Add(Me.lblDataRate)
        Me.Panel1.Controls.Add(Me.lblEnsemble)
        Me.Panel1.Controls.Add(Me.lblDABChannels)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.lblSignal)
        Me.Panel1.Controls.Add(Me.imgStereo)
        Me.Panel1.Controls.Add(Me.lblStatus)
        Me.Panel1.Controls.Add(Me.lblMode)
        Me.Panel1.Controls.Add(Me.imgVolume)
        Me.Panel1.Controls.Add(Me.lblProgramName)
        Me.Panel1.Controls.Add(Me.lblProgramText)
        Me.Panel1.Controls.Add(Me.lblProgramType)
        Me.Panel1.Location = New System.Drawing.Point(16, 15)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(640, 129)
        Me.Panel1.TabIndex = 33
        '
        'lblRadioClock
        '
        Me.lblRadioClock.AutoSize = True
        Me.lblRadioClock.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRadioClock.ForeColor = System.Drawing.Color.Gray
        Me.lblRadioClock.Location = New System.Drawing.Point(479, 87)
        Me.lblRadioClock.Name = "lblRadioClock"
        Me.lblRadioClock.Size = New System.Drawing.Size(161, 17)
        Me.lblRadioClock.TabIndex = 47
        Me.lblRadioClock.Text = "00:00:00 00/00/00"
        '
        'lblSLS
        '
        Me.lblSLS.AutoSize = True
        Me.lblSLS.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSLS.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblSLS.Location = New System.Drawing.Point(190, 104)
        Me.lblSLS.Name = "lblSLS"
        Me.lblSLS.Size = New System.Drawing.Size(0, 17)
        Me.lblSLS.TabIndex = 46
        '
        'lblDataRate
        '
        Me.lblDataRate.AutoSize = True
        Me.lblDataRate.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDataRate.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.lblDataRate.Location = New System.Drawing.Point(490, 104)
        Me.lblDataRate.Name = "lblDataRate"
        Me.lblDataRate.Size = New System.Drawing.Size(26, 17)
        Me.lblDataRate.TabIndex = 45
        Me.lblDataRate.Text = "--"
        '
        'lblEnsemble
        '
        Me.lblEnsemble.AutoSize = True
        Me.lblEnsemble.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEnsemble.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblEnsemble.Location = New System.Drawing.Point(560, 104)
        Me.lblEnsemble.Name = "lblEnsemble"
        Me.lblEnsemble.Size = New System.Drawing.Size(26, 17)
        Me.lblEnsemble.TabIndex = 44
        Me.lblEnsemble.Text = "--"
        '
        'lblDABChannels
        '
        Me.lblDABChannels.AutoSize = True
        Me.lblDABChannels.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDABChannels.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.lblDABChannels.Location = New System.Drawing.Point(341, 104)
        Me.lblDABChannels.Name = "lblDABChannels"
        Me.lblDABChannels.Size = New System.Drawing.Size(17, 17)
        Me.lblDABChannels.TabIndex = 43
        Me.lblDABChannels.Text = "0"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Red
        Me.Label2.Location = New System.Drawing.Point(225, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 17)
        Me.Label2.TabIndex = 42
        Me.Label2.Text = "DAB Channels"
        '
        'lblSignal
        '
        Me.lblSignal.AutoSize = True
        Me.lblSignal.Font = New System.Drawing.Font("Score Board", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSignal.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.lblSignal.Location = New System.Drawing.Point(537, 20)
        Me.lblSignal.Name = "lblSignal"
        Me.lblSignal.Size = New System.Drawing.Size(21, 21)
        Me.lblSignal.TabIndex = 41
        Me.lblSignal.Text = "0"
        '
        'imgStereo
        '
        Me.imgStereo.Image = CType(resources.GetObject("imgStereo.Image"), System.Drawing.Image)
        Me.imgStereo.Location = New System.Drawing.Point(498, 13)
        Me.imgStereo.Margin = New System.Windows.Forms.Padding(0)
        Me.imgStereo.Name = "imgStereo"
        Me.imgStereo.Size = New System.Drawing.Size(32, 36)
        Me.imgStereo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.imgStereo.TabIndex = 40
        Me.imgStereo.TabStop = False
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStatus.ForeColor = System.Drawing.Color.LightSkyBlue
        Me.lblStatus.Location = New System.Drawing.Point(405, 104)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(89, 17)
        Me.lblStatus.TabIndex = 38
        Me.lblStatus.Text = "searching"
        '
        'lblMode
        '
        Me.lblMode.AutoSize = True
        Me.lblMode.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMode.ForeColor = System.Drawing.Color.Red
        Me.lblMode.Location = New System.Drawing.Point(372, 104)
        Me.lblMode.Name = "lblMode"
        Me.lblMode.Size = New System.Drawing.Size(35, 17)
        Me.lblMode.TabIndex = 37
        Me.lblMode.Text = "MOD"
        '
        'imgVolume
        '
        Me.imgVolume.Image = CType(resources.GetObject("imgVolume.Image"), System.Drawing.Image)
        Me.imgVolume.Location = New System.Drawing.Point(589, 3)
        Me.imgVolume.Name = "imgVolume"
        Me.imgVolume.Size = New System.Drawing.Size(48, 48)
        Me.imgVolume.TabIndex = 36
        Me.imgVolume.TabStop = False
        '
        'lblProgramName
        '
        Me.lblProgramName.AutoSize = True
        Me.lblProgramName.Font = New System.Drawing.Font("Ozone", 30.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.lblProgramName.Location = New System.Drawing.Point(1, 0)
        Me.lblProgramName.Name = "lblProgramName"
        Me.lblProgramName.Size = New System.Drawing.Size(329, 44)
        Me.lblProgramName.TabIndex = 34
        Me.lblProgramName.Text = "6th Logic DAB+"
        '
        'lblProgramText
        '
        Me.lblProgramText.AutoSize = True
        Me.lblProgramText.Font = New System.Drawing.Font("Score Board", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramText.ForeColor = System.Drawing.Color.Red
        Me.lblProgramText.Location = New System.Drawing.Point(3, 55)
        Me.lblProgramText.Name = "lblProgramText"
        Me.lblProgramText.Size = New System.Drawing.Size(0, 33)
        Me.lblProgramText.TabIndex = 33
        '
        'lblProgramType
        '
        Me.lblProgramType.Font = New System.Drawing.Font("Score Board", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProgramType.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblProgramType.Location = New System.Drawing.Point(8, 104)
        Me.lblProgramType.Name = "lblProgramType"
        Me.lblProgramType.Size = New System.Drawing.Size(169, 20)
        Me.lblProgramType.TabIndex = 32
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 50
        '
        'Button9
        '
        Me.Button9.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.Location = New System.Drawing.Point(97, 210)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 56)
        Me.Button9.TabIndex = 10
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.Location = New System.Drawing.Point(16, 210)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 56)
        Me.Button10.TabIndex = 12
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(16, 394)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 56)
        Me.Button1.TabIndex = 34
        Me.Button1.UseVisualStyleBackColor = True
        '
        'btnSetting
        '
        Me.btnSetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSetting.Image = CType(resources.GetObject("btnSetting.Image"), System.Drawing.Image)
        Me.btnSetting.Location = New System.Drawing.Point(176, 394)
        Me.btnSetting.Margin = New System.Windows.Forms.Padding(0)
        Me.btnSetting.Name = "btnSetting"
        Me.btnSetting.Size = New System.Drawing.Size(320, 56)
        Me.btnSetting.TabIndex = 35
        Me.btnSetting.UseVisualStyleBackColor = True
        '
        'btnPreset8
        '
        Me.btnPreset8.AllowDrop = True
        Me.btnPreset8.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset8.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset8.ForeColor = System.Drawing.Color.White
        Me.btnPreset8.Image = CType(resources.GetObject("btnPreset8.Image"), System.Drawing.Image)
        Me.btnPreset8.Location = New System.Drawing.Point(502, 394)
        Me.btnPreset8.Name = "btnPreset8"
        Me.btnPreset8.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset8.TabIndex = 45
        Me.btnPreset8.UseVisualStyleBackColor = True
        '
        'btnPreset9
        '
        Me.btnPreset9.AllowDrop = True
        Me.btnPreset9.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset9.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset9.ForeColor = System.Drawing.Color.White
        Me.btnPreset9.Image = CType(resources.GetObject("btnPreset9.Image"), System.Drawing.Image)
        Me.btnPreset9.Location = New System.Drawing.Point(583, 394)
        Me.btnPreset9.Name = "btnPreset9"
        Me.btnPreset9.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset9.TabIndex = 44
        Me.btnPreset9.UseVisualStyleBackColor = True
        '
        'btnPreset5
        '
        Me.btnPreset5.AllowDrop = True
        Me.btnPreset5.BackColor = System.Drawing.SystemColors.ControlText
        Me.btnPreset5.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset5.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset5.ForeColor = System.Drawing.Color.White
        Me.btnPreset5.Image = CType(resources.GetObject("btnPreset5.Image"), System.Drawing.Image)
        Me.btnPreset5.Location = New System.Drawing.Point(583, 270)
        Me.btnPreset5.Name = "btnPreset5"
        Me.btnPreset5.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset5.TabIndex = 43
        Me.btnPreset5.UseVisualStyleBackColor = False
        '
        'btnPreset2
        '
        Me.btnPreset2.AllowDrop = True
        Me.btnPreset2.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset2.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset2.ForeColor = System.Drawing.Color.White
        Me.btnPreset2.Image = CType(resources.GetObject("btnPreset2.Image"), System.Drawing.Image)
        Me.btnPreset2.Location = New System.Drawing.Point(502, 210)
        Me.btnPreset2.Name = "btnPreset2"
        Me.btnPreset2.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset2.TabIndex = 42
        Me.btnPreset2.UseVisualStyleBackColor = True
        '
        'btnPreset3
        '
        Me.btnPreset3.AllowDrop = True
        Me.btnPreset3.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset3.FlatAppearance.BorderSize = 0
        Me.btnPreset3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset3.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset3.ForeColor = System.Drawing.Color.White
        Me.btnPreset3.Image = CType(resources.GetObject("btnPreset3.Image"), System.Drawing.Image)
        Me.btnPreset3.Location = New System.Drawing.Point(583, 210)
        Me.btnPreset3.Name = "btnPreset3"
        Me.btnPreset3.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset3.TabIndex = 41
        Me.btnPreset3.UseVisualStyleBackColor = True
        '
        'btnPreset4
        '
        Me.btnPreset4.AllowDrop = True
        Me.btnPreset4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btnPreset4.BackColor = System.Drawing.SystemColors.ControlText
        Me.btnPreset4.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset4.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset4.ForeColor = System.Drawing.Color.White
        Me.btnPreset4.Image = CType(resources.GetObject("btnPreset4.Image"), System.Drawing.Image)
        Me.btnPreset4.Location = New System.Drawing.Point(502, 270)
        Me.btnPreset4.Name = "btnPreset4"
        Me.btnPreset4.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset4.TabIndex = 40
        Me.btnPreset4.UseVisualStyleBackColor = False
        '
        'btnPreset6
        '
        Me.btnPreset6.AllowDrop = True
        Me.btnPreset6.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset6.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset6.ForeColor = System.Drawing.Color.White
        Me.btnPreset6.Image = CType(resources.GetObject("btnPreset6.Image"), System.Drawing.Image)
        Me.btnPreset6.Location = New System.Drawing.Point(502, 332)
        Me.btnPreset6.Name = "btnPreset6"
        Me.btnPreset6.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset6.TabIndex = 39
        Me.btnPreset6.UseVisualStyleBackColor = True
        '
        'btnPreset7
        '
        Me.btnPreset7.AllowDrop = True
        Me.btnPreset7.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset7.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset7.ForeColor = System.Drawing.Color.White
        Me.btnPreset7.Image = CType(resources.GetObject("btnPreset7.Image"), System.Drawing.Image)
        Me.btnPreset7.Location = New System.Drawing.Point(583, 332)
        Me.btnPreset7.Name = "btnPreset7"
        Me.btnPreset7.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset7.TabIndex = 38
        Me.btnPreset7.UseVisualStyleBackColor = True
        '
        'btnPreset1
        '
        Me.btnPreset1.AllowDrop = True
        Me.btnPreset1.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset1.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset1.ForeColor = System.Drawing.Color.White
        Me.btnPreset1.Image = CType(resources.GetObject("btnPreset1.Image"), System.Drawing.Image)
        Me.btnPreset1.Location = New System.Drawing.Point(583, 150)
        Me.btnPreset1.Name = "btnPreset1"
        Me.btnPreset1.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset1.TabIndex = 37
        Me.btnPreset1.UseVisualStyleBackColor = True
        '
        'btnPreset0
        '
        Me.btnPreset0.AllowDrop = True
        Me.btnPreset0.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnPreset0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnPreset0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnPreset0.Font = New System.Drawing.Font("Century Gothic", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPreset0.ForeColor = System.Drawing.Color.White
        Me.btnPreset0.Image = CType(resources.GetObject("btnPreset0.Image"), System.Drawing.Image)
        Me.btnPreset0.Location = New System.Drawing.Point(502, 150)
        Me.btnPreset0.Name = "btnPreset0"
        Me.btnPreset0.Size = New System.Drawing.Size(75, 56)
        Me.btnPreset0.TabIndex = 36
        Me.btnPreset0.UseVisualStyleBackColor = True
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 500
        '
        'PictureBox1
        '
        Me.PictureBox1.ImageLocation = """"""
        Me.PictureBox1.Location = New System.Drawing.Point(177, 150)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(320, 240)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 46
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'Button3
        '
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(97, 394)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 56)
        Me.Button3.TabIndex = 47
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Timer4
        '
        Me.Timer4.Enabled = True
        Me.Timer4.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlText
        Me.ClientSize = New System.Drawing.Size(669, 466)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnPreset8)
        Me.Controls.Add(Me.btnPreset9)
        Me.Controls.Add(Me.btnPreset5)
        Me.Controls.Add(Me.btnPreset2)
        Me.Controls.Add(Me.btnPreset3)
        Me.Controls.Add(Me.btnPreset4)
        Me.Controls.Add(Me.btnPreset6)
        Me.Controls.Add(Me.btnPreset7)
        Me.Controls.Add(Me.btnPreset1)
        Me.Controls.Add(Me.btnPreset0)
        Me.Controls.Add(Me.btnSetting)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DAB+ FM Demo Software by Sixth Logic"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.imgStereo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgVolume, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblProgramName As System.Windows.Forms.Label
    Friend WithEvents lblProgramText As System.Windows.Forms.Label
    Friend WithEvents lblProgramType As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents imgVolume As System.Windows.Forms.PictureBox
    Friend WithEvents lblStatus As System.Windows.Forms.Label
    Friend WithEvents lblMode As System.Windows.Forms.Label
    Friend WithEvents imgStereo As System.Windows.Forms.PictureBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnSetting As System.Windows.Forms.Button
    Friend WithEvents lblSignal As System.Windows.Forms.Label
    Friend WithEvents btnPreset8 As System.Windows.Forms.Button
    Friend WithEvents btnPreset9 As System.Windows.Forms.Button
    Friend WithEvents btnPreset5 As System.Windows.Forms.Button
    Friend WithEvents btnPreset2 As System.Windows.Forms.Button
    Friend WithEvents btnPreset3 As System.Windows.Forms.Button
    Friend WithEvents btnPreset4 As System.Windows.Forms.Button
    Friend WithEvents btnPreset6 As System.Windows.Forms.Button
    Friend WithEvents btnPreset7 As System.Windows.Forms.Button
    Friend WithEvents btnPreset1 As System.Windows.Forms.Button
    Friend WithEvents btnPreset0 As System.Windows.Forms.Button
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents lblDABChannels As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lblEnsemble As System.Windows.Forms.Label
    Friend WithEvents lblDataRate As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblSLS As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents lblRadioClock As System.Windows.Forms.Label
    Friend WithEvents Timer4 As System.Windows.Forms.Timer

End Class
