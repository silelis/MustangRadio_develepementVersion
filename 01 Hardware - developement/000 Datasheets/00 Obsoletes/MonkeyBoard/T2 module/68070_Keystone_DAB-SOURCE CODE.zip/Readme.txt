Cortrol program for monkeyboard DAB+ 

this program controls the module through the device "/dev/ttyACM0".
If this is incorrect for your setup, you have to change your setup (udev...) or the  sourcecode (Keystone_DAB.c).
FM is not supported.

"make install" install the library in "/usr/lib". You hhave to be "root" to do this.

"make" compiles the program, the binary is called "Keystone_DAB"

After the start the program "Keystone_DAB" initializes the module and tunes to the first channel in the list of the module.
The program can be controrolled over the TCP-port 20000 (you can change this through commandline).

With "telnet localhost 20000" you can connect to the program and control the module through the following commands (confirm with "enter"):

"A" deletes the list in the module an searches from 5A to 13F

"S" searches from 5A to 13F

"V" turn the volume up

"v" turn the volume down

'Number' switch to the channel in "list.txt" (first channel in list = 1, second channel = 2, and so on) 

"m" mute or unmute

"Q" Quit


The program writes the folowing files in the directory from it was started (not in the prgram folder, it can be the same):

"name.txt"         channelname
"text.txt"         radiotext
"rate.txt"         bitrate 
"strength.txt"     quality in %
"Ensemble.txt"     nsm of the ensemble
"list.txt"         channellist in the module, it is written after a search

*.jpg *.png *.apng pictures from the slideshwow. The filename comes from the broadcasting station. Old files will be not erased!
To display the correct image, you have to use the newest image.

The pragram saves often on the disk. But this shoud be no problem for actual hardware.

The first parameter at the commandline controls the channal after starting teh program, teh second the TCP-port.
Example: "Keysteone_DAB 4 8000" means channel 4 and TCP-port 8000.

When you want to control the program with single shell commands (for example "echo "8" | netcat localhost 20000"), 
so uncomment the two lines at the end of the "Keystone_DAB.c" and compile it again.
                   


