#ifndef _SLIDESHOW_H_
#define _SLIDESHOW_H_
extern void GetImage();
#endif
