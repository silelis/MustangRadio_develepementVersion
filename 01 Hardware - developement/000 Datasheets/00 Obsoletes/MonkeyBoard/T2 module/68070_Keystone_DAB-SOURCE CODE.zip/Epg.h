#ifndef _EPG_H_
#define _EPG_H_

#include "datatype.h"

#define  MAX_PI_PER_SERVICE     500
#define  MAX_SERVICE			32

typedef struct  _DATE_SETTING {
	uint8 u8Day;	
	uint8 u8Week;	
	uint8 u8Month;	
	uint8 u8Year;
}DATE_SETTING;

typedef struct _Clock{
    uint32 u32MJD;
    uint8 u8Hour;
    uint8 u8Minute;
}Clock;

typedef struct _Programe{
        uint8 pu8MediumName[60];
        Clock stClock;
        uint8 pu8Discription[250];
}Programe;

typedef struct _Service{
	uint16 u16EnsembleID;
	uint32 u32ServiceID;
	uint8  u8ServCompID;
	Programe pstPI[MAX_PI_PER_SERVICE];
	uint16 u16PINum;
}Service;

extern void EpgApp(void);
extern BOOL GetEpg(uint16 u16EnsembleID,uint32 u32ServiceID,uint8 u8ServCompID,Service *pServ);
extern void  RTC_GetClock(DATE_SETTING * stDate,uint32 u32MJD);
extern void UTLSTR_Hex8ToDecimalString(uint8 hex, uint8 fill_len, uint8 fill_char, uint8 *buf);
extern void UTLSTR_Hex16ToDecimalString(uint16 hex, uint8 fill_len, uint8 fill_char,uint8 *buf);

#endif

