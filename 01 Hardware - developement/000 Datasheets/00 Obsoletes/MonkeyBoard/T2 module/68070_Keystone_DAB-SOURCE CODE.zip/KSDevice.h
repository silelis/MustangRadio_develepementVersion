
#include "datatype.h"

typedef enum {
	KSReset_REBOOT         = 0,
	KSReset_REBOOT_AND_CLEAR          = 1,	
}KSReset;

typedef enum {
	KSMode_DAB         = 0,
	KSMode_FM          = 1,
	KSMode_BEEPER      = 3,
	KSMode_UNKNOWN      = 0xFF,
}KSMode;

typedef enum {
	KSStatus_PLAYING         = 0,
	KSStatus_SEARCHING          = 1,
	KSStatus_TUNNING      = 2,
	KSStatus_STOP      = 3,
	KSStatus_UNKNOWN            = 0xFF,
}KSStatus;

typedef enum {
	KSStereo_STEREO         = 0,
	KSStereo_JOINTSTEREO          = 1,
	KSStereo_DUALCHANNEL      = 2,
	KSStereo_SINGLECHANNEL      = 3,
	KSStereo_UNKNOWN            = 0xFF,
}KSStereo;

typedef enum {
	KSStereoMode_MONO         = 0,
	KSStereoMode_STEREO          = 1,	
	KSStereoMode_UNKNOWN          = 0xFF,
}KSStereoMode;

typedef enum {
	KSSorter_ENSEMBLE		=0,
	KSSorter_Name			=1,
	KSSorter_UNKNOWN		=0xFF,
}KSSorterType;

typedef enum {
	KSSampleRate_32KHZ         = 1,
	KSSampleRate_24KHZ          = 2,
	KSSampleRate_48KHZ      = 3,
	KSSampleRate_UNKNOWN      = 0xFF,	
}KSSampleRate;

typedef enum {
	KSTextStatus_NoText         = 0,
	KSTextStatus_GotNewText          = 1,	
	KSTextStatus_HasText          = 2,	
	KSTextStatus_Error         = 0xFF,
}KSTextStatus;

typedef enum {
	KSProgType_None = 0,	
	KSProgType_News = 1,	
	KSProgType_CurrentAffairs = 2,
	KSProgType_Information = 3,	
	KSProgType_Sport = 4,
	KSProgType_Education = 5,	
	KSProgType_Drama = 6,	
	KSProgType_Arts = 7,
	KSProgType_Science = 8,	
	KSProgType_Talk = 9,
	KSProgType_PopMusic = 10,	
	KSProgType_RockMusic = 11,
	KSProgType_EasyListening = 12, 	
	KSProgType_LightClassical = 13,
	KSProgType_ClassicalMusic = 14,
	KSProgType_OtherMusic = 15,
	KSProgType_Weather = 16,	
	KSProgType_Finance = 17,
	KSProgType_Childrens = 18,
	KSProgType_Factual = 19,	
	KSProgType_Religion = 20,
	KSProgType_PhoneIn = 21,
	KSProgType_Travel = 22,
	KSProgType_Leisure = 23,
	KSProgType_JazzandBlues = 24,	
	KSProgType_ContryMusic = 25,
	KSProgType_NationalMusic = 26,	
	KSProgType_OldiesMusic = 27,
	KSProgType_FolkMusic = 28,
	KSProgType_Documentary = 29,
	KSProgType_Undefined1 = 30,
	KSProgType_Undefined2 = 31,
	KSProgType_UNKNOWN = 0xFF,
}KSProgType;


typedef enum {
	//BAND 3
	KSFreq_BAND3_5A         = 0,
	KSFreq_BAND3_5B         = 1,
	KSFreq_BAND3_5C         = 2,
	KSFreq_BAND3_5D         = 3,
	KSFreq_BAND3_6A         = 4,
	KSFreq_BAND3_6B         = 5,
	KSFreq_BAND3_6C         = 6,
	KSFreq_BAND3_6D         = 7,	
	KSFreq_BAND3_7A         = 8,
	KSFreq_BAND3_7B         = 9,
	KSFreq_BAND3_7C         = 10,
	KSFreq_BAND3_7D         = 11,
	KSFreq_BAND3_8A         = 12,
	KSFreq_BAND3_8B         = 13,
	KSFreq_BAND3_8C         = 14,
	KSFreq_BAND3_8D         = 15,		
	KSFreq_BAND3_9A         = 16,
	KSFreq_BAND3_9B         = 17,
	KSFreq_BAND3_9C         = 18,
	KSFreq_BAND3_9D         = 19,	
	KSFreq_BAND3_10A         = 20,
	KSFreq_BAND3_10N         = 21,	
	KSFreq_BAND3_10B         = 22,
	KSFreq_BAND3_10C         = 23,
	KSFreq_BAND3_10D         = 24,	
	KSFreq_BAND3_11A         = 25,
	KSFreq_BAND3_11N         = 26,	
	KSFreq_BAND3_11B         = 27,
	KSFreq_BAND3_11C         = 28,
	KSFreq_BAND3_11D         = 29,	
	KSFreq_BAND3_12A         = 30,
	KSFreq_BAND3_12N         = 31,	
	KSFreq_BAND3_12B         = 32,
	KSFreq_BAND3_12C         = 33,
	KSFreq_BAND3_12D         = 34,	
	KSFreq_BAND3_13A         = 35,
	KSFreq_BAND3_13B         = 36,	
	KSFreq_BAND3_13C         = 37,
	KSFreq_BAND3_13D         = 38,
	KSFreq_BAND3_13E         = 39,		
	KSFreq_BAND3_13F         = 40,	
	
	//CHINA BAND
	KSFreq_CHINA_6A,
	KSFreq_CHINA_6B,
	KSFreq_CHINA_6C,
	KSFreq_CHINA_6D,
	KSFreq_CHINA_6N,
	KSFreq_CHINA_7A,
	KSFreq_CHINA_7B,
	KSFreq_CHINA_7C,
	KSFreq_CHINA_7D,	
	KSFreq_CHINA_8A,
	KSFreq_CHINA_8B,
	KSFreq_CHINA_8C,
	KSFreq_CHINA_8D,
	KSFreq_CHINA_8N,	
	KSFreq_CHINA_9A,
	KSFreq_CHINA_9B,
	KSFreq_CHINA_9C,
	KSFreq_CHINA_9D,	
	KSFreq_CHINA_10A,
	KSFreq_CHINA_10B,
	KSFreq_CHINA_10C,
	KSFreq_CHINA_10D,
	KSFreq_CHINA_10N,	
	KSFreq_CHINA_11A,
	KSFreq_CHINA_11B,
	KSFreq_CHINA_11C,
	KSFreq_CHINA_11D,	
	KSFreq_CHINA_12A,
	KSFreq_CHINA_12B,
	KSFreq_CHINA_12C,
	KSFreq_CHINA_12D,

	KSFreq_L_BAND_LA,
	KSFreq_L_BAND_LB,
	KSFreq_L_BAND_LC,
	KSFreq_L_BAND_LD,
	KSFreq_L_BAND_LE,
	KSFreq_L_BAND_LF,
	KSFreq_L_BAND_LG,
	KSFreq_L_BAND_LH,
	KSFreq_L_BAND_LI,
	KSFreq_L_BAND_LJ,
	KSFreq_L_BAND_LK,
	KSFreq_L_BAND_LL,
	KSFreq_L_BAND_LM,
	KSFreq_L_BAND_LN,
	KSFreq_L_BAND_LO,
	KSFreq_L_BAND_LP,
	KSFreq_L_BAND_LQ,
	KSFreq_L_BAND_LR,
	KSFreq_L_BAND_LS,
	KSFreq_L_BAND_LT,
	KSFreq_L_BAND_LU,
	KSFreq_L_BAND_LV,
	KSFreq_L_BAND_LW,
	
	KSFreq_UNKNOWN = 0xFF,
}KSFreq;

typedef enum {
	KSBBEEQMode_Off         = 0,
	KSBBEEQMode_BBE          = 1,
	KSBBEEQMode_EQ      = 2,	
}KSBBEEQMode;

typedef enum {
	KSBBEEQMachFreq_60Hz         = 0,
	KSBBEEQMachFreq_90Hz          = 1,
	KSBBEEQMachFreq_120Hz      = 2,	
	KSBBEEQMachFreq_150Hz       = 3,
}KSBBEEQMachFreq;

typedef enum {
	KSBBEEQMachGain_0dB         = 0,
	KSBBEEQMachGain_4dB          = 1,
	KSBBEEQMachGain_8dB      = 2,	
	KSBBEEQMachGain_12dB       = 3,
}KSBBEEQMachGain;

typedef enum {
	KSEQMode_BassBoost         = 0,
	KSEQMode_Jazz          = 1,
	KSEQMode_Live      = 2,	
	KSEQMode_Vocal       = 3,
	KSEQMode_Acoustic       = 4,
}KSEQMode;


typedef enum {
	KSServCompType_DAB         = 0,
	KSServCompType_DABPLUS     = 1,
	KSServCompType_PACKET_MODE = 2,
	KSServCompType_DATA_STREAM = 3,
	KSServCompType_UNKNOWN     = 0xFF,
}KSServCompType;

typedef enum {
	KSDRC_OFF         = 0,
	KSDRC_LOW          = 1,
	KSDRC_HIGH      = 2,	
	KSDRC_UNKNOWN       = 0xFF,
}KSDRC;

typedef enum {
	KSApplicationType_SLS        = 0,
	KSApplicationType_BWS        = 1,
	KSApplicationType_TPEG		 = 2,	
	KSApplicationType_DGPS       = 3,
	KSApplicationType_TMC        = 4,
	KSApplicationType_EPG        = 5,
	KSApplicationType_JAVA       = 6, //DAB Java
	KSApplicationType_DMB        = 7,
	KSApplicationType_PUSH       = 8,  //Push Radio
	KSApplicationType_UNKNOWN       = 0xFF,
}KSApplicationType;

typedef struct __KSDABProgrameInfo__ {
	uint16 eid;
	uint32 sid;
	uint8 scids;
	uint8 componentNum; //total programe number in this service
	uint8 componentIndex; //current programe index in this service
}KSDABProgrameInfo;

typedef struct __KSDateInfo__ {
	uint8 second;
	uint8 minute;
	uint8 hour;
	uint8 day; 
	uint8 week; 
	uint8 month; 
	uint16 year; 
}KSDateInfo;

typedef enum {
	RTN_OK         = 0,
	RTN_INVALID_HANLDE,
	RTN_SEND_WRCMD_FAIL,
	RTN_READ_ACKCMD_ERROR,
	RTN_READ_ACKCMD_NOT_ACK,
	RTN_READ_ACKCMD_NOT_NAK
}KSreturn_type;

#define INVALID_VALUE    0xFFFFFFFF
#define PRESET_NUM       10

//Open/Close session
BOOL KSDevice_OpenSession(HANDLE hCmdHandle, HANDLE hDatHandle);
BOOL KSDevice_CloseSession();

//SYSTEM_CMD
KSreturn_type KSDevice_GetSystemReady();
BOOL KSDevice_ResetSystem(KSReset mode);
BOOL KSDevice_GetMCUVersion(uint8 * major, uint16* minor, uint8* database);
BOOL KSDevice_GetBootVersion(uint8 * bootVersion);
BOOL KSDevice_GetASPVersion(uint16 * major, uint32* minor);

//STREAM CMD
BOOL KSDevice_StreamPlay(KSMode mode, uint32 index);
BOOL KSDevice_StreamStop();
BOOL KSDevice_StreamSearch(BOOL bDirection);
KSreturn_type KSDevice_StreamAutoSearch(KSFreq startIndex, KSFreq endFreq);
BOOL KSDevice_StreamStopSearch();
KSStatus KSDevice_GetPlayStatus();
KSMode KSDevice_GetPlayMode();
uint32 KSDevice_GetPlayIndex();
uint8 KSDevice_GetSignalStrength();
BOOL KSDevice_SetStereoMode(KSStereoMode mode);
KSStereoMode KSDevice_GetStereoMode();
KSStereo KSDevice_GetStereo();
BOOL KSDevice_SetVolume(uint8 level);
uint8 KSDevice_GetVolume();
KSProgType KSDevice_GetProgrameType(uint32 index);
BOOL KSDevice_GetProgramName(uint32 index, BOOL longForm, LPWSTR programName, uint16 strlen);
KSTextStatus KSDevice_GetProgramText(LPWSTR programText, uint16 strlen);
KSSampleRate KSDevice_GetSamplingRate();
uint16 KSDevice_GetDataRate();
uint8 KSDevice_GetSignalQuality();
KSFreq KSDevice_GetFrequency(uint32 index);
BOOL KSDevice_GetEnsembleName(uint32 index, BOOL longForm, LPWSTR ensembleName, uint16 strlen);
uint32 KSDevice_GetTotalProgram();
BOOL KSDevice_IsActive(uint32 index, BOOL * bRetActive);
BOOL KSDevice_SetRSSIThreshold(uint8 level);
uint8 KSDevice_GetRSSIThreshold();
BOOL KSDevice_GetServiceName(uint32 index, BOOL longForm, LPWSTR serviceName, uint16 strlen);
uint8 KSDevice_GetSearchProgram();

KSServCompType KSDevice_GetServCompType (uint32 index);

BOOL KSDevice_SetPreset(KSMode mode, uint8 presetIndex,  uint32 progIndex);
uint32 KSDevice_GetPreset(KSMode mode, uint8 presetIndex);
BOOL KSDevice_GetDABProgrameInfo(uint32 programeIndex, KSDABProgrameInfo * retInfo);
KSSorterType KSDevice_GetSorterType();
BOOL KSDevice_SetSorterType(KSSorterType type);
KSDRC KSDevice_GetDRC();
BOOL KSDevice_SetDRC(KSDRC drcType);



//RTC CMD
BOOL KSDevice_SetClock (KSDateInfo * dateInfo);
BOOL KSDevice_GetClock (KSDateInfo * dateInfo);
BOOL KSDevice_EnableSyncClock(BOOL bEnable);
BOOL KSDevice_GetSyncClockStatus();
BOOL KSDevice_GetClockStatus();

//MOT_CMD
KSApplicationType KSDevice_GetApplicationType(uint32 index);
uint16 KSDevice_GetMotData(uint8 * buffer, uint16 bufferLen);


//PACKET RAW DATA
uint16 KSDevice_GetPacketRawLength();
uint32 KSDevice_GetPacketRawData(uint8* buffer, uint32 bufferLen);

BOOL KSDevice_DirectPlayProgram(uint32 freq, uint16 vol, uint32 sid);
BOOL KSDevice_SingleCommand(uint8* cmdbuffer, uint8 u8len);
uint8 KSDevice_GetAckData(uint8* ackbuffer);