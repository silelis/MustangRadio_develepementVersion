#include <18F4520.h>
#device ADC=10


#fuses HS,NOWDT,NOPROTECT,NOLVP

#use delay (crystal=20MHz, clock=20MHz,fast_start)

#use rs232(baud=38400,parity=N,xmit=PIN_b7,rcv=PIN_b6,bits=8,stream=Dbg)
#use rs232(UART1, baud=57600,parity=N, bits=8, stream=Hrdw)


