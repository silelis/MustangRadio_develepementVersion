//#include <main.h>

#include <18F4520.h>
#device ADC=10
#fuses HS,NOWDT,NOPROTECT,NOLVP
#use delay (crystal=20MHz, clock=20MHz,fast_start)
#use rs232(baud=38400,parity=N,xmit=PIN_b7,rcv=PIN_b6,bits=8,stream=Dbg)

//#use rs232(baud=57600,parity=N, xmit=PIN_C6,rcv=PIN_C7, bits=8, stream=Hrdw)



void ClearBuffers (unsigned int *buffer, unsigned int16 buffer_size)
   {
      //unsigned int8 i;
      unsigned int16 i;
      for ( i = 0; i < buffer_size; i++ )
      {
         *(buffer+i)= 0x00;
      }
   }
// to do transmission_buffers
   //UART buffer size (MAX):
   // device:     VMusic3  DFPlayer    Bluetooth   au7860   au6850c        
   //- write  :   
   //- receive:      26
   const unsigned int16 UART_mcu_Transmission_BUFSIZE=16;
   const unsigned int16 UART_mcu_Reception_BUFSIZE=256;
   char   UART_MasterBuffer[UART_mcu_Transmission_BUFSIZE];
   char   UART_SlaveBuffer[UART_mcu_Reception_BUFSIZE];
   
   void UART_ClearMasterBuffer  (void)
   {
      ClearBuffers(&UART_MasterBuffer,UART_mcu_Transmission_BUFSIZE);
   }
   
   void UART_ClearSlaveBuffers  (void)
   {
      ClearBuffers(&UART_SlaveBuffer,UART_mcu_Transmission_BUFSIZE);
   }


// to do UART_engine
   #use rs232(UART1, baud=9600,parity=N, bits=8, stream=Hrdw)//, DISABLE_INTS)
   #define  KEYHIT_DELAY   100     // in milliseconds
   int1 UART_r_buffer_overflowed_STATEMENT;
   unsigned int16 received_data_counter;
   int1  UART_data_received_STATEMENT;
   unsigned int16 UART_kbhit_timeout;

void uart_receive_timeout(unsigned int16 *timeout_counter)
{
// Gdy "UART_data_received_STATEMENT=TRUE", tzn SLAVE przes�a� dane go mcu funkcja sprawdza czy przez pewiem okres nie pojawiaj� si� kolejne dane.
// Je�li nie to wyskakuje z p�tki i przechodzi do nast�pnego kroku.
// "timeout_counter" - resetowany jest podczas pobierania danych (w przerwaniu patrz UART_kbhit_timeout)
   while(*timeout_counter<KEYHIT_DELAY*10)
   {
      *timeout_counter=*timeout_counter+1;
      delay_us(100);   
   }
   disable_interrupts(global);
}

void uart_receive_buffer_data_parsed(void)
{
// po zako�czeniu przetwarzania danych nale�y zresetowa� wszystkie zmienne zwi�zane z przyjmowaniem danych. UART gotowy do przyjmowania nowych danych
   received_data_counter=0;
   UART_data_received_STATEMENT=FALSE;
   enable_interrupts(global);
}

void uart_read_slave_data(void)
{
   disable_interrupts(global);
   if(received_data_counter<UART_mcu_Reception_BUFSIZE)
   {
      //buffer[received_data_count]=fgetc(Hrdw);
      *(UART_SlaveBuffer+received_data_counter)=fgetc(Hrdw);
      received_data_counter=received_data_counter+1;
   }
   else
   {
      fgetc(Hrdw);
      UART_r_buffer_overflowed_STATEMENT=TRUE;
   }
   UART_kbhit_timeout=0;
   UART_data_received_STATEMENT=TRUE;
   enable_interrupts(global);
}

void uart_display_data_number_hex(char *buffer_to_display, unsigned int16 received_data_lenght)
{
// funkcja debugowa aby sprawdzi� czy slave nie wysy�a jakich� warto�ci nie ASCII
   unsigned int16 buffere_counter=0;
   while(buffere_counter<(received_data_lenght))
   {
      fprintf(Dbg, "[%lu]:%x ",buffere_counter,*(buffer_to_display+buffere_counter));
      buffere_counter++;
   }
}


void uart_display_data(char *buffer_to_display, unsigned int16 received_data_lenght)
{
   unsigned int16 buffere_counter=0;
   while(buffere_counter<(received_data_lenght))
   {
      fprintf(Dbg, "%c",*(buffer_to_display+buffere_counter));
      buffere_counter++;
   }
}
// vmusic driver

   // Prompts returned by all VNC1L firmware
#define Resp_Prompt_OK        0x01   // >  (Success)
#define Resp_Prompt_ND        0x02   // ND (Success)
#define Resp_Prompt_UE        0x03   // E echo
#define Resp_Prompt_LE        0x04   // e echo
#define Resp_Prompt_CF        0x05   // CF (Command Failed)
#define Resp_Prompt_BC        0x06   // BC (Bad Command)
#define Resp_Prompt_DF        0x07   // DF (Disk Full)
#define Resp_Prompt_FI        0x08   // FI (File Invalid)
#define Resp_Prompt_RO        0x09   // RO (Read Only)
#define Resp_Prompt_FO        0x0A   // FO (File Open)
#define Resp_Prompt_NE        0x0B   // NE (Dir Not Empty)
#define Resp_Prompt_FN        0x0C   // FN (Filename Invalid)
#define Resp_Prompt_End       0x0D
   // Asynchronous messages returned by VMSC1 firmware
#define Resp_Message_P        0x0E   // P / Playing
#define Resp_Message_S        0x0F   // S / Stopped
#define Resp_Message_T        0x10   // T / Time
   // Asynchronous messages returned by all VNC1L firmware
#define Resp_Message_NU       0x11   // NU / No Upgrade
#define Resp_Message_DD1      0x12   // DD1 / Device Detected USB Port 1)
#define Resp_Message_DD2      0x13   // DD2 / Device Detected USB Port 2)
#define Resp_Message_DR1      0x14   // DR1 / Device Removed USB Port 1)
#define Resp_Message_DR2      0x15   // DR2 / Device Removed USB Port 2)
#define Resp_Message_Splash   0x16 // Ver ...
#define Resp_None 0xff        //�mieci, nie ma takiej komendy

char pResponse[] = {
   #define  repond_pos -2                    //minus
   #define  respond_lenght_pos         -1  //minus
   #define  pResponse_table_lenght     103 //103 //6*4+  10*5+  5*6
   // SCS Prompts                
    Resp_Prompt_OK, 2, '>',0x0d,
    Resp_Prompt_UE, 2, 'E',0x0d,
    Resp_Prompt_LE, 2, 'e',0x0d,
    Resp_Message_P, 2, 'P',' ',
    Resp_Message_S, 2, 'S',0x0d,
    Resp_Message_T, 2, 'T',' ',     //6*4+

    Resp_Prompt_ND, 3, 'N','D',0x0d,
    Resp_Prompt_CF, 3, 'C','F',0x0d,
    Resp_Prompt_BC, 3, 'B','C',0x0d,
    Resp_Prompt_DF, 3, 'D','F',0x0d,
    Resp_Prompt_FI, 3, 'F','I',0x0d,
    Resp_Prompt_RO, 3, 'R','O',0x0d,
    Resp_Prompt_FO, 3, 'F','O',0x0d,
    Resp_Prompt_NE, 3, 'N','E',0x0d,
    Resp_Prompt_FN, 3, 'F','N',0x0d,
    Resp_Message_NU, 3, 'N','U',0x0d,  //10*5+

    Resp_Message_DD1, 4, 'D','D','1',0x0d,
    Resp_Message_DD2, 4, 'D','D','2',0x0d,
    Resp_Message_DR1, 4, 'D','R','1',0x0d,
    Resp_Message_DR2, 4, 'D','R','2',0x0d,
    Resp_Message_Splash, 4, 'V','e','r',' ' //5*6
};

#include <string.h>

void __Vmusic_1st_message(char *buffer_to_check, unsigned int16 received_data_lenght)
{
// podczas pierwszego uruchomienia Vmusic daje komend� '0x0d'
   if (*(buffer_to_check)==0x0d)
   {
      memcpy (buffer_to_check, buffer_to_check+1, received_data_lenght);
   }
}

int8 Vmusic_response(char *buffer_to_check, unsigned int16 received_data_lenght)
{
   //signed  int8 compare;   //memcmp answer 0 DATA EQUAL
   int8 respond_value=Resp_None;      //VMUSIC Resp_Prompt
   __Vmusic_1st_message(buffer_to_check, received_data_lenght);
   for (unsigned int16 data_position=0; (data_position+*(pResponse+respond_lenght_pos))<=pResponse_table_lenght+1; data_position++)
   //data_position licznik pozycji typ danej musi by� ten sam co buffora danych jaki si� sprawdza
   {
      if (!memcmp(pResponse+data_position,buffer_to_check,1))
      {
        if (!memcmp(pResponse+data_position,buffer_to_check,*(pResponse+data_position+respond_lenght_pos)))
         {
            respond_value=*(pResponse+data_position+repond_pos);
            break;
         }
      }
   }
  return respond_value;
}

#int_rda
void serial_isr()
{
   uart_read_slave_data();
}

#ZERO_RAM
void main()
{

  fprintf(Hrdw,"UART_TEST ");
  fprintf(Dbg,"UART_TEST");
   enable_interrupts(int_rda);
   enable_interrupts(global);
   received_data_counter=0;
   UART_data_received_STATEMENT=FALSE;
   UART_r_buffer_overflowed_STATEMENT=FALSE;
   

   while(TRUE)
   {
   
   
   if (UART_data_received_STATEMENT==TRUE)
   {

   uart_receive_timeout(&UART_kbhit_timeout);
   if (UART_r_buffer_overflowed_STATEMENT==TRUE)
   {
      //delay_ms(100);
      fprintf(Dbg, "UART overflowed.\r\n");
   }
   else
   {
   
   
      uart_display_data(UART_SlaveBuffer, received_data_counter);
      
      
      int8 resp = Vmusic_response(UART_SlaveBuffer, received_data_counter);
      
      if(resp==Resp_Message_Splash)
      {
      fprintf(Dbg, "!!!!DZIA�A!!!!.\r\n");
      
      }
   }


   uart_receive_buffer_data_parsed();
  /* received_data_count=0;
   UART_data_received=FALSE;
   UART_overflowed=FALSE;
   //enable_interrupts(int_rda);
   enable_interrupts(global);*/
   
    
   }
   

   }

}
