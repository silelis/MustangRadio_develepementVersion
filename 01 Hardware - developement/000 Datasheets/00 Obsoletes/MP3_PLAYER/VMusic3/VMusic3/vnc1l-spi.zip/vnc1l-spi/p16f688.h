// Definitions from P16F688.INC
// Converted using inc2h v1.0, by John Nagle (http://www.jobie.com)

//=============================================
// PART = PIC 16F688


#define	W	0x0000
#define	F	0x0001

//=============================================
// Registers

char indf@0x0000;
char tmr0@0x0001;
char pcl@0x0002;
char status@0x0003;
char fsr@0x0004;
char porta@0x0005;
char portc@0x0007;
char pclath@0x000A;
char intcon@0x000B;
char pir1@0x000C;
char tmr1l@0x000E;
char tmr1h@0x000F;
char baudctl@0x0011;
char spbrgh@0x0012;
char spbrg@0x0013;
char rcreg@0x0014;
char txreg@0x0015;
char txsta@0x0016;
char rcsta@0x0017;
char wdtcon@0x0018;
char cmcon0@0x0019;
char cmcon1@0x001A;
char adresh@0x001E;
char adcon0@0x001F;
char option_reg	@0x0081;
char trisa@0x0085;
char trisc@0x0087;
char pie1@0x008C;
char pcon@0x008E;
char osccon@0x008F;
char ansel@0x0091;
char ioc@0x0096;
char ioca@0x0096;
char eedath@0x0097;
char eeadrh@0x0098;
char vrcon@0x0099;
char eedat@0x009A;
char eeadr@0x009B;
char eecon1@0x009C;
char eecon2@0x009D;
char adresl@0x009E;
char adcon1@0x009F;

//=============================================
// STATUS Bits

#define	IRP	0x0007
#define	RP1	0x0006
#define	RP0	0x0005
#define	NOT_TO	0x0004
#define	NOT_PD	0x0003
#define	Z	0x0002
#define	DC	0x0001
#define	C	0x0000

//=============================================
// INTCON Bits

#define	GIE	0x0007
#define	PEIE	0x0006
#define	T0IE	0x0005
#define	INTE	0x0004
#define	RAIE	0x0003
#define	T0IF	0x0002
#define	INTF	0x0001
#define	RAIF	0x0000

//=============================================
// PIR1 Bits

#define	EEIF	0x0007
#define	ADIF	0x0006
#define	RCIF	0x0005
#define	C2IF	0x0004
#define	C1IF	0x0003
#define	OSFIF	0x0002
#define	TXIF	0x0001
#define	T1IF	0x0000
#define	TMR1IF	0x0000

//=============================================
// T1CON Bits

#define	T1GINV	0x0007
#define	TMR1GE	0x0006
#define	T1CKPS1	0x0005
#define	T1CKPS0	0x0004
#define	T1OSCEN	0x0003
#define	NOT_T1SYNC	0x0002
#define	TMR1CS	0x0001
#define	TMR1ON	0x0000

//=============================================
// BAUDCTL Bits

#define	ABDOVF	0x0007
#define	RCIDL	0x0006
#define	SCKP	0x0004
#define	BRG16	0x0003
#define	WUE	0x0001
#define	ABDEN	0x0000

//=============================================
// TXSTA Bits

#define	CSRC	0x0007
#define	TX9	0x0006
#define	TXEN	0x0005
#define	SYNC	0x0004
#define	SENDB	0x0003
#define	BRGH	0x0002
#define	TRMT	0x0001
#define	TX9D	0x0000

//=============================================
// RCSTA Bits

#define	SPEN	0x0007
#define	RX9	0x0006
#define	SREN	0x0005
#define	CREN	0x0004
#define	ADDEN	0x0003
#define	FERR	0x0002
#define	OERR	0x0001
#define	RX9D	0x0000

//=============================================
// WDTCON Bits

#define	WDTPS3	0x0004
#define	WDTPS2	0x0003
#define	WDTPS1	0x0002
#define	WDTPS0	0x0001
#define	SWDTEN	0x0000

//=============================================
// COMCON0 Bits

#define	C2OUT	0x0007
#define	C1OUT	0x0006
#define	C2INV	0x0005
#define	C1INV	0x0004
#define	CIS	0x0003
#define	CM2	0x0002
#define	CM1	0x0001
#define	CM0	0x0000

//=============================================
// COMCON1 Bits

#define	T1GSS	0x0001
#define	C2SYNC	0x0000

//=============================================
// ADCON0 Bits

#define	ADFM	0x0007
#define	VCFG	0x0006
#define	CHS2	0x0004
#define	CHS1	0x0003
#define	CHS0	0x0002
#define	GO	0x0001
#define	NOT_DONE	0x0001
#define	GO_DONE	0x0001
#define	ADON	0x0000

//=============================================
// OPTION Bits

#define	INTEDG	0x0006
#define	T0CS	0x0005
#define	T0SE	0x0004
#define	PSA	0x0003
#define	PS2	0x0002
#define	PS1	0x0001
#define	PS0	0x0000

//=============================================
// PIE1 Bits

#define	EEIE	0x0007
#define	ADIE	0x0006
#define	RCIE	0x0005
#define	C2IE	0x0004
#define	C1IE	0x0003
#define	OSFIE	0x0002
#define	TXIE	0x0001
#define	T1IE	0x0000
#define	TMR1IE	0x0000

//=============================================
// PCON Bits

#define	ULPWUE	0x0005
#define	SBODEN	0x0004
#define	NOT_POR	0x0001
#define	NOT_BOD	0x0000

//=============================================
// OSCCON Bits

#define	IRCF2	0x0006
#define	IRCF1	0x0005
#define	IRCF0	0x0004
#define	OSTS	0x0003
#define	HTS	0x0002
#define	LTS	0x0001
#define	SCS	0x0000

//=============================================
// OSCTUNE Bits

#define	TUN4	0x0004
#define	TUN3	0x0003
#define	TUN2	0x0002
#define	TUN1	0x0001
#define	TUN0	0x0000
#define	ANS7	0x0007
#define	ANS6	0x0006
#define	ANS5	0x0005
#define	ANS4	0x0004
#define	ANS3	0x0003
#define	ANS2	0x0002
#define	ANS1	0x0001
#define	ANS0	0x0000
#define	IOC5	0x0005
#define	IOC4	0x0004
#define	IOC3	0x0003
#define	IOC2	0x0002
#define	IOC1	0x0001
#define	IOC0	0x0000
#define	IOCA5	0x0005
#define	IOCA4	0x0004
#define	IOCA3	0x0003
#define	IOCA2	0x0002
#define	IOCA1	0x0001
#define	IOCA0	0x0000

//=============================================
// VRCON Bits

#define	VREN	0x0007
#define	VRR	0x0005
#define	VR3	0x0003
#define	VR2	0x0002
#define	VR1	0x0001
#define	VR0	0x0000
#define	EEPGD	0x0007
#define	WRERR	0x0003
#define	WREN	0x0002
#define	WR	0x0001
#define	RD	0x0000
#define	ADCS2	0x0006
#define	ADCS1	0x0005
#define	ADCS0	0x0004

//=============================================
// Configuration Bits

#define	_FCMEN_ON	0x3FFF
#define	_FCMEN_OFF	0x37FF
#define	_IESO_ON	0x3FFF
#define	_IESO_OFF	0x3BFF
#define	_BOD_ON	0x3FFF
#define	_BOD_NSLEEP	0x3EFF
#define	_BOD_SBODEN	0x3DFF
#define	_BOD_OFF	0x3CFF
#define	_CPD_ON	0x3F7F
#define	_CPD_OFF	0x3FFF
#define	_CP_ON	0x3FBF
#define	_CP_OFF	0x3FFF
#define	_MCLRE_ON	0x3FFF
#define	_MCLRE_OFF	0x3FDF
#define	_PWRTE_OFF	0x3FFF
#define	_PWRTE_ON	0x3FEF
#define	_WDT_ON	0x3FFF
#define	_WDT_OFF	0x3FF7
#define	_LP_OSC	0x3FF8
#define	_XT_OSC	0x3FF9
#define	_HS_OSC	0x3FFA
#define	_EC_OSC	0x3FFB
#define	_INTRC_OSC_NOCLK	0x3FFC
#define	_INTRC_OSC_CLKOU	0x3FFD
#define	_EXTRC_OSC_NOCLK	0x3FFE
#define	_EXTRC_OSC_CLKOU	0x3FFF
