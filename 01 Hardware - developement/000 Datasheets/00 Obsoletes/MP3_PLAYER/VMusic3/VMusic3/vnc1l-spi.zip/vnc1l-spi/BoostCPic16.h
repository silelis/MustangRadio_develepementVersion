// ***************************************
// BoostC Common Header file
// Author(s): David Hobday
//
// Copyright (C) 2003-2006 Pavel Baranov
// Copyright (C) 2003-2006 David Hobday
// All Rights Reserved
// ***************************************
#ifdef _PIC12F609
        #include <PIC12F609.h>
#endif // _PIC12F609

#ifdef _PIC12HV609
        #include <PIC12HV609.h>
#endif // _PIC12HV609

#ifdef _PIC12F615
        #include <PIC12F615.h>
#endif // _PIC12F615

#ifdef _PIC12HV615
        #include <PIC12HV615.h>
#endif // _PIC12HV615

#ifdef _PIC16HV785
        #include <PIC16HV785.h>
#endif // _PIC16HV785

#ifdef _PIC16F887
        #include <PIC16F887.h>
#endif // _PIC16F887

#ifdef _PIC16F886
        #include <PIC16F886.h>
#endif // _PIC16F886

#ifdef _PIC16F884
        #include <PIC16F884.h>
#endif // _PIC16F884

#ifdef _PIC16F883
        #include <PIC16F883.h>
#endif // _PIC16F883

#ifdef _PIC16F677
        #include <PIC16F677.h>
#endif // _PIC16F677

#ifdef _PIC16F631
        #include <PIC16F631.h>
#endif // _PIC16F631

#ifdef _PIC16HV616
        #include <PIC16HV616.h>
#endif // _PIC16HV616

#ifdef _PIC16F616
        #include <PIC16F616.h>
#endif // _PIC16F616

#ifdef _PIC12F635
        #include <PIC12F635.h>
#endif // _PIC12F635

#ifdef _PIC16F636
        #include <PIC16F636.h>
#endif // _PIC16F636

#ifdef _PIC16F639
        #include <PIC16F639.h>
#endif // _PIC16F639

#ifdef _PIC16F685
        #include <PIC16F685.h>
#endif // _PIC16F685

#ifdef _PIC16F687
        #include <PIC16F687.h>
#endif // _PIC16F687

#ifdef _PIC16F689
        #include <PIC16F689.h>
#endif // _PIC16F689

#ifdef _PIC16F690
        #include <PIC16F690.h>
#endif // _PIC16F690

#ifdef _PIC16F946
        #include <PIC16F946.h>
#endif // _PIC16F946

#ifdef _rfPIC12F675f
        #include <rfPIC12F675f.h>
#endif // _rfPIC12F675f

#ifdef _rfPIC12F675h
        #include <rfPIC12F675h.h>
#endif // _rfPIC12F675h

#ifdef _rfPIC12F675k
        #include <rfPIC12F675k.h>
#endif // _rfPIC12F675k

#ifdef _PIC16F785
        #include <PIC16F785.h>
#endif // _PIC16F785

#ifdef _PIC16F913
        #include <PIC16F913.h>
#endif // _PIC16F913

#ifdef _PIC16F914
        #include <PIC16F914.h>
#endif // _PIC16F914

#ifdef _PIC16F916
        #include <PIC16F916.h>
#endif // _PIC16F916

#ifdef _PIC16F917
        #include <PIC16F917.h>
#endif // _PIC16F917

#ifdef _PIC16C433
        #include <PIC16C433.h>
#endif // _PIC16C433

#ifdef _PIC12F683
        #include <PIC12F683.h>
#endif // _PIC12F683

#ifdef _PIC12CE674
        #include <PIC12CE674.h>
#endif // _PIC12CE674

#ifdef _PIC12CE673
        #include <PIC12CE673.h>
#endif // _PIC12CE673

#ifdef _PIC12C672
        #include <PIC12C672.h>
#endif // _PIC12C672

#ifdef _PIC12C671
        #include <PIC12C671.h>
#endif // _PIC12C671

#ifdef _PIC12F675
        #include <PIC12F675.h>
#endif // _PIC12F675

#ifdef _PIC12F629
        #include <PIC12F629.h>
#endif // _PIC12F629

#ifdef _PIC16C432
        #include <PIC16C432.h>
#endif // _PIC16C432

#ifdef _PIC16C554
        #include <PIC16C554.h>
#endif // _PIC16C554

#ifdef _PIC16C558
        #include <PIC16C558.h>
#endif // _PIC16C558

#ifdef _PIC16C61
        #include <PIC16C61.h>
#endif // _PIC16C61

#ifdef _PIC16C62
        #include <PIC16C62.h>
#endif // _PIC16C62

#ifdef _PIC16C620
        #include <PIC16C620.h>
#endif // _PIC16C620

#ifdef _PIC16C620A
        #include <PIC16C620A.h>
#endif // _PIC16C620A

#ifdef _PIC16C621
        #include <PIC16C621.h>
#endif // _PIC16C621

#ifdef _PIC16C621A
        #include <PIC16C621A.h>
#endif // _PIC16C621A

#ifdef _PIC16C622
        #include <PIC16C622.h>
#endif // _PIC16C622

#ifdef _PIC16C622A
        #include <PIC16C622A.h>
#endif // _PIC16C622A

#ifdef _PIC16C62A
        #include <PIC16C62A.h>
#endif // _PIC16C62A

#ifdef _PIC16C62B
        #include <PIC16C62B.h>
#endif // _PIC16C62B

#ifdef _PIC16C63
        #include <PIC16C63.h>
#endif // _PIC16C63

#ifdef _PIC16C63A
        #include <PIC16C63A.h>
#endif // _PIC16C63A

#ifdef _PIC16C64
        #include <PIC16C64.h>
#endif // _PIC16C64

#ifdef _PIC16C642
        #include <PIC16C642.h>
#endif // _PIC16C642

#ifdef _PIC16C64A
        #include <PIC16C64A.h>
#endif // _PIC16C64A

#ifdef _PIC16C65
        #include <PIC16C65.h>
#endif // _PIC16C65

#ifdef _PIC16C65A
        #include <PIC16C65A.h>
#endif // _PIC16C65A

#ifdef _PIC16C65B
        #include <PIC16C65B.h>
#endif // _PIC16C65B

#ifdef _PIC16C66
        #include <PIC16C66.h>
#endif // _PIC16C66

#ifdef _PIC16C662
        #include <PIC16C662.h>
#endif // _PIC16C662

#ifdef _PIC16C67
        #include <PIC16C67.h>
#endif // _PIC16C67

#ifdef _PIC16C71
        #include <PIC16C71.h>
#endif // _PIC16C71

#ifdef _PIC16C710
        #include <PIC16C710.h>
#endif // _PIC16C710

#ifdef _PIC16C711
        #include <PIC16C711.h>
#endif // _PIC16C711

#ifdef _PIC16C712
        #include <PIC16C712.h>
#endif // _PIC16C712

#ifdef _PIC16C715
        #include <PIC16C715.h>
#endif // _PIC16C715

#ifdef _PIC16C716
        #include <PIC16C716.h>
#endif // _PIC16C716

#ifdef _PIC16C717
        #include <PIC16C717.h>
#endif // _PIC16C717

#ifdef _PIC16C72
        #include <PIC16C72.h>
#endif // _PIC16C72

#ifdef _PIC16C72A
        #include <PIC16C72A.h>
#endif // _PIC16C72A

#ifdef _PIC16C73
        #include <PIC16C73.h>
#endif // _PIC16C73

#ifdef _PIC16C73A
        #include <PIC16C73A.h>
#endif // _PIC16C73A

#ifdef _PIC16C73B
        #include <PIC16C73B.h>
#endif // _PIC16C73B

#ifdef _PIC16C74
        #include <PIC16C74.h>
#endif // _PIC16C74

#ifdef _PIC16C745
        #include <PIC16C745.h>
#endif // _PIC16C745

#ifdef _PIC16C74A
        #include <PIC16C74A.h>
#endif // _PIC16C74A

#ifdef _PIC16C74B
        #include <PIC16C74B.h>
#endif // _PIC16C74B

#ifdef _PIC16C76
        #include <PIC16C76.h>
#endif // _PIC16C76

#ifdef _PIC16C765
        #include <PIC16C765.h>
#endif // _PIC16C765

#ifdef _PIC16C77
        #include <PIC16C77.h>
#endif // _PIC16C77

#ifdef _PIC16C770
        #include <PIC16C770.h>
#endif // _PIC16C770

#ifdef _PIC16C771
        #include <PIC16C771.h>
#endif // _PIC16C771

#ifdef _PIC16C773
        #include <PIC16C773.h>
#endif // _PIC16C773

#ifdef _PIC16C774
        #include <PIC16C774.h>
#endif // _PIC16C774

#ifdef _PIC16C781
        #include <PIC16C781.h>
#endif // _PIC16C781

#ifdef _PIC16C782
        #include <PIC16C782.h>
#endif // _PIC16C782

#ifdef _PIC16C84
        #include <PIC16C84.h>
#endif // _PIC16C84

#ifdef _PIC16C923
        #include <PIC16C923.h>
#endif // _PIC16C923

#ifdef _PIC16C924
        #include <PIC16C924.h>
#endif // _PIC16C924

#ifdef _PIC16C925
        #include <PIC16C925.h>
#endif // _PIC16C925

#ifdef _PIC16C926
        #include <PIC16C926.h>
#endif // _PIC16C926

#ifdef _PIC16CE623
        #include <PIC16CE623.h>
#endif // _PIC16CE623

#ifdef _PIC16CE624
        #include <PIC16CE624.h>
#endif // _PIC16CE624

#ifdef _PIC16CE625
        #include <PIC16CE625.h>
#endif // _PIC16CE625

#ifdef _PIC16CR62
        #include <PIC16CR62.h>
#endif // _PIC16CR62

#ifdef _PIC16CR620A
        #include <PIC16CR620A.h>
#endif // _PIC16CR620A

#ifdef _PIC16CR63
        #include <PIC16CR63.h>
#endif // _PIC16CR63

#ifdef _PIC16CR64
        #include <PIC16CR64.h>
#endif // _PIC16CR64

#ifdef _PIC16CR65
        #include <PIC16CR65.h>
#endif // _PIC16CR65

#ifdef _PIC16CR72
        #include <PIC16CR72.h>
#endif // _PIC16CR72

#ifdef _PIC16CR83
        #include <PIC16CR83.h>
#endif // _PIC16CR83

#ifdef _PIC16CR84
        #include <PIC16CR84.h>
#endif // _PIC16CR84

#ifdef _PIC16F627
        #include <PIC16F627.h>
#endif // _PIC16F627

#ifdef _PIC16F627A
        #include <PIC16F627A.h>
#endif // _PIC16F627A

#ifdef _PIC16F628
        #include <PIC16F628.h>
#endif // _PIC16F628

#ifdef _PIC16F628A
        #include <PIC16F628A.h>
#endif // _PIC16F628A

#ifdef _PIC16F630
        #include <PIC16F630.h>
#endif // _PIC16F630

#ifdef _PIC16F676
        #include <PIC16F676.h>
#endif // _PIC16F676

#ifdef _PIC16F72
        #include <PIC16F72.h>
#endif // _PIC16F72

#ifdef _PIC16F73
        #include <PIC16F73.h>
#endif // _PIC16F73

#ifdef _PIC16F74
        #include <PIC16F74.h>
#endif // _PIC16F74

#ifdef _PIC16F76
        #include <PIC16F76.h>
#endif // _PIC16F76

#ifdef _PIC16F77
        #include <PIC16F77.h>
#endif // _PIC16F77

#ifdef _PIC16F818
        #include <PIC16F818.h>
#endif // _PIC16F818

#ifdef _PIC16F819
        #include <PIC16F819.h>
#endif // _PIC16F819

#ifdef _PIC16F83
        #include <PIC16F83.h>
#endif // _PIC16F83

#ifdef _PIC16F84
        #include <PIC16F84.h>
#endif // _PIC16F84

#ifdef _PIC16F84A
        #include <PIC16F84A.h>
#endif // _PIC16F84A

#ifdef _PIC16F87
        #include <PIC16F87.h>
#endif // _PIC16F87

#ifdef _PIC16F870
        #include <PIC16F870.h>
#endif // _PIC16F870

#ifdef _PIC16F871
        #include <PIC16F871.h>
#endif // _PIC16F871

#ifdef _PIC16F872
        #include <PIC16F872.h>
#endif // _PIC16F872

#ifdef _PIC16F873
        #include <PIC16F873.h>
#endif // _PIC16F873

#ifdef _PIC16F873A
        #include <PIC16F873A.h>
#endif // _PIC16F873A

#ifdef _PIC16F874
        #include <PIC16F874.h>
#endif // _PIC16F874

#ifdef _PIC16F874A
        #include <PIC16F874A.h>
#endif // _PIC16F874A

#ifdef _PIC16F876
        #include <PIC16F876.h>
#endif // _PIC16F876

#ifdef _PIC16F876A
        #include <PIC16F876A.h>
#endif // _PIC16F876A

#ifdef _PIC16F877
        #include <PIC16F877.h>
#endif // _PIC16F877

#ifdef _PIC16F877A
        #include <PIC16F877A.h>
#endif // _PIC16F877A

#ifdef _PIC16F88
        #include <PIC16F88.h>
#endif // _PIC16F88

#ifdef _PIC16C557
        #include <PIC16C557.h>
#endif // _PIC16C557

#ifdef _PIC16F648A
        #include <PIC16F648A.h>
#endif // _PIC16F648A

#ifdef _PIC16F684
        #include <PIC16F684.h>
#endif // _PIC16F684

#ifdef _PIC16F688
        #include <PIC16F688.h>
#endif // _PIC16F688

#ifdef _PIC16F716
        #include <PIC16F716.h>
#endif // _PIC16F716

#ifdef _PIC16F737
        #include <PIC16F737.h>
#endif // _PIC16F737

#ifdef _PIC16F747
        #include <PIC16F747.h>
#endif // _PIC16F747

#ifdef _PIC16F767
        #include <PIC16F767.h>
#endif // _PIC16F767

#ifdef _PIC16F777
        #include <PIC16F777.h>
#endif // _PIC16F777

