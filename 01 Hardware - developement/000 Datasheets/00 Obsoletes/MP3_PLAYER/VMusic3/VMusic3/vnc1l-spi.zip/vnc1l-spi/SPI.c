//*****************************************************************************************
//
//	Code for bit-banging SPI on the PIC16F688 for communicating with the VNC1L.
//  Commands received/transmitted to/from UART from/to SPI.
//  The PIC only handles Tx and Rx automatically for the UART, so handshaking must 
//	be implemented in code.
//	
//	Author: FTDI
//	
//*****************************************************************************************


//*****************************************************************************************
//	
//	Pin definitions for PIC16F688 on VPIC board
//	
//	PIC16F688 Pin Number		Designation			Function
//	1							VDD					Power
//	2							RA5					OSC_IN
//	3							RA4					OSC_OUT
//	4							MCLR#				MCLR#
//	5							RC5					Rx (UART)
//	6							RC4					Tx (UART)
//	7							RC3					CTS# (connects to RTS# on TTL cable)
//	8							RC2					RTS# (connects to CTS# on TTL cable)
//	9							RC1					CS (SPI digital output)
//	10							RC0					SCLK (SPI digital clock output)
//	11							RA2					SDO (SPI digital output - SDI on VNC1L)
//	12							RA1					SDI (SPI digital input - SDO on VNC1L)
//	13							RA0					Analogue/Digital Input
//	14							GND					Ground
//	
//*****************************************************************************************



#include <BoostCPic16.h>
#include <boostc.h>

#pragma DATA 0x2007, _HS_OSC & _WDT_OFF & _PWRTE_OFF & _MCLRE_OFF & _CP_OFF & _IESO_OFF & _FCMEN_OFF;
#pragma	CLOCK_FREQ 20000000;



//*****************************************************************************************
//  
//  Constants and variables for serial port
//  
//*****************************************************************************************
// Define serial port flags
char _RTS = 0x04;											// RTS# is RC2 (Port C bit 2)
char _CTS = 0x08;											// CTS# is RC3 (Port C bit 3)
char FLOW_NONE = 0x00;	
char FLOW_RTS_CTS = 0x01;
char FLOW_CONTROL_ENABLED = 0x00;							// Initialise FLOW_CONTROL_ENABLED to off

// Define serial port Rx buffer variables
char SERIAL_RX_FIFO[0x20];									// Allocate buffer for RX FIFO USE MULTIPLE OF 0x04!
char RX_FIFO_SIZE = sizeof(SERIAL_RX_FIFO);					// Initialise FIFO size variable
char RX_FIFO_COUNT = 0x00;									// Reset RX FIFO count
char * RX_FIFO_HEAD_PTR = &SERIAL_RX_FIFO[0x00];			// Initialise head pointer 
char * RX_FIFO_TAIL_PTR = &SERIAL_RX_FIFO[0x00];			// Initialise tail pointer
char * RX_FIFO_START = RX_FIFO_TAIL_PTR;					// Set lowest address of RX_FIFO
char * RX_FIFO_END = RX_FIFO_START + RX_FIFO_SIZE;			// Set highest address of RX_FIFO
char RX_STATUS = 0x00;										// Reset RX status
char RX_FIFO_OVERRUN = 0x01;

char RX_FIFO_UPPER_LIMIT = 0x03 *(RX_FIFO_SIZE / 0x04);		// Buffer limit for handshaking
char RX_FIFO_LOWER_LIMIT = (RX_FIFO_SIZE / 0x04);			// Buffer limit for handshaking


// Define serial port Tx buffer variables
char SERIAL_TX_FIFO[0x20];									// Allocate buffer for TX FIFO
char TX_FIFO_SIZE = sizeof(SERIAL_TX_FIFO);					// Initialise FIFO size variable
char TX_FIFO_COUNT = 0x00;									// Reset TX FIFO count
char * TX_FIFO_HEAD_PTR = &SERIAL_TX_FIFO[0x00];			// Initialise head pointer 
char * TX_FIFO_TAIL_PTR = &SERIAL_TX_FIFO[0x00];			// Initialise tail pointer
char * TX_FIFO_START = TX_FIFO_TAIL_PTR;					// Set lowest address of TX_FIFO
char * TX_FIFO_END = TX_FIFO_START + TX_FIFO_SIZE;			// Set highest address of TX_FIFO
char TX_STATUS = 0x00;										// Reset TX status
char TX_FIFO_OVERRUN = 0x01;

//*****************************************************************************************
//  
//  Constants and variables for SPI
//  
//*****************************************************************************************
char SDI = 0x02;											// SDI is RA1 (Port A bit 1)
char SDO = 0x04;											// SDO is RA2 (Port A bit 2)
char SCLK = 0x01;											// SCLK is RC0 (Port C bit 0)
char CS = 0x02;												// CS is RC1 (Port C bit 1)

enum {														// Enum states
	SPI_Idle,												// Idle state
	SPI_R1,													// Read 1
	SPI_R2,
	SPI_R3,
	SPI_W1,													// Write 1
	SPI_W2,
	SPI_W3,
	SPI_D1,													// Data 1
	SPI_D2,
	SPI_D3,
	SPI_D4,
	SPI_D5,
	SPI_D6,
	SPI_D7,
	SPI_C1,													// Check 1
	SPI_C2,
	SPI_C3	
};

char SPI_State = SPI_Idle;									// SPI state variable, initialised to idle

char LastWasRead = 0x00;									// Keeps bus fair - arbitrates between read and write operations
char SPI_Read_Byte = 0x00;
char SPI_Write_Byte = 0x00;
char SPI_Last_Write_Byte = 0x00;							// Keep a note of the byte trying to write in case write fails
char SPI_Status = 0x00;										// SPI status variable
char SPI_Write_Failed = 0x00;								// Status of write


#define WRStart  ((RX_FIFO_COUNT != 0x00) && (LastWasRead == 0x01))	// RX_FIFO_Count incremented via interrupts




///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
//  
//  Routines for serial port
//  
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////


//*****************************************************************************************
//  
//  Reset Rx FIFO
//  
//*****************************************************************************************
void serial_resetrxfifo()
{
	RX_FIFO_COUNT = 0x00;									// Reset FIFO count to 0
	RX_STATUS = 0x00;										// Reset FIFO status
	RX_FIFO_HEAD_PTR = (&SERIAL_RX_FIFO[0x00]);				// Set FIFO head pointer to address of first byte of SERIAL_RX_FIFO
	RX_FIFO_TAIL_PTR = (&SERIAL_RX_FIFO[0x00]);				// Set FIFO tail pointer to address of first byte of SERIAL_RX_FIFO
}



//*****************************************************************************************
//  
//  Reset Tx FIFO
//  
//*****************************************************************************************
void serial_resettxfifo()
{
	TX_FIFO_COUNT = 0x00;									// Reset FIFO count to 0
	TX_STATUS = 0x00;										// Reset FIFO status
	TX_FIFO_HEAD_PTR = (&SERIAL_TX_FIFO[0x00]);				// Set FIFO head pointer to address of first byte of SERIAL_TX_FIFO
	TX_FIFO_TAIL_PTR = (&SERIAL_TX_FIFO[0x00]);				// Set FIFO tail pointer to address of first byte of SERIAL_TX_FIFO
}



//*****************************************************************************************
//  
//  Initialise serial port (Baud rate, handshaking, interrupt enable, enable receiver)
//  
//*****************************************************************************************
void serial_init(long BaudRate, char Handshaking)			// Set up serial port
{
	pie1.RCIE = 0x00;										// Disable interrupts
	intcon.GIE = 0x00;
	intcon.PEIE = 0x00;

	baudctl = 0x00;	
	ansel &= 0x3F;											// Digital IO on RC2, RC3
	trisc = 0xDB;											// Set RC4 (Tx) & RC2 (RTS#) as output,RC5 (Rx) & RC3 (CTS#) as input
															// TRISC bits 1 for input, 0 for output
	portc |= _RTS;											// Set RTS# high (inactive) at this stage
	txsta = 0x04;											// Enable UART module and set 8,n,1 - Set BRGH to 1
	rcsta.SPEN = 0x01;										// Enable serial port

	switch (BaudRate)										// Set Baud rate
	{
		case 9600:
			spbrg = 0x81;
			break;
		case 19200:
			spbrg = 0x40;
			break;
		case 57600:
			spbrg = 0x15;
			break;
		case 115200:
			spbrg = 0x0A;
			break;
		default:
			spbrg = 0x81;									// Default to 9600 if not a valid achievable Baud rate
	}
	spbrgh = 0x00;			


	if (Handshaking == FLOW_RTS_CTS)
	{
		portc &= ~_RTS;										// If handshaking is required, set RTS# active (low)
		FLOW_CONTROL_ENABLED = 0x01;						// Set flow control enabled flag
	}

	serial_resetrxfifo();									// Reset Rx FIFO
	serial_resettxfifo();									// Reset Tx FIFO

	pir1.RCIF = 0x00;										// Clear Rx interrupt flag
	pie1.RCIE = 0x01;										// Enable interrupts for Rx byte
	intcon.GIE = 0x01;
	intcon.PEIE = 0x01;
	rcsta.CREN = 0x01;										// Enable receiver
}




//*****************************************************************************************
//  
//  Send a byte directly from the transmit register
//  
//*****************************************************************************************
void serial_sendbyte(char TX_BYTE)
{
	if (FLOW_CONTROL_ENABLED == 0x01)
	{	
		while (portc & _CTS);								// Wait for CTS# to become active (low)
	}
	while (!txsta.TRMT);									// Wait for TSR to be empty
	txreg = TX_BYTE;										// Move byte to send into TXREG
	txsta.TXEN = 1;											// Start transmission
	while (!txsta.TRMT);									// Wait for TSR to be empty - indicates sending is complete
}




//*****************************************************************************************
//  
//  Read a byte directly from the receive character register
//  
//*****************************************************************************************
void serial_receivebyte(char RX_BYTE)
{
	RX_BYTE = rcreg;
	pir1.RCIF = 0x00;										// Clear Rx interrupt flag
}




//*****************************************************************************************
//  
//  Add a byte from the receive character register to the receive FIFO buffer
//  
//*****************************************************************************************
void serial_addtorxfifo()
{
	if (RX_FIFO_COUNT >= RX_FIFO_SIZE)						// If Rx FIFO is full
	{
		RX_STATUS = RX_STATUS | RX_FIFO_OVERRUN;			// Set overrun flag
		if (FLOW_CONTROL_ENABLED == 0x01)					// If using flow control
		{
			portc |= _RTS;									// Set RTS# inactive (high)
		}
		return;
	}

	if (RX_FIFO_COUNT >= RX_FIFO_UPPER_LIMIT)				// Keep some space in the FIFO for bytes already being sent
	{
		if (FLOW_CONTROL_ENABLED == 0x01)					// If using flow control
		{
			portc |= _RTS;									// Set RTS# inactive (high)
		}
	}

	intcon.GIE = 0x00;										// Disable interrupts
	intcon.PEIE = 0x00;

	*RX_FIFO_HEAD_PTR++ = rcreg;							// Add received byte to RX_FIFO and then increment head pointer
	RX_FIFO_COUNT++;										// Increment byte count

	if (RX_FIFO_HEAD_PTR >= RX_FIFO_END)					// If head pointer is greater than allocated FIFO end address
	{
		RX_FIFO_HEAD_PTR = RX_FIFO_START;					// Wrap-around buffer to start address again (circuluar FIFO)
	}	

	if ((RX_FIFO_COUNT < RX_FIFO_UPPER_LIMIT) && (FLOW_CONTROL_ENABLED == 0x01))	// If Rx FIFO is not full
	{
		portc &= ~_RTS;										// Set RTS# active (low)
	}
	
	intcon.GIE = 0x01;										// Re-enable interrupts
	intcon.PEIE = 0x01;
}




//*****************************************************************************************
//  
//  Read a byte out of the receive FIFO buffer
//  
//*****************************************************************************************
void serial_readfromrxfifo(char * RX_FIFO_BYTE)
{
	if (RX_FIFO_COUNT == 0)									// If FIFO is empty
	{
		return;												// Exit - no data to read
	}

	intcon.GIE = 0x00;										// Disable interrupts
	intcon.PEIE = 0x00;

	*RX_FIFO_BYTE = *RX_FIFO_TAIL_PTR++;					// Read a byte from the FIFO at position given by RX_FIFO_TAIL_PTR and then increment tail pointer
	RX_FIFO_COUNT--;										// Decrement byte count	
	
	if (RX_FIFO_TAIL_PTR >= RX_FIFO_END)					// If tail pointer is greater than allocated FIFO end address
	{
		RX_FIFO_TAIL_PTR = RX_FIFO_START;					// Wrap-around buffer to start address again (circuluar FIFO)
	}
	
	intcon.GIE = 0x01;										// Re-enable interrupts
	intcon.PEIE = 0x01;

	if ((RX_FIFO_COUNT < RX_FIFO_LOWER_LIMIT) && (FLOW_CONTROL_ENABLED == 0x01))	// If using flow control
	{
		portc &= ~_RTS;										// Set RTS# active (low)
	}
}




//*****************************************************************************************
//  
//  Add a byte to the transmit FIFO buffer
//  
//*****************************************************************************************
void serial_addtotxfifo(char * TX_BYTE)
{
	if (TX_FIFO_COUNT >= TX_FIFO_SIZE)						// If Tx FIFO is full
	{
		TX_STATUS = TX_STATUS | TX_FIFO_OVERRUN;			// Set overrun flag
		return;
	}

	*TX_FIFO_HEAD_PTR++ = *TX_BYTE;							// Add byte to TX_FIFO and then increment head pointer
	TX_FIFO_COUNT++;										// Increment byte count

	if (TX_FIFO_HEAD_PTR >= TX_FIFO_END)					// If head pointer is greater than allocated FIFO end address
	{
		TX_FIFO_HEAD_PTR = TX_FIFO_START;					// Wrap-around buffer to start address again (circuluar FIFO)
	}
}



//*****************************************************************************************
//  
//  Add a byte from the transmit FIFO buffer to the transmit character register and send it
//  
//*****************************************************************************************
void serial_sendfromtxfifo()
{
	if (FLOW_CONTROL_ENABLED == 0x01)						// If using flow control
	{
		while (portc & _CTS);								// Wait until CTS# is active (low)
	}

	if (TX_FIFO_COUNT == 0x00)								// If no data in FIFO
	{
		return;												// Exit - no data available
	}
		
	if (FLOW_CONTROL_ENABLED == 0x01)						// If using flow control
	{
		while (portc & _CTS);								// Wait for CTS# to become active (low)
	}

	while (!txsta.TRMT);									// Wait for TSR to be empty
	txreg = *TX_FIFO_TAIL_PTR++;							// Add byte from TX_FIFO_TAIL_PTR to tx register and then increment tail pointer
	TX_FIFO_COUNT--;										// Decrement byte count
	txsta.TXEN = 1;											// Start transmission
	while (!txsta.TRMT);									// Wait for TSR to be empty - indicates sending is complete
	
	if (TX_FIFO_TAIL_PTR >= TX_FIFO_END)
	{
		TX_FIFO_TAIL_PTR = TX_FIFO_START;					// Check for buffer wrap around
	}
}






///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////
//  
//  Routines for SPI emulation
//  
///////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////


//*****************************************************************************************
//  
//  Initialise SPI pins
//  
//*****************************************************************************************
void SPI_Init()
{
	cmcon0 = 0x07;											// Turn comparators off
	ansel &= 0xC9;											// Digital IO on RA1, RA2, RC0, RC1
	trisa |= SDI;											// TRISA bits 1 for input, 0 for output
	trisa &= ~SDO;											// SDI input, SDO output
	trisc &= ~SCLK;											// TRISC bits 1 for input, 0 for output
	trisc &= ~CS;											// SCLK output, CS output
	// Configure initial pin states
	porta &= ~SDO;											// SDO starts low
	portc &= ~SCLK;											// SCLK starts low
	portc &= ~CS;											// CS starts low
}



//*****************************************************************************************
//  
//  Activate the SPI clock pin (SCLK - Port C bit O)
//  
//*****************************************************************************************
void SPI_Set_SCLK()
{
	portc |= SCLK;											// Set SCLK active (high)
}





//*****************************************************************************************
//  
//  Deactivate the SPI clock pin (SCLK - Port C bit O)
//  
//*****************************************************************************************
void SPI_Clear_SCLK()
{
	portc &= ~SCLK;											// Set SCLK inactive (low)
}





//*****************************************************************************************
//  
//  Toggle the SPI clock pin state (SCLK - Port C bit 0)
//  
//*****************************************************************************************
void SPI_Toggle_Clock()
{
	if (portc & SCLK)										// If SCLK is high
	{
		SPI_Clear_SCLK();									// then toggle it low
	}
	else
	{
		SPI_Set_SCLK();										// Otherwise, toggle it high
	}
}





//*****************************************************************************************
//  
//  Pulse the SPI clock pin high then low (SCLK - Port C bit 0)
//  
//*****************************************************************************************
void SPI_Pulse_Clock()
{
	SPI_Clear_SCLK();										// Set SCLK low
	nop();													// Wait
	SPI_Set_SCLK();											// Toggle it high
	nop();													// Wait
	SPI_Clear_SCLK();										// Set SCLK low	
}




//*****************************************************************************************
//  
//  Activate the SPI chip select pin (CS - Port C bit 1)
//  
//*****************************************************************************************
void SPI_Set_CS()
{
	portc |= CS;											// Set CS active (high)
}




//*****************************************************************************************
//  
//  Deactivate the SPI chip select pin (CS - Port C bit 1)
//  
//*****************************************************************************************
void SPI_Clear_CS()
{
	portc &= ~CS;											// Set CS inactive (low)
}





//*****************************************************************************************
//  
//  Activate the SPI data out pin (SDO - Port A bit 2)
//  
//*****************************************************************************************
void SPI_Set_SDO()
{
	porta |= SDO;											// Set SDO active (high)
}




//*****************************************************************************************
//  
//  Deactivate the SPI data out pin (SDO - Port A bit 2)
//  
//*****************************************************************************************
void SPI_Clear_SDO()
{
	porta &= ~SDO;											// Set SDO inactive (low)
}



//*****************************************************************************************
//  
//  Read the state of the SPI data in pin (SDI - Port A bit 1)
//  
//*****************************************************************************************
char SPI_Get_SDI()
{
	return (porta & SDI) ? 0x01 : 0x00;						// Get state of SDI (high or low)
}



//*****************************************************************************************
//  
//  Clock bits in/out
//  
//*****************************************************************************************
void SPI_Shift_Data()
{
	SPI_Pulse_Clock();										// Generate a clock pulse
	SPI_Read_Byte <<= 1;									// Shift SPI_Read_Byte left 1 bit
	SPI_Read_Byte |= SPI_Get_SDI();							// OR with current SDI state
	SPI_Write_Byte <<= 1;									// Shift SPI_Write_Byte left 1 bit
	if (SPI_Write_Byte & 0x80)								// Test bit 7 of SPI_Write_Byte
	{
		SPI_Set_SDO();										// If high, set SDO high
	}
	else
	{
		SPI_Clear_SDO();									// If low, set SDO low
	}
}




//*****************************************************************************************
//  
//  Check if write was successful - SPI_Status bit (SDI) must be read before calling
//  
//*****************************************************************************************
void SPI_Check_Write_Status()
{
	if ((LastWasRead == 0x00) && (SPI_Status == 0x00))  	// Write status check
	{
		SPI_Write_Failed = 0x00;							// Write operation passed
	}
	else if ((LastWasRead == 0x00) && (SPI_Status == 0x01))
	{
		SPI_Write_Failed = 0x01;							// Write operation failed
	}
}





//*****************************************************************************************
//  
//  Check if read was successful - SPI_Status bit (SDI) must be read before calling
//  
//*****************************************************************************************
void SPI_Check_Read_Status()
{
	if ((LastWasRead == 0x01) && (SPI_Status == 0x00))
	{
		serial_addtotxfifo(&SPI_Read_Byte);					// If data read is valid, add it to UART TX FIFO
	}
}





//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************
//  
//  Interrupt routines go here
//  Use receive character interrupt to add received characters to the RX FIFO
//  
//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************
void interrupt()
{															
	if (pir1.RCIF) 
	{
//		if (FLOW_CONTROL_ENABLED == 0x01)					// If using flow control
//		{
//			portc |= _RTS;									// Set RTS# inactive (high)
//		}
		serial_addtorxfifo();								// Add received byte to Rx FIFO
		pir1.RCIF = 0x00;									// Clear RCIF flag
	}	
}





//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************
//  
//  Main line code
//  
//*****************************************************************************************
//*****************************************************************************************
//*****************************************************************************************
void main()
{
	serial_init(115200, FLOW_RTS_CTS);						// Initialise Baud rate and flow control
	SPI_Init();												// Initialise SPI pins

	while (1)												// SPI state machine here - don't come out again
	{
		switch (SPI_State)
		{
			case SPI_Idle:
				while (TX_FIFO_COUNT > 0x00)
				{
					serial_sendfromtxfifo();				// Send any available data from the UART
				}
				SPI_Clear_SDO();							// Set SDO low
				SPI_Clear_CS();								// Set CS low
				SPI_Clear_SCLK();							// Set SCLK low
				if (WRStart)								// WRStart macro defined above
				{
					SPI_State = SPI_W1;						// Move state to W1	
				}
				else
				{
					SPI_State = SPI_R1;						// Move state to R1
				}
				break;

			case SPI_R1:
				SPI_Set_CS();								// Raise CS
				SPI_Set_SDO();								// Raise SDO (SDI on VNC1L)
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_State = SPI_R2;							// Move state to R2
				break;

			case SPI_R2:
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_State = SPI_R3;							// Move state to R3
				break;

			case SPI_R3:
				SPI_Clear_SDO();							// Lower SDO (SDI on VNC1L)
				SPI_Pulse_Clock();							// Generate a clock pulse
				LastWasRead = 0x01;							// Set to indicate last operation was a read
				SPI_Read_Byte = SPI_Get_SDI();				// Shift
				SPI_State = SPI_D1;							// Move state to D1
				break;

			case SPI_W1:
				SPI_Set_CS();								// Raise CS
				SPI_Set_SDO();								// Raise SDO (SDI on VNC1L)
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_State = SPI_W2;							// Move state to W2
				break;

			case SPI_W2:
				SPI_Clear_SDO();							// Lower SDO (SDI on VNC1L)
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_State = SPI_W3;							// Move state to W2
				break;

			case SPI_W3:
				SPI_Pulse_Clock();							// Generate a clock pulse
				LastWasRead = 0x00;							// Set to indicate last operation was a write (not a read)
				if (SPI_Write_Failed == 0x01)				// If last write attempt failed
				{
					SPI_Write_Byte = SPI_Last_Write_Byte;	// Send last byte again
					SPI_Write_Failed = 0x00;				// Reset status
				}
				else
				{
					serial_readfromrxfifo(&SPI_Write_Byte);	// Read a byte out of the UART FIFO to write over SPI
					SPI_Last_Write_Byte = SPI_Write_Byte;	// Update last byte variable
				}
				if (SPI_Write_Byte & 0x80)					// Test bit 7 of SPI_Write_Byte
				{
					SPI_Set_SDO();							// If high, set SDO high
				}
				else
				{
					SPI_Clear_SDO();						// If low, set SDO low
				}
				SPI_State = SPI_D1;							// Move state to D1
				break;

			case SPI_D1:
				SPI_Shift_Data();
				SPI_State = SPI_D2;							// Move state to D2
				break;

			case SPI_D2:
				SPI_Shift_Data();
				SPI_State = SPI_D3;							// Move state to D3
				break;

			case SPI_D3:
				SPI_Shift_Data();
				SPI_State = SPI_D4;							// Move state to D4
				break;

			case SPI_D4:
				SPI_Shift_Data();
				SPI_State = SPI_D5;							// Move state to D5
				break;

			case SPI_D5:
				SPI_Shift_Data();
				SPI_State = SPI_D6;							// Move state to D6
				break;

			case SPI_D6:
				SPI_Shift_Data();
				SPI_State = SPI_D7;							// Move state to D7
				break;

			case SPI_D7:
				SPI_Shift_Data();
				SPI_State = SPI_C1;							// Move state to C1
				break;

			case SPI_C1:
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_Status = SPI_Get_SDI();					// Check status
				SPI_Check_Write_Status();
				SPI_Check_Read_Status();
				SPI_State = SPI_C2;							// Move state to C2
				break;

			case SPI_C2:
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_Clear_CS();								// Lower SPI chip select
				SPI_State = SPI_C3;							// Move state to C3
				break;

			case SPI_C3:
				SPI_Pulse_Clock();							// Generate a clock pulse
				SPI_State = SPI_Idle;						// Move state to Idle
				break;
		}
	}
}

