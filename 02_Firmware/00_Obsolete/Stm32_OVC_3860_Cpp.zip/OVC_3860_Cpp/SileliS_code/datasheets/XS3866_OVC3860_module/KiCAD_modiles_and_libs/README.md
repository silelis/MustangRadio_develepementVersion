repo for hw(pcbs mainly) part of electronic projects, sometimes there is also few software files here:)

kicad: projects made in kicad

audi_chorus_cd_changer_input: all files needed to convert audi chorus 1 to enable CD changer input, more: http://kovo-blog.blogspot.sk/2013/11/how-to-enable-cd-changer-input-on-audi.html

