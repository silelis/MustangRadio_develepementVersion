extern const unsigned char   mod_data[];
extern unsigned int    mod_len;
extern const char    * mod_name;
