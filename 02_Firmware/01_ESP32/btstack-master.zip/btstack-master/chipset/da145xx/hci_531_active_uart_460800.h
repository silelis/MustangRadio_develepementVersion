
/** 
 * hci_531_active_uart_460800.h converted from hci_531_active_uart_460800.hex 
 */

#ifndef hci_531_active_uart_460800_H
#define hci_531_active_uart_460800_H

#include <stdint.h>

extern const uint8_t  da145xx_fw_data[];
extern const uint32_t da145xx_fw_size;
extern const char *   da145xx_fw_name;

#endif
