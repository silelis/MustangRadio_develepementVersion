
/** 
 * hci_585.h converted from hci_585.hex 
 */

#ifndef hci_585_H
#define hci_585_H

#include <stdint.h>

extern const uint8_t  da145xx_fw_data[];
extern const uint32_t da145xx_fw_size;
extern const char *   da145xx_fw_name;

#endif
