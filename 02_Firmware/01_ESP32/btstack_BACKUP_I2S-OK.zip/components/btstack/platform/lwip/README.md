# lwIP Support for BTstack

Contents:
- bnep_lwip contains an adapter to forward packets between lwIP and BNEP
- port contains a NO_SYS == 1 / bare metal configuration to use lwIP with BTstack on the same thread 
