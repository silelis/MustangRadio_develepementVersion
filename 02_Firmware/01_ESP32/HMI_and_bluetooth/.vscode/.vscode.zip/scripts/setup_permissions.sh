#!/bin/bash
echo "Setting up permissions for ESP32 decoder..."
chmod +x "$(dirname "$0")/decode_guru.py"
echo "✅ Setup complete!"