#pragma once

#include "esp_log.h"
#include "driver/i2c.h"


#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

class i2cMaster
{
public:
	i2cMaster(int, int, uint32_t, size_t, size_t);
	~i2cMaster();
	esp_err_t i2cPing(uint8_t);
	esp_err_t writeData(i2c_cmd_handle_t);
	
protected:
	
private:
	
	//TODO: mux or semaphote to avoid multiple i2c usage at the time
	const char *TAG = "I2C master log:";
	static uint8_t i2cInstanceCounter; //thisone should be initioalised to "0" at !!!very top!!!

	static int i2cMasterPort;
	static i2c_config_t i2cConfig;
	static SemaphoreHandle_t xI2CMasterMutex;		//mutex which controlls access to I2C interface
};