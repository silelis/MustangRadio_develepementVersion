#pragma once
#include "cstdio"
#include "hwConfigFile.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "esp_attr.h"
#include "driver/gptimer.h"
#include "freertos/FreeRTOS.h"

#define LONG_PRESS_BIT_MASK		0b10000000

//#define DEBUG_ENCODER_TABLE

struct kbrdState
{
	volatile uint8_t lastState;
	volatile uint8_t newState;
	uint8_t latchedState;
};



struct encoderState
{
	int8_t stepCounter;
	volatile uint8_t lastState;		//used to debounce
	volatile uint8_t newState;		//used to debounce
	uint8_t lastLatchedState;		//pin state after dobounce used to calculate direction (not requiref if encoders and input would be in different functions)
	uint8_t newLatchedState;		//pin state after dobounce used to calculate direction (not requiref if encoders and input would be in different functions)
	uint8_t pulseIncrement;
	//const int8_t pulsPerDetant = ENCODER_PULSED_PER_DETANT;
	int8_t latchedQEM;				//value which is retrurned to encoder queue
	
#ifdef DEBUG_ENCODER_TABLE
	//WYKASOWA� PONI�SZE	
	uint8_t table[100];
	uint8_t i = 0;
	//WYKASOWA� POWY�SZE
	//		  
#endif // DEBUG


	
};


struct gpioInterruptCallbackStruct				//struct which is passed to interrupts (timer and gpios) callback functions
{
	encoderState*		pVolEncState;			//pointer to volume encoder
	encoderState*		pEquEncState;			//pointer to equaliser encoder
	kbrdState*			pbuttonsState;			//pointer to buttons struct kbrdState
	gptimer_handle_t	pgptimer;				//pointer to timer
	bool exitTimerInterrupt;					//variable used to determine if alarm callback function should be stopped
	uint16_t debounceTime;						//debounce time and long press counting variable
	
	const int8_t QEM[16] = { 0, -1, 1, 2, 1, 0, 2, -1, -1, 2, 0, 1, 2, 1, -1, 0 };		//rotary encoder state martix
	
	char whichInput;							//variable used to determine which input in active /buttons/ volume encoder / equaliser encoder
	const char case_buttonInput = 'B';
	const char case_volumeInput = 'V';
	const char case_equaliserInput = 'E';
};


class KEYBOARD
{
public:
	KEYBOARD();
	~KEYBOARD();
	static void gpio_intr_disableAll();
	static void gpio_intr_enableAll();
	static uint8_t buttonsGetLevel();
	static uint8_t encoderGetLevel(gpio_num_t EncoderPortA, gpio_num_t EncoderPortB);
	//kbrdState buttonsState;
	//encoderState VolEncState;
	//encoderState EquEncState;
	
	
protected:
	//gptimer_config_t gpioDebounceTimer_config;
	//gptimer_handle_t gptimer = NULL;
	//gptimer_alarm_config_t gpioAlarm_config;
	

	
	
private:
	const char *TAG = "Input(s) log:";
	gpio_config_t iputButtonsConf;
	gpio_config_t iputRotaryEncoderConf;
	gptimer_event_callbacks_t cbs;
	gpioInterruptCallbackStruct gpioInterruptCallback;
	

	
	gptimer_config_t gpioDebounceTimer_config;
	gptimer_handle_t gptimer = NULL;
	gptimer_alarm_config_t gpioAlarm_config;
	
	kbrdState buttonsState;
	encoderState VolEncState;
	encoderState EquEncState;
};