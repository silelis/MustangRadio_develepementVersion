#pragma once

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "comunicationProtocol.h"
#include "hwConfigFile.h"
#include "tasksFunctions.h"
#include "keyboard/keyboard.h"
#include "Leds\Leds_backlight.h"


struct hmiDisplay {
	struct colorSet {
		struct ws2812Color primary;
		struct ws2812Color secondary;
	} sourceLed, equaliserLed, errorLed, backlightLeds;

	const uint16_t blinkTime = LED_DISPLAY_BLINK_TIME;
};

extern QueueHandle_t handlerQueue_MainKeyboard;
extern TaskHandle_t handlerTask_keyboardQueueParametersParser;
extern TaskHandle_t handlerTask_ledDisplay;
extern TaskHandle_t handlerTask_backlightDisplay;	
extern hmiDisplay displayLedsColors;
extern SemaphoreHandle_t handlerMutex_ledDisplay_Backlight;

void keyboardQueueParametersParser(void*);
void humanMahineDisplayLeds(void *);
void humanMahineBacklightLeds(void *);