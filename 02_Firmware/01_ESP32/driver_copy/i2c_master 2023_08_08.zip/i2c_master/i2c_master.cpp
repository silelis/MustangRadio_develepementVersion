#include "i2c_master.h"

uint8_t i2cMaster::i2cInstanceCounter = 0;
int i2cMaster::i2cMasterPort;
i2c_config_t i2cMaster::i2cConfig;
SemaphoreHandle_t i2cMaster::xI2CMasterMutex=NULL;


/*----------------------------------------------------------------------------------
Konstruktor interfejsu komunikacji ESP32 po i2c z peryferiami typu slave.
ESP32 działa jako master.
Klasa zaprojektowana w sposób pozwalający na jej dziedziczenie w wielu równoległych
klasach, jak również konstruowanie wielu obiektow. Kluczowe do działania komunikacji
i2c zmienne zdefiniowano jako static, co powoduje, że w obiektach, w których klasa jest
wywoływana deklarowane sa tylko raz. Mechanizm ten kontrolowany jest poprzez zmienną 
"i2cInstanceCounter". Jeżleli zmienna "i2cInstanceCounter" ma wartość większą od 0 to
znaczy, że nastąła już inicjalizacja interfejsu i2c i nie należy jej powtażać.

Parameters:
int pinSDA 		- pin SDA interfejsu i2c
int pinSCL 		- pin SCL interfejsu i2c
uint32_t i2cSpeed	- prętkość transmisji i2c
size_t rxBuffLen	- wielkość bufora nadawania
size_t txBuffLen	- wielkość bufora odbioru
Returns:
NONE
----------------------------------------------------------------------------------*/
i2cMaster::i2cMaster(int pinSDA, int pinSCL, uint32_t i2cSpeed, size_t rxBuffLen, size_t txBuffLen)
{
	//esp_err_t retVal;
	if (i2cInstanceCounter==0)
	{
		xI2CMasterMutex = xSemaphoreCreateMutex();
		
		ESP_LOGI(this->TAG, "Create I2C master configuration.");
		i2cMasterPort = 1;
					
		i2cConfig.mode = I2C_MODE_MASTER;
		i2cConfig.sda_io_num = pinSDA;	//GPIO_NUM_19;
		i2cConfig.scl_io_num = pinSCL;	//GPIO_NUM_18;
		//i2c_conf.sda_pullup_en = 0;
		//i2c_conf.scl_pullup_en = 0;
		i2cConfig.master.clk_speed = i2cSpeed; //400khz 
		i2cConfig.clk_flags = 0;
		
		i2c_param_config(i2cMasterPort, &i2cConfig);
 
		
		if ((i2c_driver_install(i2cMasterPort, i2cConfig.mode, rxBuffLen, txBuffLen, 0) == ESP_OK)&& (xI2CMasterMutex !=NULL))
		{
			
			/*if (i2cSpeed > 400000)
			{
				i2c_filter_enable(i2cMasterPort, 5);
			}*/		
			i2cInstanceCounter++;			
			ESP_LOGI(this->TAG, "I2C has been configured.");
			xSemaphoreGive(xI2CMasterMutex);
		}
		else
		{
			ESP_LOGI(this->TAG, "I2C configuration error.");
			if (i2c_driver_install(i2cMasterPort, i2cConfig.mode, rxBuffLen, txBuffLen, 0) != ESP_OK)
			{
				ESP_LOGI(this->TAG, "I2C hardware configuration error");
			}
			if (xI2CMasterMutex == NULL)
			{
				ESP_LOGI(this->TAG, "I2C mutex configuration error");
			}
		}
	}
	else
	{
		ESP_LOGI(this->TAG, "I2C had already been configured.");
	}

}


i2cMaster::~i2cMaster()
{
	if (i2cInstanceCounter == 1)
	{
		//i2c_cmd_link_delete_static	// - to consider if it is required
		//i2c_cmd_link_delete			// - to consider if it is required
		if (xSemaphoreTake(xI2CMasterMutex, portMAX_DELAY) == pdTRUE)
		{
			vSemaphoreDelete(xI2CMasterMutex);
			i2c_reset_tx_fifo(i2cMasterPort);
			i2c_reset_rx_fifo(i2cMasterPort);
			i2c_driver_delete(i2cMasterPort);			
		}

	}
	i2cInstanceCounter--;
}

esp_err_t i2cMaster::i2cPing(uint8_t i2c_address)
{
	i2c_cmd_handle_t cmd = i2c_cmd_link_create();
	i2c_master_start(cmd);
	i2c_master_write_byte(cmd, (i2c_address << 1) | I2C_MASTER_WRITE, true);
	i2c_master_stop(cmd);
	
	xSemaphoreTake(xI2CMasterMutex, portMAX_DELAY);
	esp_err_t retVal = i2c_master_cmd_begin(i2cMasterPort, cmd, 10000);
	xSemaphoreGive(xI2CMasterMutex);
	i2c_cmd_link_delete(cmd);
	
	if (retVal == ESP_OK)
	{
		ESP_LOGI(TAG, "Device found at address 0x%02X", i2c_address);
		//return true;
	}
	else if (retVal == ESP_ERR_TIMEOUT)
	{
		ESP_LOGW(TAG, "No response from device at address 0x%02X", i2c_address);
		//return false;
	}
	else
	{
		ESP_LOGE(TAG, "Error %d during I2C communication", retVal);
		//return false;
	}
	
	return retVal;
}

esp_err_t i2cMaster::i2cWriteData(i2c_cmd_handle_t cmd_handle)
{
	xSemaphoreTake(xI2CMasterMutex, portMAX_DELAY);
	esp_err_t retVal = i2c_master_cmd_begin(i2cMasterPort, cmd_handle, portMAX_DELAY);
	xSemaphoreGive(xI2CMasterMutex);
	return retVal;
}


uint8_t i2cMaster::geti2cInstanceCounterState()
{
	return i2cMaster::i2cInstanceCounter;
}