#pragma once

#include "led_strip.h"
#include "esp_log.h"


class LEDS_BACKLIGHT
{
public:
	LEDS_BACKLIGHT(/*led_strip_rmt_config_t,*/ int, uint8_t, led_pixel_format_t, led_model_t);
	~LEDS_BACKLIGHT();
	
	esp_err_t ledStripSet_sourceLed(uint32_t, uint32_t, uint32_t);
	esp_err_t ledStripSet_equaliserLed(uint32_t, uint32_t, uint32_t);
	esp_err_t ledStripSet_errorLed(uint32_t, uint32_t, uint32_t);
	esp_err_t ledStripSet_backlightLeds(uint32_t, uint32_t, uint32_t);
	esp_err_t ledStripRefresh();
protected:
	esp_err_t ledStripClearAll();
	
private:
	const char *TAG = "Led Bglight log:";
	uint32_t errorLedAddress;
	uint32_t equaliserLedAddress;
	uint32_t sourceLedAddress;
	led_strip_handle_t ledStrip;
};